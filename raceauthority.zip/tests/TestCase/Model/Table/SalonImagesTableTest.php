<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\SalonImagesTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\SalonImagesTable Test Case
 */
class SalonImagesTableTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \App\Model\Table\SalonImagesTable
     */
    public $SalonImages;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.salon_images',
        'app.salons',
        'app.users',
        'app.account_types',
        'app.user_tokens',
        'app.salon_work_days',
        'app.order_costs'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::exists('SalonImages') ? [] : ['className' => SalonImagesTable::class];
        $this->SalonImages = TableRegistry::get('SalonImages', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->SalonImages);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
