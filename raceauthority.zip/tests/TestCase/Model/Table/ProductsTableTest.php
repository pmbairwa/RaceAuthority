<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\ProductsTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\ProductsTable Test Case
 */
class ProductsTableTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \App\Model\Table\ProductsTable
     */
    public $Products;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.products',
        'app.categories',
        'app.seller',
        'app.account_types',
        'app.countries',
        'app.states',
        'app.orders',
        'app.users',
        'app.reviews',
        'app.buyer',
        'app.saved_cards',
        'app.shipping_methods',
        'app.stripe_customers',
        'app.user_addresses',
        'app.user_tokens',
        'app.wp_comments',
        'app.wp_usermeta',
        'app.transactions',
        'app.seller_orders',
        'app.vendors',
        'app.product_tags',
        'app.tags',
        'app.product_images'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::exists('Products') ? [] : ['className' => ProductsTable::class];
        $this->Products = TableRegistry::get('Products', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->Products);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test findCommon method
     *
     * @return void
     */
    public function testFindCommon()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
