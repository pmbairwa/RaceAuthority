<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\ShippingMethodsTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\ShippingMethodsTable Test Case
 */
class ShippingMethodsTableTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \App\Model\Table\ShippingMethodsTable
     */
    public $ShippingMethods;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.shipping_methods',
        'app.users',
        'app.account_types',
        'app.payment_details',
        'app.restaurants',
        'app.user_tokens',
        'app.user_addresses',
        'app.countries',
        'app.states',
        'app.orders',
        'app.transactions',
        'app.seller_orders',
        'app.products',
        'app.categories',
        'app.seller',
        'app.saved_cards',
        'app.product_tags',
        'app.tags',
        'app.product_images',
        'app.reviews',
        'app.buyer',
        'app.sellers'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::exists('ShippingMethods') ? [] : ['className' => ShippingMethodsTable::class];
        $this->ShippingMethods = TableRegistry::get('ShippingMethods', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->ShippingMethods);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
