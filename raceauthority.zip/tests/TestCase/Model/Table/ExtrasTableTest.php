<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\ExtrasTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\ExtrasTable Test Case
 */
class ExtrasTableTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \App\Model\Table\ExtrasTable
     */
    public $Extras;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.extras',
        'app.restaurants',
        'app.users',
        'app.account_types',
        'app.user_tokens',
        'app.restaurant_work_days',
        'app.menu_extras'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::exists('Extras') ? [] : ['className' => ExtrasTable::class];
        $this->Extras = TableRegistry::get('Extras', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->Extras);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
