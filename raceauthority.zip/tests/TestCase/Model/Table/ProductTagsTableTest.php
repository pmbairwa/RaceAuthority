<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\ProductTagsTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\ProductTagsTable Test Case
 */
class ProductTagsTableTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \App\Model\Table\ProductTagsTable
     */
    public $ProductTags;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.product_tags',
        'app.products',
        'app.categories',
        'app.seller',
        'app.account_types',
        'app.user_tokens',
        'app.users',
        'app.user_addresses',
        'app.saved_cards',
        'app.tags'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::exists('ProductTags') ? [] : ['className' => ProductTagsTable::class];
        $this->ProductTags = TableRegistry::get('ProductTags', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->ProductTags);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
