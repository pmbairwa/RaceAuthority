<?php
namespace App\Test\TestCase\Controller\Admin;

use App\Controller\Admin\ShippingMethodsController;
use Cake\TestSuite\IntegrationTestCase;

/**
 * App\Controller\Admin\ShippingMethodsController Test Case
 */
class ShippingMethodsControllerTest extends IntegrationTestCase
{

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.shipping_methods',
        'app.users',
        'app.account_types',
        'app.payment_details',
        'app.restaurants',
        'app.user_tokens',
        'app.user_addresses',
        'app.countries',
        'app.states',
        'app.orders',
        'app.transactions',
        'app.seller_orders',
        'app.products',
        'app.categories',
        'app.seller',
        'app.saved_cards',
        'app.product_tags',
        'app.tags',
        'app.product_images',
        'app.reviews',
        'app.buyer',
        'app.sellers'
    ];

    /**
     * Test index method
     *
     * @return void
     */
    public function testIndex()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test view method
     *
     * @return void
     */
    public function testView()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test add method
     *
     * @return void
     */
    public function testAdd()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test edit method
     *
     * @return void
     */
    public function testEdit()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test delete method
     *
     * @return void
     */
    public function testDelete()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
