<?php
namespace App\Test\TestCase\Controller\SalonOwner;

use App\Controller\SalonOwner\SalonServicesController;
use Cake\TestSuite\IntegrationTestCase;

/**
 * App\Controller\SalonOwner\SalonServicesController Test Case
 */
class SalonServicesControllerTest extends IntegrationTestCase
{

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.salon_services',
        'app.services',
        'app.bookings',
        'app.users',
        'app.account_types',
        'app.user_tokens',
        'app.salons',
        'app.salon_work_days',
        'app.order_costs',
        'app.users_services'
    ];

    /**
     * Test index method
     *
     * @return void
     */
    public function testIndex()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test view method
     *
     * @return void
     */
    public function testView()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test add method
     *
     * @return void
     */
    public function testAdd()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test edit method
     *
     * @return void
     */
    public function testEdit()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test delete method
     *
     * @return void
     */
    public function testDelete()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
