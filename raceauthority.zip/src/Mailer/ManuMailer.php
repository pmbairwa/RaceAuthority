<?php

namespace App\Mailer;

use Cake\Mailer\Mailer;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use Cake\Utility\Text;
use Cake\Mailer\Email;

/**
 * Manu mailer.
 */
class ManuMailer extends Mailer {

    /**
     * Mailer's name.
     *
     * @var string
     */
    static public $name = 'Manu';

    public function send_invoice($order) {
        $compeleteOrderData = json_decode($order->order_json);
        $format = "html"; // both
        $subject = 'Invoice';
        $from = Configure::read('Setting.from_email') != null ? Configure::read('Setting.from_email') : "testsupport@appsder.com";
        $this
                ->setTransport('mygmail')
                ->setSender($from, Configure::read('Setting.site_name') . " emailer")
                ->setFrom([$from => Configure::read('Setting.site_name')])
                ->setTo('developerrajeshjangid@gmail.com')
                ->setSubject($subject)
                ->setEmailFormat($format)
                ->setViewVars(['order' => $order])
                ->setTemplate('invoice') // By default template with same name as method name is used.
                ->setLayout('default');
    }

    public function welcome($user) {
        $this->UserTokens = TableRegistry::get('UserTokens');
        $from = Configure::read('Setting.from_email') != null ? Configure::read('Setting.from_email') : "testsupport@appsder.com";
        $EmailTemplates = TableRegistry::get('EmailTemplates');
        $template = $EmailTemplates->find()->where(['email_type' => 'welcome_email'])->first();
        $subject = str_replace('##first_name##', $user->first_name, $template->subject);
        $subject = str_replace('##site_name##', Configure::read('Setting.site_name'), $subject);
        $uid = md5($user['id']) . "-" . Text::uuid();
        $message = str_replace('##base_url##', _BASE_, $template->description);
        $message = str_replace('##first_name##', $user->first_name, $message);
        $message = str_replace('##site_name##', Configure::read('Setting.site_name'), $message);
        $message = str_replace('##site_logo##', _BASE_ . 'img/uploads/settings/' . Configure::read('Setting.logo'), $message);
        $message = str_replace('##activate_link##', _BASE_ . "users/verify/" . $uid, $message);
        $message = str_replace('##footer##', "Copyright " . Configure::read('Setting.site_name') . " " . date("Y"), $message);

        $_usertoken = $this->UserTokens->newEntity();
        $_usertoken->user_id = $user->id;
        $_usertoken->user_type = "website_users";
        $_usertoken->token_type = "registration_verified";
        $_usertoken->token = $uid;
        $this->UserTokens->save($_usertoken);
        $format = "html"; // both

        $this
                ->setTransport('mygmail')
                ->setSender($from, Configure::read('Setting.site_name') . " emailer")
                ->setFrom([$from => Configure::read('Setting.site_name')])
                ->setTo($user->email)
                ->setSubject($subject)
                ->setEmailFormat($format)
                ->setViewVars(['content' => $message])
                ->setTemplate('default') // By default template with same name as method name is used.
                ->setLayout('default');
    }

    public function welcome_admin($user) {
        $this->UserTokens = TableRegistry::get('UserTokens');
        $from = Configure::read('Setting.from_email') != null ? Configure::read('Setting.from_email') : "testsupport@appsder.com";
        $EmailTemplates = TableRegistry::get('EmailTemplates');
        $template = $EmailTemplates->find()->where(['email_type' => 'welcome_from_admin'])->first();

        $subject = str_replace('##first_name##', $user->first_name, $template->subject);
        $subject = str_replace('##site_name##', Configure::read('Setting.site_name'), $subject);
        $uid = md5($user['id']) . "-" . Text::uuid();
        $message = str_replace('##base_url##', _BASE_, $template->description);
        $message = str_replace('##first_name##', $user->first_name, $message);
        $message = str_replace('##site_name##', Configure::read('Setting.site_name'), $message);
        $message = str_replace('##site_logo##', _BASE_ . 'img/uploads/settings/' . Configure::read('Setting.logo'), $message);
        $message = str_replace('##set_password_link', _BASE_ . "users/setpassword/" . $uid, $message);
        $message = str_replace('##footer##', "Copyright " . Configure::read('Setting.site_name') . " " . date("Y"), $message);

        $_usertoken = $this->UserTokens->newEntity();
        $_usertoken->user_id = $user->id;
        $_usertoken->user_type = "website_users";
        $_usertoken->token_type = "setpassword";
        $_usertoken->token = $uid;
        $this->UserTokens->save($_usertoken);
        $format = "html"; // both
        ;
        Email::configTransport('mygmail');
        $this
                ->setTransport('mygmail')
                ->setSender($from, Configure::read('Setting.site_name') . " emailer")
                ->setFrom([$from => Configure::read('Setting.site_name')])
                ->setTo($user->email)
                ->setSubject($subject)
                ->setEmailFormat($format)
                ->setViewVars(['content' => $message])
                ->setTemplate('default') // By default template with same name as method name is used.
                ->setLayout('default');
    }

    public function forgot($user) {
        $this->UserTokens = TableRegistry::get('UserTokens');
        $from = Configure::read('Setting.from_email') != null ? Configure::read('Setting.from_email') : "testsupport@appsder.com";
        $EmailTemplates = TableRegistry::get('EmailTemplates');
        $template = $EmailTemplates->find()->where(['email_type' => 'forgot_password'])->first();

        $uid = Text::uuid();
        $message = str_replace('##base_url##', _BASE_, $template->description);
        $message = str_replace('##site_name##', Configure::read('Setting.site_name'), $message);
        $message = str_replace('##site_logo##', _BASE_ . 'img/uploads/settings/' . Configure::read('Setting.logo'), $message);
        $message = str_replace('##user_name##', $user->first_name . ' ' . $user->last_name, $message);
        $message = str_replace('##user_reset_link##', _BASE_ . "users/reset/" . $uid, $message);
        $message = str_replace('##footer##', "Copyright " . Configure::read('Setting.site_name') . " " . date("Y"), $message);

        $subject = str_replace('##site_name##', Configure::read('Setting.site_name'), $template->subject);
        $subject = str_replace('##firstname', $user->first_name, $subject);
        $UserTokens = TableRegistry::get('UserTokens');
        $_usertoken = $UserTokens->newEntity();
        $_usertoken->user_id = $user->id;
        $_usertoken->user_type = "website_users";
        $_usertoken->token_type = "forgot";
        $_usertoken->token = $uid;
        $UserTokens->save($_usertoken);
        $format = "html"; // both
        $this
                ->setTransport('mygmail')
                ->setSender($from, Configure::read('Setting.site_name') . " emailer")
                ->setFrom([$from => Configure::read('Setting.site_name')])
                ->setTo($user->email)
                ->setSubject($subject)
                ->setEmailFormat($format)
                ->setViewVars(['content' => $message])
                ->setTemplate('default') // By default template with same name as method name is used.
                ->setLayout('default');
    }

    public function form_mail($data) {
        $from = Configure::read('Setting.from_email') != null ? Configure::read('Setting.from_email') : "testsupport@appsder.com";
        $to = Configure::read('Setting.to_email') != null ? Configure::read('Setting.to_email') : "testsupport@appsder.com";
        $admin = Configure::read('Setting.email_admin') != null ? Configure::read('Setting.email_admin') : "Lynda";
        $EmailTemplates = TableRegistry::get('EmailTemplates');
        $template = $EmailTemplates->find()->where(['email_type' => 'global_form'])->first();

        $message = str_replace('##base_url##', _BASE_, $template->description);
        $message = str_replace('##site_name##', Configure::read('Setting.site_name'), $message);
        $message = str_replace('##site_logo####', _BASE_ . 'img/uploads/settings/' . Configure::read('Setting.logo'), $message);
        $message = str_replace('##admin##!', $admin, $message);
        $message = str_replace('##content##', $data['content'], $message);

        $subject = str_replace('##subject##', $data['subject'], $template->subject);
        $message = str_replace('##footer##', "Copyright " . Configure::read('Setting.site_name') . " " . date("Y"), $message);
        $format = "html"; // both

        $this
                ->setTransport('mygmail')
                ->setSender($from, Configure::read('Setting.site_name') . " emailer")
                ->setFrom([$from => Configure::read('Setting.site_name')])
                ->setTo($to)
                ->setSubject($subject)
                ->setEmailFormat($format)
                ->setViewVars(['content' => $message])
                ->setTemplate('default') // By default template with same name as method name is used.
                ->setLayout('default');
    }

    public function sendEmails($config, $bodyContent, $template = "default", $layout = 'default', $file = '') {
        $from = Configure::read('Setting.from_email') != null ? Configure::read('Setting.from_email') : "testsupport@domain.com";
        $format = "html"; // both

        if (isset($config['from'])) {
            $from = $config['from'];
        }
        if (isset($config['to'])) {
            $to = $config['to'];
        }


        $sent = $this
                ->setTransport('mygmail')
                ->setSender($from, Configure::read('Setting.site_name'))
                ->setFrom([$from => Configure::read('Setting.site_name')]);

        $this->setTo($config['to']);


        if (isset($config['cc'])) {
            $this->setCc($config['cc']);
        }
        if (isset($config['bcc'])) {
            $this->setBcc($config['bcc']);
        }

        if (isset($config['subject'])) {
            $this->setSubject($config['subject']);
        }

        if ($file != '') {
            $this->setAttachments($file);
        }

        $this->setEmailFormat($format)
                ->setViewVars(['content' => $bodyContent])
                ->setTemplate($template) // By default template with same name as method name is used.
                ->setLayout($layout);
        Email::dropTransport('mygmail');
    }

}
