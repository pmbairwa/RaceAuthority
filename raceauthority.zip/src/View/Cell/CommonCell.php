<?php
namespace App\View\Cell;

use Cake\View\Cell;
use Cake\ORM\TableRegistry;
/**
 * Common cell
 */
class CommonCell extends Cell
{

    /**
     * List of valid options that can be passed into this
     * cell's constructor.
     *
     * @var array
     */
    protected $_validCellOptions = [];

    /**
     * Default display method.
     *
     * @return void
     */
    public function display()
    {
    }
    
    public function getParentCategories($id = null) {
        $this->loadModel('MenuCategories');
        $records = $this->MenuCategories->getParentCategoriesList($id);        
        $this->set(compact('records','id'));
    }  
    
    public function getParentAttributes($id = null) {
        $this->loadModel('Attributes');
        $records = $this->Attributes->getParentAttributesList($id);        
        $this->set(compact('records','id'));
    }
    
    public function getParentExtras($id = null) {
        $this->loadModel('Extras');
        $records = $this->Extras->getParentExtrasList($id);        
        $this->set(compact('records','id'));
    }
    
    
}
