<?php

namespace App\View\Helper;

use Cake\View\Helper;
use Cake\Routing\Router;

class CustomHelper extends Helper {

    public $helpers = ['Html'];

    public function getRatingStars($rating, $size = 'small') {
        $star = '<ul>';

        $half_rating = explode(".", $rating);

        for ($x = 1; $x <= $rating; $x++) {
            $star .='<li>' . $this->Html->image('star-active-' . $size . '.png', ['alt' => 'rating']) . '</li>';
        }
        if (!empty($half_rating[1]) && $half_rating[1] >= 5) {
            $star .= '<li>' . $this->Html->image('halfstar-active-' . $size . '.png', ['alt' => 'rating']) . '</li>';
            $x++;
        }
        while ($x <= 5) {
            $star .= '<li>' . $this->Html->image('star-in-active-' . $size . '.png', ['alt' => 'rating']) . '</li>';
            $x++;
        }

        $star .= '</ul>';

        return $star;
    }

    function formatBytes($bytes, $precision = 2) {
        $units = array('B', 'KB', 'MB', 'GB', 'TB');

        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        return round($bytes, $precision) . ' ' . $units[$pow];
    }

}

?>