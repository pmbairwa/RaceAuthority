<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Cake\Auth\DefaultPasswordHasher;

/**
 * User Entity
 *
 * @property int $id
 * @property int $account_type_id
 * @property string $first_name
 * @property string $last_name
 * @property \Cake\I18n\Time $dob
 * @property string $gender
 * @property string $mobile
 * @property int $location_id
 * @property string $email
 * @property string $username
 * @property string $password
 * @property string $profile_photo
 * @property int $login_count
 * @property bool $status
 * @property bool $verified
 * @property \Cake\I18n\Time $created
 * @property \Cake\I18n\Time $modified
 *
 * @property \App\Model\Entity\AccountType $account_type
 * @property \App\Model\Entity\Location $location
 * @property \App\Model\Entity\Booking[] $bookings
 * @property \App\Model\Entity\Schedule[] $schedules
 * @property \App\Model\Entity\SocialProfile[] $social_profiles
 * @property \App\Model\Entity\TimeSlot[] $time_slots
 * @property \App\Model\Entity\UserToken[] $user_tokens
 * @property \App\Model\Entity\UsersDocument[] $users_documents
 * @property \App\Model\Entity\Service[] $services
 */
class TemporaryRecord extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
        'id' => false
    ];

    /**
     * Fields that are excluded from JSON versions of the entity.
     *
     * @var array
     */
    
    
}
