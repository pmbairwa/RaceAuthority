<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Order Entity
 *
 * @property int $id
 * @property int $user_id
 * @property int $no_of_items
 * @property float $total_price
 * @property int $is_paid
 * @property string $order_json
 * @property int $user_address_id
 * @property int $order_status
 * @property string $order_code
 * @property string $coupon_code
 * @property float $discount_price
 * @property float $shipping_cost
 * @property string $transaction_id
 * @property bool $is_delete
 * @property int $is_guest
 * @property int $order_source
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 *
 * @property \App\Model\Entity\User $user
 * @property \App\Model\Entity\UserAddress $user_address
 * @property \App\Model\Entity\SellerOrder[] $seller_orders
 */
class Order extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
        'id' => false
    ];
}
