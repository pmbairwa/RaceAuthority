<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * User Entity
 *
 * @property int $id
 * @property int $account_type_id
 * @property string $auth_token
 * @property string $device_type
 * @property string $unique_key
 * @property string $verification_code
 * @property string $reset_key
 * @property string $login_by
 * @property string $first_name
 * @property string $last_name
 * @property string $address_1
 * @property string $address_2
 * @property string $phone
 * @property string $email
 * @property string $postcode
 * @property string $city
 * @property string $state
 * @property int $country_id
 * @property string $password
 * @property string $profile_photo
 * @property int $login_count
 * @property bool $status
 * @property bool $verified
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 *
 * @property \App\Model\Entity\AccountType $account_type
 * @property \App\Model\Entity\Country $country
 * @property \App\Model\Entity\Order[] $orders
 * @property \App\Model\Entity\Review[] $reviews
 * @property \App\Model\Entity\SavedCard[] $saved_cards
 * @property \App\Model\Entity\ShippingMethod[] $shipping_methods
 * @property \App\Model\Entity\StripeCustomer[] $stripe_customers
 * @property \App\Model\Entity\UserAddress[] $user_addresses
 * @property \App\Model\Entity\UserToken[] $user_tokens
 * @property \App\Model\Entity\WpComment[] $wp_comments
 * @property \App\Model\Entity\WpUsermetum[] $wp_usermeta
 */
class User extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
        'id' => false
    ];

    /**
     * Fields that are excluded from JSON versions of the entity.
     *
     * @var array
     */
    protected $_hidden = [
        'password'
    ];
}
