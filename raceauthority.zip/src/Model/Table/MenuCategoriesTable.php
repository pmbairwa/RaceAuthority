<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Filesystem\File;
use Cake\ORM\TableRegistry;

/**
 * MenuCategories Model
 *
 * @property \App\Model\Table\RestaurantsTable|\Cake\ORM\Association\BelongsTo $Restaurants
 * @property \App\Model\Table\MenuCategoriesTable|\Cake\ORM\Association\BelongsTo $ParentMenuCategories
 * @property \App\Model\Table\MenuCategoriesTable|\Cake\ORM\Association\HasMany $ChildMenuCategories
 *
 * @method \App\Model\Entity\MenuCategory get($primaryKey, $options = [])
 * @method \App\Model\Entity\MenuCategory newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\MenuCategory[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\MenuCategory|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\MenuCategory patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\MenuCategory[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\MenuCategory findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 * @mixin \Cake\ORM\Behavior\TreeBehavior
 */
class MenuCategoriesTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);
        $this->_dir = 'img' . DS . 'uploads' . DS . 'menu_categories' . DS . 'photos' . DS;
        $this->setTable('menu_categories');
        $this->setDisplayField('title');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');        
        
        $this->addBehavior('Upload', [
            'fields' => [
                'image' => [
                    'path' => $this->_dir . ':name'
                ]
            ]
        ]);

        $this->belongsTo('Restaurants', [
            'foreignKey' => 'restaurant_id',
            'joinType' => 'INNER'
        ]);        
        $this->hasMany('Menus', [
            'className' => 'Menus',
            'foreignKey' => 'menu_category_id'
        ]);        
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');     

        $validator
            ->requirePresence('title', 'create')
            ->notEmpty('title');
        
        $validator
            ->requirePresence('restaurant_id', 'create')
            ->notEmpty('restaurant_id');

        $validator
            ->integer('status')
            ->requirePresence('status', 'create')
            ->notEmpty('status');
        
        $validator                
                ->allowEmpty('image_file')
                ->add('image_file', [
                    'fileSize' => [
                        'rule' => ['fileSize', '<=', '5mb'],
                        'last' => true,
                        'message' => __('Wrong file size. File size must be below 500 kb.')
                    ],
                    'validExtension' => [
                        'rule' => ['extension', ['gif', 'jpeg', 'png', 'jpg']], // default  ['gif', 'jpeg', 'png', 'jpg']
                        'message' => __('These files extension are allowed: .jpeg, .jpg, .gif, .png')
                    ]
        ]);

        return $validator;
    }   
    
    public function findCommon(Query $query, array $options) {
        $searchKeyword = $options['searchKeyword'];

        if (isset($searchKeyword['status']) && $searchKeyword['status'] != "") {
            $query->where(['MenuCategories.status' => $searchKeyword['status']]);
        } 
        
        if (isset($searchKeyword['keyword']) && !empty($searchKeyword['keyword'])) {
            $query->where(['OR' => [['MenuCategories.title LIKE' => '%' . trim($searchKeyword['keyword']) . '%'], ['Restaurants.title LIKE' => '%' . trim($searchKeyword['keyword']) . '%']]]);
        }   
        
        if (isset($searchKeyword['title']) && !empty($searchKeyword['title'])) {
            $query->where(['OR' => [['MenuCategories.title LIKE' => '%' . trim($searchKeyword['title']) . '%']]]);
        } 
        
        return $query;
    }
    
    
    /**
     * getParentLocationsList method
     *
     * @param string $id The record id to get parent records
     * @param type $options Options Array
     * @return array key value pair of parent records
     */
    public function getParentCategoriesList($id = null) {
        $records = [];
        if (!empty($id)) {
            $parents = $this->find('path', ['for' => $id])
                    ->select(['id', 'title'])                   
                    ->toArray();     
            if (!empty($parents)) {
                foreach ($parents as $parent) {
                    $records[$parent->id] = $parent->title;
                }
            }
        }
        return $records;
    }
    
 
    public function getAllChildIdsList($id = null) {
        $records = [];
        $_cids = false;
        if (!empty($id)) {
            $childrens = $this->find('children', ['for' => $id])
                    ->find('threaded')
                    ->toArray();
            $childIds = [];
            if (!empty($childrens)) {
                foreach ($childrens as $child) {
                    if (!empty($child['children']))
                        $childIds[$child['id']] = $this->child_ids($child['children']);
                    else
                        $childIds[$child['id']] = $child['id'];
                }
            }
            $narr = array();
            $_cids = $this->allIds($childIds, $narr);
        }
        return $_cids;
    }

    private function child_ids($data) {
        $childIds = array();
        foreach ($data as $child) {

            if (!empty($child['children'])) {
                $childIds[$child['id']] = $this->child_ids($child['children']);
            } else {
                $childIds[$child['id']] = $child['id'];
            }
        }
        return $childIds;
    }

    function allIds($arr, &$out) {
        if (is_array($arr)) {
            foreach ($arr as $k => $value) {
                if (is_array($value)) {
                    $this->allIds($value, $out);
                } else {
                    $out[] = $value;
                }
            }
        }
        return $out;
    }
    
     public function deleteImage($image = '', $record = null) {
        if (!empty($image)) {
            $file = new File($this->_dir . $image, false);
            if ($file->exists()) {
                $file->delete();
            }
        }
        if (!empty($banner)) {
            $banner->image = '';
            return $this->save($banner);
        }
        return true;
    }
}
