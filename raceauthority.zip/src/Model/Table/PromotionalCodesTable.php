<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * PromotionalCodes Model
 *
 * @property \App\Model\Table\SalonsTable|\Cake\ORM\Association\BelongsTo $Salons
 *
 * @method \App\Model\Entity\PromotionalCode get($primaryKey, $options = [])
 * @method \App\Model\Entity\PromotionalCode newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\PromotionalCode[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\PromotionalCode|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\PromotionalCode patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\PromotionalCode[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\PromotionalCode findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class PromotionalCodesTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('promotional_codes');
        $this->setDisplayField('title');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Salons', [
            'foreignKey' => 'salon_id',
            'joinType' => 'INNER'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');
        
        $validator
            ->integer('salon_id')
            ->notEmpty('salon_id', 'create');

        $validator
            ->requirePresence('title', 'create')
            ->notEmpty('title');        

        $validator
            ->requirePresence('type', 'create')
            ->notEmpty('type');

        $validator
            ->numeric('value')
            ->requirePresence('value', 'create')
            ->notEmpty('value');

        $validator
            ->requirePresence('code', 'create')
            ->notEmpty('code');

        $validator
            ->numeric('min_cart_value')
            ->requirePresence('min_cart_value', 'create')
            ->notEmpty('min_cart_value');

        $validator            
            ->requirePresence('start_date', 'create')
            ->notEmpty('start_date');

        $validator            
            ->requirePresence('end_date', 'create')
            ->notEmpty('end_date');

        $validator
            ->boolean('status')
            ->requirePresence('status', 'create')
            ->notEmpty('status');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['salon_id'], 'Salons'));

        return $rules;
    }
}
