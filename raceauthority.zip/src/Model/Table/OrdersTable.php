<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Orders Model
 *
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 * @property \App\Model\Table\UserAddressesTable|\Cake\ORM\Association\BelongsTo $UserAddresses
 * @property |\Cake\ORM\Association\BelongsTo $Transactions
 * @property \App\Model\Table\SellerOrdersTable|\Cake\ORM\Association\HasMany $SellerOrders
 *
 * @method \App\Model\Entity\Order get($primaryKey, $options = [])
 * @method \App\Model\Entity\Order newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Order[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Order|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Order patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Order[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Order findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class OrdersTable extends Table {

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config) {
        parent::initialize($config);

        $this->setTable('orders');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('UserAddresses', [
            'foreignKey' => 'user_address_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Transactions', [
            'foreignKey' => 'transaction_id',
            'joinType' => 'INNER'
        ]);
        $this->hasMany('SellerOrders', [
            'foreignKey' => 'order_id'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator) {
        $validator
                ->integer('id')
                ->allowEmpty('id', 'create');

        $validator
                ->integer('no_of_items')
                ->requirePresence('no_of_items', 'create')
                ->notEmpty('no_of_items');

        $validator
                ->numeric('total_price')
                ->requirePresence('total_price', 'create')
                ->notEmpty('total_price');

        $validator
                ->integer('is_paid')
                ->requirePresence('is_paid', 'create')
                ->notEmpty('is_paid');

        $validator
                ->requirePresence('order_json', 'create')
                ->notEmpty('order_json');

        $validator
                ->integer('order_status')
                ->requirePresence('order_status', 'create')
                ->notEmpty('order_status');

        $validator
                ->requirePresence('order_code', 'create')
                ->notEmpty('order_code');

        $validator
                ->requirePresence('coupon_code', 'create')
                ->notEmpty('coupon_code');

        $validator
                ->decimal('discount_price')
                ->requirePresence('discount_price', 'create')
                ->notEmpty('discount_price');

        $validator
                ->decimal('shipping_cost')
                ->requirePresence('shipping_cost', 'create')
                ->notEmpty('shipping_cost');

        $validator
                ->boolean('is_delete')
                ->requirePresence('is_delete', 'create')
                ->notEmpty('is_delete');

        $validator
                ->integer('is_guest')
                ->requirePresence('is_guest', 'create')
                ->notEmpty('is_guest');

        $validator
                ->integer('order_source')
                ->requirePresence('order_source', 'create')
                ->notEmpty('order_source');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules) {
        $rules->add($rules->existsIn(['user_id'], 'Users'));
        $rules->add($rules->existsIn(['user_address_id'], 'UserAddresses'));
        $rules->add($rules->existsIn(['transaction_id'], 'Transactions'));

        return $rules;
    }

}
