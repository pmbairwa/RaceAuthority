<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Symfony\Component\Yaml\Yaml;
use Cake\Event\Event;
use ArrayObject;
use Cake\Filesystem\File;
use Cake\Core\Configure;
use Cake\ORM\Entity;
use Cake\Datasource\EntityInterface;

/**
 * Settings Model
 *
 * @method \App\Model\Entity\Setting get($primaryKey, $options = [])
 * @method \App\Model\Entity\Setting newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Setting[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Setting|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Setting patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Setting[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Setting findOrCreate($search, callable $callback = null)
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class SettingsTable extends Table {

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public $_dir;

    public function initialize(array $config) {
        parent::initialize($config);
        $this->_dir = 'img' . DS . 'uploads' . DS . 'settings' . DS;
        $this->table('settings');
        $this->displayField('id');
        $this->primaryKey('id');

        $this->addBehavior('Timestamp');

        $this->addBehavior('Upload', [
            'fields' => [
                'config_value' => [
                    'path' => $this->_dir . ':name'
                ]
            ]
                ]
        );
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator) {
        $validator
                ->integer('id')
                ->allowEmpty('id', 'create');

        $validator
                ->requirePresence('config_name', 'create')
                ->notEmpty('config_name');

        $validator
                ->requirePresence('config_key', 'create')
                ->notEmpty('config_key');

        $validator
                ->allowEmpty('config_value');


        return $validator;
    }

    public function afterSave(Event $event, EntityInterface $entity, ArrayObject $options) {
//        if($entity->isNew()){
//            die("new");
//        }else{
//            die("old");
//        }       
        $this->yamlParse();
    }

    public function afterDelete(Event $event, EntityInterface $entity, ArrayObject $options) {
        $this->yamlParse();
    }

    public function yamlParse() {
        $conditions = ['OR' => [['manager IS' => NULL], ['manager' => 'social'], ['manager' => 'options'], ['manager' => 'smtp'], ['manager' => 'theme']]];
        $lists = $this->find('list', ['keyField' => 'config_key', 'valueField' => 'config_value'])->where($conditions)->order(['config_key' => 'ASC'])->toArray();
        $listYaml = Yaml::dump($lists, 4, 60);
        $filePath = ROOT . DS . 'config' . DS . 'settings.yml';
        $file = new File($filePath, true);
        $file->write($listYaml);
    }

    /**
     * This general function is a 'finder' to use in the searching and get all general config settings
     *
     * @param \Cake\ORM\Query; $query The rules object to be modified.
     * @param type $options Options Array
     * @return \Cake\ORM\Query
     */
    public function findGeneral(Query $query, array $options) {
        $searchKeyword = $options['searchKeyword'];
        //pr($searchKeyword);die;
        $query->where(['Settings.manager IS' => NULL]);
        if (!empty($searchKeyword['keyword']) && trim($searchKeyword['keyword'])) {
            $conditions[] = ['OR' => [['Settings.config_name LIKE' => '%' . trim($searchKeyword['keyword']) . '%'], ['Settings.config_key LIKE' => '%' . trim($searchKeyword['keyword']) . '%'], ['Settings.config_value LIKE' => '%' . trim($searchKeyword['keyword']) . '%']]];
            $query->where($conditions);
        }
        return $query;
    }

    public function deleteImage($image = '', $record = null) {
        if (!empty($image)) {
            $file = new File($this->_dir . $image, false);
            if ($file->exists()) {
                $file->delete();
            }
        }
        if (!empty($record)) {
            $record->image = '';
            return $this->save($record);
        }
        return true;
    }

    /**
     * This function returns all the settings available(from db/cache)
     * @return array key-value pair of all the settings
     */
    public function getAllSettings() {
        return $this->find('list', ['keyField' => 'config_key', 'valueField' => 'config_value'])->toArray();
    }

}
