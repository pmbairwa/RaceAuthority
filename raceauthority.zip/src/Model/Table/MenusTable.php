<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Filesystem\File;
use Cake\ORM\TableRegistry;

/**
 * Menus Model
 *
 * @property \App\Model\Table\RestaurantsTable|\Cake\ORM\Association\BelongsTo $Restaurants
 * @property \App\Model\Table\MenuCategoriesTable|\Cake\ORM\Association\BelongsTo $MenuCategories
 * @property \App\Model\Table\MenuExtrasTable|\Cake\ORM\Association\HasMany $MenuExtras
 *
 * @method \App\Model\Entity\Menu get($primaryKey, $options = [])
 * @method \App\Model\Entity\Menu newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Menu[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Menu|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Menu patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Menu[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Menu findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class MenusTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);
        $this->_dir = 'img' . DS . 'uploads' . DS . 'menus' . DS . 'photos' . DS;
        $this->setTable('menus');
        $this->setDisplayField('title');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Restaurants', [
            'foreignKey' => 'restaurant_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('MenuCategories', [
            'foreignKey' => 'menu_category_id',
            'joinType' => 'INNER'
        ]);
        $this->hasMany('MenuExtras', [
            'foreignKey' => 'menu_id'
        ]);
        $this->hasMany('MenuAttributes', [
            'foreignKey' => 'menu_id'
        ]);
        $this->hasMany('PackageMenus', [
            'foreignKey' => 'menu_id'
        ]);
        $this->addBehavior('Upload', [
            'fields' => [
                'image' => [
                    'path' => $this->_dir . ':name'
                ]
            ]
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');
        
        $validator
            ->requirePresence('restaurant_id', 'create')
            ->notEmpty('restaurant_id');
        
        $validator
            ->requirePresence('menu_category_id', 'create')
            ->notEmpty('menu_category_id');

        $validator
            ->requirePresence('title', 'create')
            ->notEmpty('title');

        $validator            
            ->requirePresence('price', 'create')
            ->notEmpty('price');   

        $validator
            ->boolean('menu_type')
            ->requirePresence('menu_type', 'create')
            ->notEmpty('menu_type');

        $validator
            ->boolean('status')
            ->requirePresence('status', 'create')
            ->notEmpty('status');
        
        $validator                
                ->allowEmpty('image_file')
                ->add('image_file', [
                    'fileSize' => [
                        'rule' => ['fileSize', '<=', '5mb'],
                        'last' => true,
                        'message' => __('Wrong file size. File size must be below 500 kb.')
                    ],
                    'validExtension' => [
                        'rule' => ['extension', ['gif', 'jpeg', 'png', 'jpg']], // default  ['gif', 'jpeg', 'png', 'jpg']
                        'message' => __('These files extension are allowed: .jpeg, .jpg, .gif, .png')
                    ]
        ]);

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['restaurant_id'], 'Restaurants'));
        $rules->add($rules->existsIn(['menu_category_id'], 'MenuCategories'));

        return $rules;
    }
    
    public function findCommon(Query $query, array $options) {
        $searchKeyword = $options['searchKeyword'];

        if (isset($searchKeyword['status']) && $searchKeyword['status'] != "") {
            $query->where(['Menus.status' => $searchKeyword['status']]);
        } 
        
        if (isset($searchKeyword['keyword']) && !empty($searchKeyword['keyword'])) {
            $query->where(['OR' => [['Menus.title LIKE' => '%' . trim($searchKeyword['keyword']) . '%'],['Restaurants.title LIKE' => '%' . trim($searchKeyword['keyword']) . '%'], ['MenuCategories.title LIKE' => '%' . trim($searchKeyword['keyword']) . '%']]]);
        }    
        
        if (isset($searchKeyword['title']) && !empty($searchKeyword['title'])) {
            $query->where(['OR' => [['Menus.title LIKE' => '%' . trim($searchKeyword['title']) . '%'], ['MenuCategories.title LIKE' => '%' . trim($searchKeyword['title']) . '%']]]);
        }  
        
        return $query;
    }
    
    public function deleteImage($image = '', $record = null) {
        if (!empty($image)) {
            $file = new File($this->_dir . $image, false);
            if ($file->exists()) {
                $file->delete();
            }
        }
        if (!empty($banner)) {
            $banner->image = '';
            return $this->save($banner);
        }
        return true;
    }
}
