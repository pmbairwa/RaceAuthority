<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Event\Event;
use Cake\Filesystem\File;

/**
 * Cmspages Model
 *
 * @method \App\Model\Entity\Cmspage get($primaryKey, $options = [])
 * @method \App\Model\Entity\Cmspage newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Cmspage[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Cmspage|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Cmspage patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Cmspage[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Cmspage findOrCreate($search, callable $callback = null)
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class CmspagesTable extends Table {

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public $_dir;

    public function initialize(array $config) {
        parent::initialize($config);
        $this->_dir = 'img' . DS . 'uploads' . DS . 'pages' . DS;
        $this->table('cmspages');
        $this->displayField('title');
        $this->primaryKey('id');

        $this->addBehavior('Timestamp');

        $this->addBehavior('Upload', [
            'fields' => [
                    'image' => [
                        'path' => $this->_dir . ':name'
                    ]
            ]
        ]
        );
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator) {
        $validator
                ->integer('id')
                ->allowEmpty('id', 'create');
        $validator
                ->requirePresence('title', 'create')
                ->notEmpty('title');
        $validator
                ->requirePresence('description', 'create')
                ->notEmpty('description');
        $validator
                //->requirePresence('image_file', 'create')
                //->allowEmpty('image_file','update')
                ->allowEmpty('image_file')
                ->add('image_file', [
                    'fileSize' => [
                        'rule' => ['fileSize', '<=', '500kb'],
                        'last' => true,
                        'message' => __('Wrong file size. File size must be below 500 kb.')
                    ],
                    'validExtension' => [
                        'rule' => ['extension', ['gif', 'jpeg', 'png', 'jpg']], // default  ['gif', 'jpeg', 'png', 'jpg']
                        'message' => __('These files extension are allowed: .jpeg, .jpg, .gif, .png')
                    ]
        ]);
        $validator
                ->boolean('status')
                ->requirePresence('status', 'create')
                ->notEmpty('status');
        return $validator;
    }

    /**
     * This common function is a 'finder' to use in the Index pages searching
     *
     * @param \Cake\ORM\Query; $query The rules object to be modified.
     * @param type $options Options Array
     * @return \Cake\ORM\Query
     */
    public function findCommon(Query $query, array $options) {
        $searchKeyword = $options['searchKeyword'];
        if (!empty($searchKeyword['keyword']) && trim($searchKeyword['keyword'])) {
            $query->where(['title LIKE ' => '%' . trim($searchKeyword['keyword']) . '%']);
            $query->orWhere(['short_description LIKE ' => '%' . trim($searchKeyword['keyword']) . '%']);
        }
        return $query;
    }

    public function deleteImage($image = '', $record = null) {
        if (!empty($image)) {
            $file = new File($this->_dir . $image, false);
            if ($file->exists()) {
                $file->delete();
            }
        }
        if (!empty($record)) {
            $record->image = '';
            return $this->save($record);
        }
        return true;
    }

}
