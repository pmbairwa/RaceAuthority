<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * EmailTemplates Model
 *
 */
class EmailTemplatesTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->table('email_templates');
        $this->displayField('title');
        $this->primaryKey('id');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        
        $validator
                ->notEmpty('email_type', 'email type is required')
                ->requirePresence('email_type', 'create')
                ->add('email_type', [
                    'unique' => ['rule' => 'validateUnique', 'message' => 'The email type is already taken.', 'provider' => 'table']
        ]);

        $validator
            ->requirePresence('subject', 'create')
            ->notEmpty('subject');

       

        $validator
            ->requirePresence('description', 'create')
            ->notEmpty('description');


        return $validator;
    }

    /**
     * This common function is a 'finder' to use in the Index pages searching
     *
     * @param \Cake\ORM\Query; $query The rules object to be modified.
     * @param type $options Options Array
     * @return \Cake\ORM\Query
     */
    public function findCommon(Query $query, array $options) {
        $searchKeyword = $options['searchKeyword'];
        if (!empty($searchKeyword['keyword']) && trim($searchKeyword['keyword'])) {
            $query->where(['email_type LIKE ' => '%' . trim($searchKeyword['keyword']) . '%']);
            $query->orWhere(['subject LIKE ' => '%' . trim($searchKeyword['keyword']) . '%']);
        }
        return $query;
    }
}
