<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Filesystem\File;
use Cake\ORM\TableRegistry;

/**
 * Salons Model
 *
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 * @property \App\Model\Table\SalonWorkDaysTable|\Cake\ORM\Association\HasMany $SalonWorkDays
 *
 * @method \App\Model\Entity\Salon get($primaryKey, $options = [])
 * @method \App\Model\Entity\Salon newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Salon[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Salon|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Salon patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Salon[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Salon findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class BookingsTable extends Table {

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config) {
        parent::initialize($config);
        $this->_dir = 'img' . DS . 'uploads' . DS . 'salons' . DS . 'photos' . DS;
        $this->setTable('bookings');
        $this->setDisplayField('title');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('SalonStaffs', [
            'foreignKey' => 'salon_staff_id',
            'joinType' => 'INNER'
        ]);
//        $this->belongsTo('Salons', [
//            'foreignKey' => 'salon_id',
//            'joinType' => 'INNER'
//        ]);
        $this->hasMany('BookingDetails', [
            'foreignKey' => 'booking_id'
        ]);
//        
        $this->hasMany('SalonStaffs', [
            'foreignKey' => 'salon_id'
        ]);
//        $this->hasMany('SalonServices', [
//            'foreignKey' => 'salon_id'
//        ]);
//        
//        $this->hasOne('OrderCosts', [
//            'foreignKey' => 'salon_id'
//        ]);
//        $this->addBehavior('Upload', [
//            'fields' => [
//                'image' => [
//                    'path' => $this->_dir . ':name'
//                ],
//                'banner' => [
//                    'path' => $this->_dir . ':name'
//                ]
//            ]
//        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator) {
        $validator
                ->integer('id')
                ->allowEmpty('id', 'create');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules) {
        $rules->add($rules->existsIn(['user_id'], 'Users'));

        return $rules;
    }

    public function findCommon(Query $query, array $options) {
        $searchKeyword = $options['searchKeyword'];

        if (isset($searchKeyword['status']) && $searchKeyword['status'] != "") {
            $query->where(['Salons.status' => $searchKeyword['status']]);
        }

        if (isset($searchKeyword['keyword']) && !empty($searchKeyword['keyword'])) {
            $query->where(['OR' => [['Salons.title LIKE' => '%' . trim($searchKeyword['keyword']) . '%'], ['CONCAT(first_name," ", last_name) LIKE' => '%' . trim($searchKeyword['keyword']) . '%']]]);
        }
        return $query;
    }

    public function deleteImage($image = '', $record = null) {
        if (!empty($image)) {
            $file = new File($this->_dir . $image, false);
            if ($file->exists()) {
                $file->delete();
            }
        }
        if (!empty($banner)) {
            $banner->image = '';
            return $this->save($banner);
        }
        return true;
    }

}
