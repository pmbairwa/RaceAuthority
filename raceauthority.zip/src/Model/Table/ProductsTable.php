<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Products Model
 *
 * @property \App\Model\Table\CategoriesTable|\Cake\ORM\Association\BelongsTo $Categories
 * @property \App\Model\Table\VendorsTable|\Cake\ORM\Association\BelongsTo $Vendors
 * @property \App\Model\Table\ProductAttributesTable|\Cake\ORM\Association\HasMany $ProductAttributes
 * @property \App\Model\Table\ProductImagesTable|\Cake\ORM\Association\HasMany $ProductImages
 * @property \App\Model\Table\ProductTagsTable|\Cake\ORM\Association\HasMany $ProductTags
 * @property \App\Model\Table\ReviewsTable|\Cake\ORM\Association\HasMany $Reviews
 * @property \App\Model\Table\SellerOrdersTable|\Cake\ORM\Association\HasMany $SellerOrders
 *
 * @method \App\Model\Entity\Product get($primaryKey, $options = [])
 * @method \App\Model\Entity\Product newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Product[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Product|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Product patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Product[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Product findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class ProductsTable extends Table {

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config) {
        parent::initialize($config);
        $this->_dir = 'img' . DS . 'uploads' . DS . 'products' . DS;
        $this->setTable('products');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Categories', [
            'foreignKey' => 'category_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Vendors', [
            'foreignKey' => 'vendor_id',
            'joinType' => 'INNER'
        ]);
        $this->hasMany('ProductAttributes', [
            'foreignKey' => 'product_id'
        ]);
//        $this->hasMany('ProductImages', [
//            'foreignKey' => 'foreign_key',
//            'conditions' => [
//                'ProductImages.model' => 'Products',
//                'Images.field' => 'upload'
//            ],
//            'sort' => ['Images.position' => 'ASC']
//        ]);
        $this->hasMany('ProductImages', [
            'foreignKey' => 'product_id'
        ]);
        $this->hasMany('ProductTags', [
            'foreignKey' => 'product_id'
        ]);
        $this->hasMany('Reviews', [
            'foreignKey' => 'product_id'
        ]);
        $this->hasMany('SellerOrders', [
            'foreignKey' => 'product_id'
        ]);
        $this->addBehavior('Upload', [
            'fields' => [
                'image' => [
                    'path' => $this->_dir . ':name'
                ],
            ]
                ]
        );
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator) {
        $validator
                ->integer('id')
                ->allowEmpty('id', 'create');

        $validator
                ->requirePresence('name', 'create')
                ->notEmpty('name');
        $validator
                ->numeric('price')
                ->requirePresence('price', 'create')
                ->notEmpty('price');

//        $validator
//                ->requirePresence('image', 'create')
//                ->notEmpty('image');

        $validator
                ->requirePresence('description', 'create')
                ->notEmpty('description');

        $validator
                ->numeric('regular_price')
                ->requirePresence('regular_price', 'create')
                ->notEmpty('regular_price');

        $validator
                ->integer('stock_quatity')
                ->requirePresence('stock_quatity', 'create')
                ->notEmpty('stock_quatity');

        $validator
                ->integer('status')
                ->requirePresence('status', 'create')
                ->notEmpty('status');

        $validator
                ->requirePresence('image_file', 'create')
                ->notEmpty('image_file')
                ->add('image_file', [
                    'fileSize' => [
                        'rule' => ['fileSize', '<=', '5mb'],
                        'last' => true,
                        'message' => __('Wrong file size. File size must be below 500 kb.')
                    ],
                    'validExtension' => [
                        'rule' => ['extension', ['gif', 'jpeg', 'png', 'jpg']], // default  ['gif', 'jpeg', 'png', 'jpg']
                        'message' => __('These files extension are allowed: .jpeg, .jpg, .gif, .png')
                    ]
        ]);
//        $validator
//                ->requirePresence('ProductImages.banner_file', 'create')
//                ->notEmpty('banner_file')
//                ->add('banner_file', [
//                    'fileSize' => [
//                        'rule' => ['fileSize', '<=', '5mb'],
//                        'last' => true,
//                        'message' => __('Wrong file size. File size must be below 500 kb.')
//                    ],
//                    'validExtension' => [
//                        'rule' => ['extension', ['gif', 'jpeg', 'png', 'jpg']], // default  ['gif', 'jpeg', 'png', 'jpg']
//                        'message' => __('These files extension are allowed: .jpeg, .jpg, .gif, .png')
//                    ]
//        ]);


        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules) {
        $rules->add($rules->existsIn(['category_id'], 'Categories'));
        $rules->add($rules->existsIn(['vendor_id'], 'Vendors'));

        return $rules;
    }

}
