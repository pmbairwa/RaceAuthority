<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Event\Event;
use ArrayObject;
use Cake\Filesystem\File;

/**
 * AdminUsers Model
 *
 * @property \Cake\ORM\Association\BelongsTo $Roles
 *
 * @method \App\Model\Entity\AdminUser get($primaryKey, $options = [])
 * @method \App\Model\Entity\AdminUser newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\AdminUser[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\AdminUser|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\AdminUser patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\AdminUser[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\AdminUser findOrCreate($search, callable $callback = null)
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class AdminUsersTable extends Table {

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public $_dir;

    public function initialize(array $config) {
        parent::initialize($config);
        $this->_dir = 'img' . DS . 'uploads' . DS . 'admin_users' . DS . 'photos' . DS;
        $this->table('admin_users');
        $this->displayField('id');
        $this->primaryKey('id');

        $this->addBehavior('Timestamp');
        
        $this->addBehavior('Upload', [
            'fields' => [
                'profile_photo' => [
                    'path' => $this->_dir . ':name'
                ]
            ]
                ]
        );
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator) {
        $validator
                ->requirePresence('first_name', 'create')
                ->notEmpty('first_name')
                ->add('name', [
                    'length' => [
                        'rule' => ['minLength', 3],
                        'message' => 'Name need to be at least 3 characters long',
                    ]
        ]);

        $validator
                ->requirePresence('role_id', 'create')
                ->notEmpty('role_id');
        
        $validator                
                ->allowEmpty('mobile')
                ->add('mobile',[
                    'numeric'=>[
                        'message'=>'Plese enter valid phone number.',
                        'rule'=>'numeric'
                    ]
                ]);


        $validator
                ->notEmpty('email', 'An email is required')
                ->add('email', 'validFormat', [
                    'rule' => 'email',
                    'message' => 'You must provide a valid email'
                ])
                ->add('email', [
                    'emailUnique' => [
                        'message' => 'The email is already taken.',
                        'rule' => 'validateUnique', 'provider' => 'table'
                    ]
        ]);   
                
        $validator
                ->requirePresence('password', 'create')
                ->notEmpty('password', 'A password is required', 'create')
                ->add('password', [
                    'minLength' => [
                        'rule' => ['minLength', 6],
                        'message' => 'Your password must be at least 6 characters long.'
                    ],
                    'maxLength' => [
                        'rule' => ['maxLength', 15],
                        'message' => 'Password is too long. The limit is 15 characters.'
                    ],
                    'custom' => [
                        'rule' => function($value, $context) {
                            if (preg_match('/^(?=.*[a-zA-Z_@&+-])(?=.*\d)([0-9a-zA-Z_@&+-]+)$/', $context['data']['password']) && preg_match('/[A-Z]/', $context['data']['password']) && preg_match('/[a-z]/', $context['data']['password'])&& preg_match('/[!@#$%^&*()\-_=+{};:,<.>]/', $context['data']['password'])) {
                                return true;
                            } else {
                                return false;
                            }
                        },
                        'on' => function($context) {
                            return !empty($context['data']['password']);
                        },
                        'message' => 'Password must contain at least one small, one capital alphabet, one numeric digit and one special character.'
                    ]
                ]);
        $validator                        
                ->requirePresence('confirm_password', 'create')
                ->notEmpty('confirm_password', 'Your must confirm your password', 'create')
                ->add('confirm_password', [
                    'custom' => [
                        'rule' => function($value, $context) {
                            if ($context['data']['password'] != "") {
                                return ($value == $context['data']['password']);
                            } else {
                                return true;
                            }
                        },
                        'on' => function($context) {
                            return !empty($context['data']['password']);
                        },
                        'message' => 'Your confirm password must match with your password'
                    ]
        ]);

        $validator
                ->requirePresence('profile_photo_file', 'create')
                //->allowEmpty('profile_photo_file','update')
                ->allowEmpty('profile_photo_file')
                ->add('profile_photo_file', [
                    'fileSize' => [
                        'rule' => ['fileSize', '<=', '5mb'],
                        'last' => true,
                        'message' => __('Wrong file size. File size must be below 500 kb.')
                    ],
                    'validExtension' => [
                        'rule' => ['extension', ['gif', 'jpeg', 'png', 'jpg']], // default  ['gif', 'jpeg', 'png', 'jpg']
                        'message' => __('These files extension are allowed: .jpeg, .jpg, .gif, .png')
                    ]
        ]);

        $validator
                ->integer('status')
                ->allowEmpty('status');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules) {
        $rules->add($rules->isUnique(['email']),['message' => 'This Email is already in used.']); 
        return $rules;
    }

    public function findAuth(\Cake\ORM\Query $query, array $options) {
        $query
                ->select(['AdminUsers.id', 'AdminUsers.first_name', 'AdminUsers.last_name', 'AdminUsers.dob', 'AdminUsers.email',  'AdminUsers.password', 'AdminUsers.role_id', 'AdminUsers.profile_photo', 'AdminUsers.status', 'AdminUsers.login_count', 'AdminUsers.created'])
                ->where(['AdminUsers.status' => 1]);
        // dump($query->first());die;
        return $query;
    }

    public function beforeMarshal(Event $event, ArrayObject $data) {
        $trim_ar = ['first_name', 'last_name', 'email', 'password'];
        foreach ($data as $key => $value) {
            if (in_array($key, $trim_ar)) {
                $data[$key] = trim($value);
            }
        };
    }

    public function deleteImage($image = '', $record = null) {
        if (!empty($image)) {
            $file = new File($this->_dir . $image, false);
            if ($file->exists()) {
                $file->delete();
            }
        }
        if (!empty($record)) {
            $record->profile_photo = '';
            return $this->save($record);
        }
        return true;
    }

}
