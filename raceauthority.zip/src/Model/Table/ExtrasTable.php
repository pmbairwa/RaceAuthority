<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Extras Model
 *
 * @property \App\Model\Table\RestaurantsTable|\Cake\ORM\Association\BelongsTo $Restaurants
 * @property \App\Model\Table\ExtrasTable|\Cake\ORM\Association\BelongsTo $ParentExtras
 * @property \App\Model\Table\ExtrasTable|\Cake\ORM\Association\HasMany $ChildExtras
 * @property \App\Model\Table\MenuExtrasTable|\Cake\ORM\Association\HasMany $MenuExtras
 *
 * @method \App\Model\Entity\Extra get($primaryKey, $options = [])
 * @method \App\Model\Entity\Extra newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Extra[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Extra|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Extra patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Extra[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Extra findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 * @mixin \Cake\ORM\Behavior\TreeBehavior
 */
class ExtrasTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('extras');
        $this->setDisplayField('title');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
        $this->addBehavior('Tree');

        $this->belongsTo('Restaurants', [
            'foreignKey' => 'restaurant_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('ParentExtras', [
            'className' => 'Extras',
            'foreignKey' => 'parent_id'
        ]);
        $this->hasMany('ChildExtras', [
            'className' => 'Extras',
            'foreignKey' => 'parent_id'
        ]);
        $this->hasMany('MenuExtras', [
            'foreignKey' => 'extra_id'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->requirePresence('title', 'create')
            ->notEmpty('title');
        
        $validator
            ->integer('restaurant_id')
            ->requirePresence('restaurant_id', 'create')
            ->notEmpty('restaurant_id');  

        $validator
            ->boolean('status')
            ->requirePresence('status', 'create')
            ->notEmpty('status');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['restaurant_id'], 'Restaurants'));        

        return $rules;
    }
    
    public function getParentExtrasList($id = null) {
        $records = [];
        if (!empty($id)) {
            $parents = $this->find('path', ['for' => $id])
                    ->select(['id', 'title'])                   
                    ->toArray();     
            if (!empty($parents)) {
                foreach ($parents as $parent) {
                    $records[$parent->id] = $parent->title;
                }
            }
        }
        return $records;
    }
    
    /**
     * This common function is a 'finder' to use in the Index pages searching
     *
     * @param \Cake\ORM\Query; $query The rules object to be modified.
     * @param type $options Options Array
     * @return \Cake\ORM\Query
     */
    public function findCommon(Query $query, array $options) {
        $searchKeyword = $options['searchKeyword'];    
        
        if (isset($searchKeyword['status']) && $searchKeyword['status'] != "") {
            $query->where(['Extras.status' => $searchKeyword['status']]);
        }
        
        if (!empty($searchKeyword['keyword']) && trim($searchKeyword['keyword'])) {
            $query->where(['OR' => [['Restaurants.title LIKE' => '%' . trim($searchKeyword['keyword']) . '%'], ['Extras.title LIKE' => '%' . trim($searchKeyword['keyword']) . '%']]]);
        }
        
        if (!empty($searchKeyword['title']) && trim($searchKeyword['title'])) {
            $query->where([[['Extras.title LIKE' => '%' . trim($searchKeyword['title']) . '%']]]);
        }
        
        if (!empty($searchKeyword['parent_id']) && trim($searchKeyword['parent_id']) != "") {
            $_cids = $this->getAllChildIdsList($searchKeyword['parent_id']);            
            if (!empty($_cids)) {
                $_cids[] = $searchKeyword['parent_id'];
                $query->where(['Extras.id IN' => $_cids]);
            } else {
                $query->where(['Extras.id' => $searchKeyword['parent_id']]);
            }
        }
        return $query;
    }
    
    public function getAllChildIdsList($id = null) {
        $records = [];
        $_cids = false;
        if (!empty($id)) {
            $childrens = $this->find('children', ['for' => $id])
                    ->find('threaded')
                    ->toArray();
            $childIds = [];
            if (!empty($childrens)) {
                foreach ($childrens as $child) {
                    if (!empty($child['children']))
                        $childIds[$child['id']] = $this->child_ids($child['children']);
                    else
                        $childIds[$child['id']] = $child['id'];
                }
            }
            $narr = array();
            $_cids = $this->allIds($childIds, $narr);
        }
        return $_cids;
    }

    private function child_ids($data) {
        $childIds = array();
        foreach ($data as $child) {

            if (!empty($child['children'])) {
                $childIds[$child['id']] = $this->child_ids($child['children']);
            } else {
                $childIds[$child['id']] = $child['id'];
            }
        }
        return $childIds;
    }

    function allIds($arr, &$out) {
        if (is_array($arr)) {
            foreach ($arr as $k => $value) {
                if (is_array($value)) {
                    $this->allIds($value, $out);
                } else {
                    $out[] = $value;
                }
            }
        }
        return $out;
    }
}
