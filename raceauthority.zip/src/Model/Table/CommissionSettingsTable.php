<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * CommissionSettings Model
 *
 * @method \App\Model\Entity\CommissionSetting get($primaryKey, $options = [])
 * @method \App\Model\Entity\CommissionSetting newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\CommissionSetting[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\CommissionSetting|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\CommissionSetting patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\CommissionSetting[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\CommissionSetting findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class CommissionSettingsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('commission_settings');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->integer('commission_for')
            ->requirePresence('commission_for', 'create')
            ->notEmpty('commission_for');

        $validator
            ->integer('commission_mode')
            ->requirePresence('commission_mode', 'create')
            ->notEmpty('commission_mode');

        $validator
            ->decimal('commission_cost')
            ->requirePresence('commission_cost', 'create')
            ->notEmpty('commission_cost');

        return $validator;
    }
}
