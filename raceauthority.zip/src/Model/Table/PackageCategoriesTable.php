<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * PackageCategories Model
 *
 * @property \App\Model\Table\PackagesTable|\Cake\ORM\Association\BelongsTo $Packages
 * @property \App\Model\Table\MenuCategoriesTable|\Cake\ORM\Association\BelongsTo $MenuCategories
 * @property \App\Model\Table\PackageCategorieMenusTable|\Cake\ORM\Association\HasMany $PackageCategorieMenus
 *
 * @method \App\Model\Entity\PackageCategory get($primaryKey, $options = [])
 * @method \App\Model\Entity\PackageCategory newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\PackageCategory[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\PackageCategory|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\PackageCategory patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\PackageCategory[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\PackageCategory findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class PackageCategoriesTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('package_categories');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Packages', [
            'foreignKey' => 'package_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('MenuCategories', [
            'foreignKey' => 'menu_category_id',
            'joinType' => 'INNER'
        ]);
        $this->hasMany('PackageCategoryMenus', [
            'foreignKey' => 'package_category_id'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['package_id'], 'Packages'));
        $rules->add($rules->existsIn(['menu_category_id'], 'MenuCategories'));

        return $rules;
    }
}
