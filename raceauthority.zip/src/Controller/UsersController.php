<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Utility\Text;
use Cake\ORM\TableRegistry;
use Cake\Mailer\MailerAwareTrait;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 */
class UsersController extends AppController {

    use MailerAwareTrait;

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Cookie');
        $this->Auth->allow(["register", "verify", "forgot", "verifyAppAccount", "reset", "setpassword"]);
    }

    public function index() {
        return $this->redirect(['controller' => 'Users', 'action' => 'profile']);
    }

    public function verifyAppAccount() {
        $this->viewBuilder()->layout('verifyRequest');
        $title = "Verify Account";
        $email = $this->request->query['email'];
        $key = $this->request->query['key'];
        if (!$email || $email == "" || !$key || $key == "") {
            $this->Flash->error(__('Invalid Request'));
        } else {
            $check_valid_email = $this->Users->find()
                    ->select(['id', 'email', 'verification_code', 'verified'])
                    ->where(['email' => $email])
                    ->first();

            if (!empty($check_valid_email)) {
                if ($check_valid_email['verification_code'] == $key) {
                    if ($check_valid_email['verified'] == 0 || $check_valid_email['verified'] == NULL || $check_valid_email['verified'] == '') {
                        $user = $this->Users->get($check_valid_email['id']);
                        $user->verification_code = NULL;
                        $user->verified = 1;
                        $user->status = 1;
                        if ($this->Users->save($user)) {

                            $this->Flash->success(__('Account has been verified successfully, please login to continue'));
                        }
                    } else
                        $this->Flash->error(__('Your account already verified, please login to continue'));
                } else
                    $this->Flash->error(__('Key is not attached with this email'));
            } else
                $this->Flash->error(__('Email address not registered with us'));
        }
        $this->set(compact('title'));
    }

    public function login() {
        if ($this->Auth->user()) {
            return $this->redirect($this->Auth->redirectUrl());
        }
        if ($this->request->is('post') || $this->request->query('provider')) {
            $user = $this->Auth->identify();
            //dump($user);die;
            if ($user) {
                $this->Auth->setUser($user);
                $incQuery = $this->Users->query();
                $incQuery->update()
                        ->set($incQuery->newExpr('login_count = login_count + 1'))
                        ->where(['id' => $user['id']])
                        ->execute();
                return $this->redirect($this->Auth->redirectUrl());
            } else {

                $this->Flash->error(__('Invalid username or password, try again'));
            }
        } else {
            $logincookie = $this->Cookie->read('_remember');
            if (!empty($logincookie))
                $this->request->data = $logincookie;
        }
    }

    public function register($id = null) {
        if ($this->Auth->user("id")) {
            $user = $this->Users->get($this->Auth->user("id"), [
                'contain' => ['Locations', 'SocialProfiles']
            ]);
        } else {
            $user = $this->Users->newEntity();
        }
        if ($this->request->is(['patch', 'post', 'put'])) {
            $user = $this->Users->patchEntity($user, $this->request->data);
            if ($this->request->data['password'] == "") {
                unset($user->password);
            }

            if ($this->Users->save($user)) {
                if ($user->isNew()) {
                    $this->getMailer('Manu')->send('welcome', [$user]);
                }
                $this->Flash->success(__('You are successfully registered.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The user could not be saved. Please, try again.'));
        }
        $accountTypes = $this->Users->AccountTypes->find('list');
        $institutes = $this->Users->Institutes->find('list');
        $this->set(compact('user', '_dir', 'accountTypes', 'institutes'));
        $this->set('_serialize', ['user']);
    }

    public function profile() {
        $user = $this->Users->get($this->Auth->user("id"), [
            'contain' => ['Locations']
        ]);
        $this->set(compact('user'));
        $this->set('_serialize', ['user']);
    }

    public function verify($token = null) {
        if (!$token) {
            return $this->redirect(['controller' => 'AdminUsers', 'action' => 'login', 'prefix' => 'admin']);
        }

        $UserTokens = TableRegistry::get('UserTokens');
        $query = $UserTokens->find()->select(['id', 'user_id']);
        $query->where(['UserTokens.token' => $token, 'UserTokens.status' => 0, 'UserTokens.user_type' => 'website_users',
            'UserTokens.token_type' => 'registration_verified'])->order(['id' => 'DESC'])->limit(1);
        $res = $query->first();

        if (empty($res)) {
            $this->Flash->error(__('you token has expired.!'));
            return $this->redirect(['controller' => 'AdminUsers', 'action' => 'login', 'prefix' => 'admin']);
        }

        $adminUser = $this->Users->get($res->user_id);
        $adminUser->verified = 1;
        if ($this->Users->save($adminUser)) {
            $tokenq = $UserTokens->query();
            $tokenq->delete()
                    ->where(['id' => $res->id])
                    ->execute();
            $this->Auth->setUser($adminUser);
            $this->Flash->success(__('Your Account has been activated.'));
            return $this->redirect(['controller' => 'AdminUsers', 'action' => 'login', 'prefix' => 'admin']);
        } else {
            $this->Flash->error(__('your process faild. please try again!'));
            return $this->redirect(['controller' => 'Users', 'action' => 'login']);
        }
    }

    public function forgot() {
        $EmailTemplates = TableRegistry::get('EmailTemplates');
        $template = $EmailTemplates->find()->where(['email_type' => 'forgot_password'])->first();
        if ($this->request->is('post')) {
            $uData = $this->Users->find("all", ['conditions' => ['email' => $this->request->data['email'], 'status' => 1]]);
            $uData->select(['Users.id', 'Users.first_name', "Users.last_name",
                "Users.email", "Users.last_name"]);
            $result = $uData->first();
            //dump($result);die;
            if (!empty($result)) {
                $send = $this->getMailer('Manu')->send('forgot', [$result]);
                $this->Flash->success(__('Your password reset link has been sent to your email!'));
                return $this->redirect(['action' => 'login']);
            } else {
                $this->Flash->error(__('This email address does not exist in database.!'));
            }
        }
    }

    public function reset($token = null) {
        if (!$token) {
            return $this->redirect(['controller' => 'Users', 'action' => 'login']);
        }
        $UserTokens = TableRegistry::get('UserTokens');
        $query = $UserTokens->find()->select(['id', 'user_id']);
        $query->where(['UserTokens.token' => $token, 'UserTokens.status' => 0, 'UserTokens.user_type' => 'website_users',
            'UserTokens.token_type' => 'forgot'])->order(['id' => 'DESC'])->limit(1);
        $res = $query->first();
        if (empty($res)) {
            $this->Flash->error(__('you token has expired.!'));
            return $this->redirect(['action' => 'forgot']);
        }
        if ($this->request->is('post')) {
            if (empty($this->request->data['password'])) {
                $this->Flash->error(__('password is required.'));
                return;
            }
            if ($this->request->data['password'] != $this->request->data['confirm_password']) {
                $this->Flash->error(__('password didn\'t match. please try again!'));
                return;
            }
            $adminUser = $this->Users->get($res->user_id);
            $adminUser->password = $this->request->data['password'];
            if ($this->Users->save($adminUser)) {
                $tokenq = $UserTokens->query();
                $tokenq->delete()
                        ->where(['id' => $res->id])
                        ->execute();
                $this->Flash->success(__('Your password has changed.'));
                return $this->redirect(['action' => 'login']);
            } else {
                $this->Flash->error(__('your process faild. please try again!'));
            }
        }
    }

    public function logout() {
        return $this->redirect($this->Auth->logout());
    }

    public function setpassword($token = null) {
        $this->viewBuilder()->layout('login');
        if (!$token) {
            //return $this->redirect('/');
        }
        $UserTokens = TableRegistry::get('UserTokens');
        $query = $UserTokens->find()->select(['id', 'user_id']);
        $query->where(['UserTokens.token' => $token, 'UserTokens.status' => 0, 'UserTokens.user_type' => 'website_users', 'UserTokens.token_type' => 'setpassword'])->order(['id' => 'DESC'])->limit(1);
        $res = $query->first();
        if (empty($res)) {
            $this->Flash->error(__('you token has expired.!'));
           // return $this->redirect('/');
        }
        if ($this->request->is('post')) {
            $len = strlen($this->request->data['password']);
            if ($this->request->data['password'] != $this->request->data['confirm_password']) {
                $this->Flash->error(__('password didn\'t match. please try again!'));
                return;
            } elseif ($len < 6) {
                $this->Flash->error(__('Your password must be at least 6 characters long.'));
                return;
            } elseif ($len > 15) {
                $this->Flash->error(__('Password is too long. The limit is 15 characters.'));
                return;
            } elseif (!(preg_match('/^(?=.*[a-zA-Z_@&+-])(?=.*\d)([0-9a-zA-Z_@&+-]+)$/', $this->request->data['password']) && preg_match('/[A-Z]/', $this->request->data['password']) && preg_match('/[a-z]/', $this->request->data['password']) && preg_match('/[!@#$%^&*()\-_=+{};:,<.>]/', $this->request->data['password']))) {
                $this->Flash->error(__('Password must contain at least one small, one capital alphabet, one numeric digit and one special character.'));
                return;
            }
            $User = $this->{$this->modelClass}->get($res->user_id);
            $User->password = $this->request->data['password'];
            $User->verified = 1;
            if ($this->{$this->modelClass}->save($User)) {
                $tokenq = $UserTokens->query();
                $tokenq->delete()
                        ->where(['id' => $res->id])
                        ->execute();
                $this->Flash->success(__('You password has been set successfully to access account.'));
                //return $this->redirect('/');
            } else {
                $this->Flash->error(__('your process faild. please try again!'));
            }
        }
    }

}
