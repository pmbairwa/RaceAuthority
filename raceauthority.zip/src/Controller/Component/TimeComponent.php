<?php

namespace App\Controller\Component;

use Cake\Controller\Component;
use Cake\Controller\ComponentRegistry;
use Cake\Core\Configure;

/**
 * Time component
 */
class TimeComponent extends Component {

    /**
     * Default configuration.
     *
     * @var array
     */
    protected $_defaultConfig = [];

    public function divideSlotsIn12h() {
        $interval = Configure::read("Setting.time_interval") != null ? Configure::read("Setting.time_interval") : 15;
        $intsec = $interval * 60;
        $mins = range(0, 43200, $intsec);
        $duration = [];
        foreach ($mins AS $min) {
            $hours = floor($min / 3600);
            $minutes = floor(($min / 60) % 60);
            $seconds = $min % 60;
            $str = '';
            if ($hours > 0) {
                $str .= $hours . " h ";
                if ($minutes > 0) {
                    $str .= $minutes . " m";
                }
            } else if ($minutes > 0) {
                $str .= $minutes . " m";
            }
            if (!empty($str))
                $duration[$min] = $str;
        }
        return $duration;
    }

    public function daySlots() {
        $interval = Configure::read("Setting.time_interval") != null ? Configure::read("Setting.time_interval") : 15;
        $start = strtotime("00:" . $interval);
        $endtime = date('H:i', strtotime('-' . $interval . ' min 24:00'));
        sscanf($endtime, "%d:%d:%d", $hours, $minutes, $seconds);
        $entstrtime = $hours * 3600 + $minutes * 60 + $seconds;
        $mins = range(0, 86400, ($interval * 60)); //43200 for 12 hours -- 86400 for 24 hours
        $ftim = date('h:i A', strtotime("00:00"));
        $slots["00:00"] = $ftim;
        foreach ($mins AS $min) {
            if ($min < $entstrtime) {
                $time = date('h:i A', $start + $min);
                $time24 = date('H:i', $start + $min);
                $slots[$time24] = $time;
            }
        }
        return $slots;
    }

    public function daySlotsBetween($start, $end) {
        $interval = Configure::read("Setting.time_interval") != null ? Configure::read("Setting.time_interval") : 15;
        $period = new \DatePeriod(
                new \DateTime($start), 
                new \DateInterval('PT' . $interval . 'M'), 
                new \DateTime($end)
        );
        $slots = [];
        foreach ($period as $date) {
            $time = $date->format("h:i A");
            $time24 = $date->format("H:i");
            $slots[] = [$time24,$time];
        }
        $slots[] = [$end,date('h:i A', strtotime($end))];
        return $slots;
    }
    
    function hoursToSecods ($hour) { // $hour must be a string type: "HH:mm:ss"

    $parse = array();
    if (preg_match ('#^(?<hours>[\d]{2}):(?<mins>[\d]{2})$#',$hour,$parse)) {
         return (int) $parse['hours'] * 3600 + (int) $parse['mins'] * 60;
    }else{
        return 0;
    }

}

}
