<?php

/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link      http://cakephp.org CakePHP(tm) Project
 * @since     0.2.9
 * @license   http://www.opensource.org/licenses/mit-license.php MIT License
 */

namespace App\Controller;

use Cake\Controller\Controller;
use Cake\Event\Event;
use Cake\ORM\TableRegistry;
use Cake\I18n\FrozenTime;
use Cake\I18n\FrozenDate;
use Cake\I18n\Date;
use Cake\Mailer\Email;
use Cake\Core\Configure;
use Cake\I18n\Time;

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @link http://book.cakephp.org/3.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller {

    /**
     * Initialization hook method.
     *
     * Use this method to add common initialization code like loading components.
     *
     * e.g. `$this->loadComponent('Security');`
     *
     * @return void
     */
    public function initialize() {
        parent::initialize();
        FrozenTime::setToStringFormat('HH:mm'); // For any immutable DateTime
        Date::setToStringFormat('yyyy-MM-dd'); // For any mutable Date
        FrozenDate::setToStringFormat('yyyy-MM-dd'); // For any mutable Date
        Time::setToStringFormat('HH:mm');
        $this->loadComponent('RequestHandler');
        $this->loadComponent('Flash');

        /*
         * Enable the following components for recommended CakePHP security settings.
         * see http://book.cakephp.org/3.0/en/controllers/components/security.html
         */
        //$this->loadComponent('Security');
        //$this->loadComponent('Csrf');
        $this->loadComponent('Security', ['blackHoleCallback' => 'forceSSL']);
        if (isset($this->request->prefix) && (strtolower($this->request->prefix) == "admin")) {
            $this->loadComponent('Auth', [
                'authenticate' => [
                    'Form' => [
                        'userModel' => 'AdminUsers', // Added This
                        'finder' => 'auth',
                        'fields' => [
                            'username' => 'email',
                            'password' => 'password'
                        ]
                    ]
                ],
                'loginAction' => [
                    'controller' => 'admin_users',
                    'action' => 'login',
                    'prefix' => 'admin'
                ],
                'loginRedirect' => [
                    'controller' => 'dashboard',
                    'action' => 'index',
                    'prefix' => 'admin'
                ],
                'logoutRedirect' => [
                    'controller' => 'admin_users',
                    'action' => 'login',
                    'prefix' => 'admin'
                ],
                'storage' => [
                    'className' => 'Session',
                    'key' => 'Auth.Admin',
                ],
            ]);
            // Allow the display action so our pages controller
            $this->Auth->allow(['signup', 'login', 'logout', 'forgot', 'reset']);
            $userData = ($this->Auth->user()) ? ($this->Auth->user()) : [];
            $userdir = str_replace("\\", "/", TableRegistry::get("AdminUsers")->_dir);
        } elseif (isset($this->request->prefix) && (strtolower($this->request->prefix) == "seller")) {
            $this->loadComponent('Auth', [
                'authenticate' => [
                    'Form' => [
                        'userModel' => 'Users', // Added This
                        'finder' => 'auth',
                        'fields' => [
                            'username' => 'email',
                            'password' => 'password'
                        ]
                    ]
                ],
                'loginAction' => [
                    'controller' => 'users',
                    'action' => 'login',
                    'prefix' => 'seller'
                ],
                'loginRedirect' => [
                    'controller' => 'dashboard',
                    'action' => 'index',
                    'prefix' => 'seller'
                ],
                'logoutRedirect' => [
                    'controller' => 'users',
                    'action' => 'login',
                    'prefix' => 'seller'
                ],
                'storage' => [
                    'className' => 'Session',
                    'key' => 'Auth.Seller',
                ],
            ]);
            // Allow the display action so our pages controller
            $this->Auth->allow(['signup', 'login', 'logout', 'forgot', 'reset']);
            $userData = ($this->Auth->user()) ? ($this->Auth->user()) : [];
            $userdir = str_replace("\\", "/", TableRegistry::get("Users")->_dir);
        } else {
            $this->loadComponent('Auth', [
                'authenticate' => [
                    'Form' => [
                        'userModel' => 'Users', // Added This
                        'finder' => 'auth',
                        'fields' => [
                            'username' => 'email',
                            'password' => 'password'
                        ]
                    ],
                ],
                'loginAction' => [
                    'controller' => 'users',
                    'action' => 'login',
                    'plugin' => false
                ],
                'loginRedirect' => [
                    'controller' => 'users',
                    'action' => 'profile',
                    'plugin' => false
                ],
                'logoutRedirect' => [
                    'controller' => 'users',
                    'action' => 'login',
                    'plugin' => false
                ],
                'storage' => [
                    'className' => 'Session',
                    'key' => 'Auth.User',
                ],
            ]);
            $this->Auth->allow(['imgupload']);
            $authData = ($this->Auth->user()) ? ($this->Auth->user()) : [];
            $this->set(compact("authData"));
        }

        $this->ConfigSettings = $ConfigSettings = Configure::read('Setting');
        $this->set(compact("userData", "userdir", "ConfigSettings"));
    }

    public function isAuthorized($user) {
        pr($user);
        die;
        // Admin can access every action
        if (isset($user['role']) && $user['role'] === 'admin') {
            return true;
        }

        // Default deny
        return false;
    }

    /**
     * Before render callback.
     *
     * @param \Cake\Event\Event $event The beforeRender event.
     * @return \Cake\Network\Response|null|void
     */
    public function beforeRender(Event $event) {
        if (!array_key_exists('_serialize', $this->viewVars) &&
                in_array($this->response->type(), ['application/json', 'application/xml'])
        ) {
            $this->set('_serialize', true);
        }
    }

    public function beforeFilter(Event $event) {
        $this->Security->requireSecure();
    }

    public function forceSSL() {
        if (!$this->request->is(['patch', 'post', 'put'])) {
            if (strtolower($this->request->controller) != "crons") {
                //return $this->redirect('https://' . env('SERVER_NAME') . $this->request->here);
            }
        }
    }

    public function imgupload() {
        $upload_dir = "img/ckimage/";
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        if (isset($_FILES['upload']) && strlen($_FILES['upload']['name']) > 1) {
            $upload_dir = trim($upload_dir, '/') . '/';
            $img_name = basename($_FILES['upload']['name']);
            $site = _BASE_;
            //$site = "/";
            $err = '';
            $ext = pathinfo($_FILES['upload']["name"], PATHINFO_EXTENSION);
            $allowedExt = array('jpg', 'jpeg', 'png', 'gif', 'bmp', 'jpe');
            if (in_array(strtolower($ext), $allowedExt)) {
                $CKEditorFuncNum = $_GET['CKEditorFuncNum'];

                $ran = time();
                $upload_img = $ran . "_" . $_FILES['upload']['name'];
                if (strlen($upload_img) > 60) {
                    $upload_img = $ran . "_" . rand() . "." . $ext;
                }
                $upload_img = str_replace(' ', '-', $upload_img);

                // $imageUploadProcess = $this->imageUpload->uploadFileResize($_FILES['upload'], $upload_dir);
                $url = $site . $upload_dir . $upload_img;
                if (move_uploaded_file($_FILES['upload']["tmp_name"], $upload_dir . $upload_img)) {
                    $message = $img_name . ' successfully uploaded: \\n- Size: ' . number_format($_FILES['upload']['size'] / 1024, 3, '.', '') . ' KB ';
                    $re = "window.parent.CKEDITOR.tools.callFunction($CKEditorFuncNum, '$url', '$message')";
                } else {
                    $re = 'alert("Unable to upload the file")';
                }
            } else {
                $re = 'alert("The file: ' . $_FILES['upload']['name'] . ' has not the allowed extension type.")';
            }
        } else {
            $re = 'alert("invalid image")';
        }

        echo "<script>$re;</script>";
        die();
    }

}
