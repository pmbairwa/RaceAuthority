<?php

namespace App\Controller\Api;

use App\Controller\Api\AppController;
use Cake\ORM\TableRegistry;
use Cake\I18n\Time;
use Cake\I18n\Date;
use Cake\Core\Configure;
use Cake\Log\Log;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 */
class ProductsController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->Auth->allow();
    }

    /*
     */

    public function getAllProducts() {
        if ($this->request->is('post')) {
            $conditions = [];
            $conditions[] = ['Products.status' => 1];
            $query = $this->Products->find();
            $query->where($conditions);
            $total = $query->count();
            if ($total > 0) {
                $options['limit'] = (isset($this->request->data['limit']) && !empty($this->request->data['limit'])) ? $this->request->data['limit'] : 1;
                //  $options['order'] = (isset($this->request->data['order']) && !empty($this->request->data['order'])) ? $this->request->data['order'] : 'DESC';
                $last_page = ceil($total / $options['limit']);
                $last_page = ($last_page > 0) ? $last_page : 1;
                // page no.
                $options['page'] = (isset($this->request->data['page']) && !empty($this->request->data['page']) && ($this->request->data['page'] <= $last_page)) ? $this->request->data['page'] : 1;

                $query->where($conditions);
                $query->contain(['Categories', 'Vendors']);
                $query->group(['Products.id']);
                if (isset($this->request->data['order']) && $this->request->data['order'] != '') {
                    $query->order(['Products.price' => $this->request->data['order']]);
                } else {
                    $query->order(['Products.id' => 'DESC']);
                }
                $this->paginate = $options;
                $products = $this->paginate($query)->toArray();
                foreach ($products as $k => $product) {
                    $bannerFolder = 'img/uploads/products/';
                    $products[$k]['image'] = !empty($product['image']) && file_exists($bannerFolder . $product['image']) ? _BASE_ . 'img/uploads/products/' . $product['image'] : _BASE_ . 'img/uploads/download.png';
                    $products[$k]['description'] = isset($product['description']) && $product['description'] != '' ? strip_tags($product['description']) : '';
                }
                $this->status = true;
                $this->responseData['last_page'] = $last_page;
                $this->responseData['total'] = $total;
                $this->responseData['products'] = $products;
            } else {
                $this->status = false;
                $this->responseData = array();
                $this->message = $this->msgDictonary['data_not_found'];
            }
        }
        $this->respond();
    }

    public function getAllProductsByUserId() {
        if ($this->request->is('post')) {
            $conditions = [];
            $conditions[] = ['Products.status' => 1, 'Products.seller_id' => $this->loggedInUserId];
            $query = $this->Products->find();
            $query->where($conditions);
            $total = $query->count();

            if ($total > 0) {
                //$options['limit'] = (isset($this->request->data['limit']) && !empty($this->request->data['limit'])) ? $this->request->data['limit'] : 2;
                $options['limit'] = (isset($this->request->data['limit']) && !empty($this->request->data['limit'])) ? $this->request->data['limit'] : 10;
                // $options['order'] = (isset($this->request->data['order']) && !empty($this->request->data['order'])) ? $this->request->data['order'] : 'ASC';
                $last_page = ceil($total / $options['limit']);
                $last_page = ($last_page > 0) ? $last_page : 1;
                // page no.
                $options['page'] = (isset($this->request->data['page']) && !empty($this->request->data['page']) && ($this->request->data['page'] <= $last_page)) ? $this->request->data['page'] : 1;

                $query->where($conditions);
                $query->contain(['Categories', 'Seller']);
                $query->group(['Products.id']);
                if (isset($this->request->data['order']) && $this->request->data['order'] != '') {
                    $query->order(['Products.price' => $this->request->data['order']]);
                } else {
                    $query->order(['Products.id' => 'DESC']);
                }
                $this->paginate = $options;
                $products = $this->paginate($query)->toArray();
                // pr($magazines); die;
                foreach ($products as $k => $product) {
                    $bannerFolder = 'img/uploads/products/';
                    $products[$k]['image'] = !empty($product['image']) && file_exists($bannerFolder . $product['image']) ? _BASE_ . 'img/uploads/products/' . $product['image'] : _BASE_ . 'img/uploads/download.png';
                    $products[$k]['description'] = isset($product['description']) && $product['description'] != '' ? strip_tags($product['description']) : '';
                }
//                        exit;
                $this->status = true;
                $this->responseData['last_page'] = $last_page;
                $this->responseData['total'] = $total;
                $this->responseData['products'] = $products;
            } else {
                $this->status = false;
                $this->responseData = array();
                $this->message = $this->msgDictonary['data_not_found'];
            }
        }
        $this->respond();
    }

    public function getProductDetail() {
        if ($this->request->is('post')) {
            $this->paramsValidation(array('product_id' => 'notBlank'));
            $this->loadModel('Reviews');
            $queryAvg = $this->Reviews->find();
            $avgRating = $queryAvg->select(['Reviews.star', 'Reviews.product_id', 'averagerating' => $queryAvg->func()->avg('Reviews.star')])->toArray();
            $query = $this->Products->find();
            $query->where(['Products.id =' => $this->request->data['product_id']]);
            $query->contain(['Seller', 'Categories', 'ProductImages', 'Reviews' => 'Buyer']);
            $productDetail = $query->first();
            if (!empty($productDetail)) {
                $imageFolder = 'img/uploads/products/';
                $productDetail['image'] = !empty($productDetail['image']) && file_exists($imageFolder . $productDetail['image']) ? _BASE_ . 'img/uploads/products/' . $productDetail['image'] : _BASE_ . 'img/uploads/download.png';
                $productDetail['description'] = isset($productDetail['description']) && $productDetail['description'] != '' ? strip_tags($productDetail['description']) : '';
                if (!empty($productDetail['product_images'])) {
                    foreach ($productDetail['product_images'] as $k => $productImages) {
                        $productDetail['product_images'][$k]['image'] = !empty($productImages['image']) && file_exists($imageFolder . $productImages['image']) ? _BASE_ . 'img/uploads/products/' . $productImages['image'] : _BASE_ . 'img/uploads/download.png';
                    }
                }
                if (!empty($productDetail['reviews'])) {
                    foreach ($productDetail['reviews'] as $k =>$reviews) {
                        $productDetail['reviews'][$k]['buyer']['profile_photo'] = !empty($reviews['profile_photo']) && file_exists($imageFolder . $reviews['profile_photo']) ? _BASE_ . 'img/uploads/users/photos/' . $reviews['profile_photo'] : _BASE_ . 'img/uploads/download.png';
                    }
                }
                $productDetail['reviewavg'] = $avgRating[0];
                $this->status = true;
                $this->responseData = $productDetail;
                $this->message = $this->msgDictonary['data_found'];
            } else {
                $this->status = false;
                $this->responseData = array();
                $this->message = $this->msgDictonary['data_not_found'];
            }
        }
        $this->respond();
    }

    public function getProductReview() {
        if ($this->request->is('post')) {
            $this->loadModel('Reviews');
            $this->paramsAvailability($this->request->data, array('product_id'));
            $this->paramsValidation(array('product_id' => 'notBlank'));
            $query = $this->Reviews->find();
            $query->where(['Reviews.product_id =' => $this->request->data['product_id']]);
            $productReviews = $query->contain(['Buyer'])->toArray();
            if (!empty($productReviews)) {
                foreach ($productReviews as $k => $productReview) {
                    $timestring = strtotime($productReview['created']);

                    // convert seconds into a specific format
                    $date = date("Y-m-d H:i", $timestring);

                    $productReviews[$k]['created'] = $date;
                }
                $this->status = true;
                $this->responseData['PrdocutReviews'] = $productReviews;
                $this->message = $this->msgDictonary['data_found'];
            } else {
                $this->status = false;
                $this->responseData = array();
                $this->message = $this->msgDictonary['data_not_found'];
            }
            $this->respond();
        }
    }

// 

    public function getCategories() {
        if ($this->request->is('post')) {
            $this->loadModel('Categories');
            $conditions = [];
            $query = $this->Categories->find();
            $query->where($conditions);
            $total = $query->count();
            if ($total > 0) {
                //$options['limit'] = (isset($this->request->data['limit']) && !empty($this->request->data['limit'])) ? $this->request->data['limit'] : 2;
                $options['limit'] = (isset($this->request->data['limit']) && !empty($this->request->data['limit'])) ? $this->request->data['limit'] : 50;
                $last_page = ceil($total / $options['limit']);
                $last_page = ($last_page > 0) ? $last_page : 1;
                // page no.
                $options['page'] = (isset($this->request->data['page']) && !empty($this->request->data['page']) && ($this->request->data['page'] <= $last_page)) ? $this->request->data['page'] : 1;

                $query->where($conditions);
                $query->order(['Categories.id' => 'DESC']);
                $this->paginate = $options;
                $categories = $this->paginate($query)->toArray();
                foreach ($categories as $k => $category) {
                    $bannerFolder = _BASE_ . 'img/uploads/categories/';
                    $categories[$k]['image'] = $bannerFolder . $category['image'];
                    $categories[$k]['description'] = isset($category['description']) && $category['description'] != '' ? strip_tags($category['description']) : '';
                }
                // pr($magazines); die;
                $this->status = true;
                $this->responseData['last_page'] = $last_page;
                $this->responseData['total'] = $total;
                $this->responseData['categories'] = $categories;
            } else {
                $this->status = false;
                $this->responseData = array();
                $this->message = $this->msgDictonary['data_not_found'];
            }
            $this->respond();
        }
    }

    public function getProductsByCategory() {
        if ($this->request->is('post')) {
            $this->paramsValidation(array('category_id' => 'notBlank'));
            $conditions = [];
            $lowerLimit = (isset($this->request->data['min_price']) && !empty($this->request->data['min_price'])) ? $this->request->data['min_price'] : 0;
            $upperLimit = (isset($this->request->data['max_price']) && !empty($this->request->data['max_price'])) ? $this->request->data['max_price'] : '';
            $conditions[] = ['Products.status' => 1, 'Products.category_id' => $this->request->data['category_id'],'Products.price <=' => $upperLimit,'Products.price >' => $lowerLimit];
            $query = $this->Products->find();
            $query->where($conditions);
            $total = $query->count();

            if ($total > 0) {
                //$options['limit'] = (isset($this->request->data['limit']) && !empty($this->request->data['limit'])) ? $this->request->data['limit'] : 2;
                $options['limit'] = (isset($this->request->data['limit']) && !empty($this->request->data['limit'])) ? $this->request->data['limit'] : 50;
                $last_page = ceil($total / $options['limit']);
                $last_page = ($last_page > 0) ? $last_page : 1;
                // page no.
                $options['page'] = (isset($this->request->data['page']) && !empty($this->request->data['page']) && ($this->request->data['page'] <= $last_page)) ? $this->request->data['page'] : 1;

                $query->where($conditions);
                $query->contain(['Categories', 'Seller']);
                $query->group(['Products.id']);
                $query->order(['Products.id' => 'DESC']);
                $this->paginate = $options;
                $products = $this->paginate($query)->toArray();
                // pr($magazines); die;
                foreach ($products as $k => $product) {
                    $bannerFolder = _BASE_ . '/img/uploads/product/';
                    $products[$k]['image'] = !empty($product['image']) && file_exists($bannerFolder . $product['image']) ? _BASE_ . 'img/uploads/product/' . $product['image'] : _BASE_ . 'img/uploads/download.png';
                    $products[$k]['description'] = isset($product['description']) && $product['description'] != '' ? strip_tags($product['description']) : '';
                }
//                        exit;
                $this->status = true;
                $this->responseData['last_page'] = $last_page;
                $this->responseData['total'] = $total;
                $this->responseData['products'] = $products;
            } else {
                $this->status = false;
                $this->responseData = array();
                $this->message = $this->msgDictonary['data_not_found'];
            }
        }
        $this->respond();
    }

    public function getCategoryListing() {
        if ($this->request->is('post')) {
            $this->loadModel('Categories');
            $conditions = ['Categories.name LIKE' => '%' . $this->request->data['query'] . '%'];
            $query = $this->Categories->find();
            $query->where($conditions);
            $total = $query->count();
            if ($total > 0) {
                //$options['limit'] = (isset($this->request->data['limit']) && !empty($this->request->data['limit'])) ? $this->request->data['limit'] : 2;
                $query->where($conditions);
                $query->order(['Categories.id' => 'DESC']);

                $categories = $this->paginate($query)->toArray();
                // pr($magazines); die;
                $this->status = true;
                $this->responseData['categories'] = $categories;
            } else {
                $this->status = false;
                $this->responseData = array();
                $this->message = $this->msgDictonary['data_not_found'];
            }
            $this->respond();
        }
    }

    public function postReview() {
        if ($this->request->is('post')) {
            $this->loadModel('Reviews');
            $this->paramsAvailability($this->request->data, array('user_id', 'product_id', 'comment'));
            $this->paramsValidation(array('user_id' => 'notBlank', 'product_id' => 'notBlank', 'comment' => 'notBlank'));
            $this->request->data['status'] = 1;
            $review = $this->Reviews->newEntity();
            $review = $this->Reviews->patchEntity($review, $this->request->data);

            if ($this->Reviews->save($review)) {
                $this->message = $this->msgDictonary['review_submit'];
                $this->status = true;
            } else {
                $this->message = $this->errors = $this->Default->get_errors($review->errors());
            }
        }
        $this->respond();
    }

    public function addProduct() {
        if ($this->request->is('post')) {
            $this->loadModel('Reviews');
            $this->paramsAvailability($this->request->data, array('name', 'category_id', 'quantity', 'regular_price', 'price', 'status'));
            $this->paramsValidation(array('category_id' => 'notBlank', 'name' => 'notBlank', 'quantity' => 'notBlank', 'regular_price' => 'notBlank', 'price' => 'notBlank', 'status' => 'notBlank'));
            $this->request->data['seller_id'] = $this->loggedInUserId;
            $product = $this->Products->newEntity();
            $product = $this->Products->patchEntity($product, $this->request->data);
            if ($this->Products->save($product)) {
                $this->message = $this->msgDictonary['product_add'];
                $this->responseData['product_id'] = $product->id;
                $this->status = true;
            } else {
                $this->message = 'test';
                $this->status = false;
            }
        }
        $this->respond();
    }

    public function addImages() {
        $this->loadModel('ProductImages');
        $this->paramsAvailability($this->request->data, array('product_id'));
        $this->request->data['user_id'] = $this->loggedInUserId;
        $target_path = BASE_PATH_PRODUCT_IMAGE;
        $target_path = $target_path . basename($_FILES['file']['name']);
        $productInfo = $this->Products->find()->where(['id' => $this->request->data['product_id']])->first();



        if ($productInfo->image != '') {
            if (move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {
                $this->request->data['product_id'] = $this->request->data['product_id'];
                $this->request->data['image'] = $_FILES['file']['name'];
                $productImages = $this->ProductImages->newEntity();
                $productImages = $this->ProductImages->patchEntity($productImages, $this->request->data);
                if ($this->ProductImages->save($productImages)) {
                    $this->message = 'Image Uploaded Successfully';
                    $this->status = true;
                } else {
                    $this->status = false;
                    $this->responseData = [];
                    $this->message = $this->errors = $this->Default->get_errors($productImages->errors());
                }
            } else {
                $this->status = true;
                $this->message = 'Error in image uploading';
            }
        } else {
            $productInfo->image = $_FILES['file']['name'];


            if (move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {
                if ($resultUpdate = $this->Products->save($productInfo)) {
                    $this->status = true;
                    $this->responseData = [];
                    $this->message = 'Image Uploaded Successfully';
                } else {
                    $this->status = false;
                    $this->responseData = [];
                    $this->message = $this->errors = $this->Default->get_errors($resultUpdate->errors());
                }
            } else {
                $this->status = true;
                $this->message = 'Error in image uploading';
            }
        }
        $this->respond();
    }

    public function searchCategory() {
        if ($this->request->is('post')) {
            $keyword = $this->request->data['keyword'];
            $this->loadModel('Categories');
            $query = $this->Categories->find();
            $searchResult = $query->where(['Categories.name LIKE' => '%' . $keyword . '%',])->order(['Categories.created' => 'DESC'])->toArray();
            if (!empty($searchResult)) {
                $this->status = true;
                $this->responseData = $searchResult;
                $this->message = $this->msgDictonary['data_found'];
            } else {
                $this->status = false;
                $this->responseData = array();
                $this->message = $this->msgDictonary['data_not_found'];
            }
            $this->respond();
        }
    }

    public function getAllSliders() {
        $this->loadModel('Sliders');
        if ($this->request->is('get')) {
            $conditions = [];
            $conditions[] = ['Sliders.status' => 1];
            $query = $this->Sliders->find();
            $query->where($conditions);
            $total = $query->count();
            if ($total > 0) {
                $sliders = $query->toArray();
                foreach ($sliders as $k => $slider) {
                    $bannerFolder = 'img/uploads/products/';
                    $sliders[$k]['image'] = !empty($slider['image']) && file_exists($bannerFolder . $slider['image']) ? _BASE_ . 'img/uploads/products/' . $slider['image'] : _BASE_ . 'img/uploads/download.png';
                }
                $this->status = true;
                $this->responseData['sliders'] = $sliders;
            } else {
                $this->status = false;
                $this->responseData = array();
                $this->message = $this->msgDictonary['data_not_found'];
            }
        }
        $this->respond();
    }

    public function getCountryState() {
        $this->loadModel('Countries');
        $this->loadModel('States');
        if ($this->request->is('get')) {
            $conditions = [];
            $query = $this->Countries->find();
            $query->where($conditions);
            $total = $query->count();
            $country_data = array();
            if ($total > 0) {
                $querystate = $this->States->find();
                $country_data['countries'] = $query->toArray();
                $country_data['states'] = $querystate->toArray();
                $this->status = true;
                $this->responseData = $country_data;
            } else {
                $this->status = false;
                $this->responseData = array();
                $this->message = $this->msgDictonary['data_not_found'];
            }
        }
        $this->respond();
    }

}
