<?php

namespace App\Controller\Api;

use App\Controller\Api\AppController;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use Cake\I18n\Time;
use Cake\I18n\Date;
use Cake\Mailer\MailerAwareTrait;

/**
 * Orders Controller
 *
 * @property \App\Model\Table\OrdersTable $Orders
 */
class OrdersController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->Auth->allow();
    }

    /**
     * Booking method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function createOrder() {
        if ($this->request->is('post')) {
            $orders = $this->Orders->newEntity();
            $totalCount = count($this->request->data['order_json']);
            $this->request->data['user_id'] = $this->loggedInUserId;
            $this->request->data['no_of_items'] = $totalCount;
            $this->request->data['order_json_data'] = $this->request->data['order_json'];
            $this->request->data['order_json'] = json_encode($this->request->data['order_json']);
            $this->request->data['order_status'] = 0;
            $this->request->data['total_price'] = $this->request->data['totalCost'];
            $this->request->data['order_code'] = uniqid('ORD_');
            $this->request->data['order_source'] = 2;
            $orders = $this->Orders->newEntity();
            $orders = $this->Orders->patchEntity($orders, $this->request->data);
            if ($newOrder = $this->Orders->save($orders)) {
                unset($this->request->data['order_json']);
                $this->loadModel('SellerOrders');
                $new_order_id = $newOrder->id;
                $orderData = $this->request->data;
                foreach ($this->request->data['order_json_data'] as $sellerdata) {
                    $sellerOrders = $this->SellerOrders->newEntity();
                    $sellerOrders['order_id'] = $new_order_id;
                    $sellerOrders['seller_id'] = $sellerdata['seller_id'];
                    $sellerOrders['quantity_per_item'] = $sellerdata['qty'];
                    $sellerOrders['product_id'] = $sellerdata['id'];
                    $this->SellerOrders->save($sellerOrders);
                }
                $this->status = true;
                $this->responseData = $new_order_id;
                $this->message = $this->msgDictonary['data_saved'];
            } else {
                $this->status = false;
                $this->responseData = $orders->errors();
                $this->message = $this->msgDictonary['data_not_saved'];
            }
        }
        $this->respond();
    }

    public function createOrderPayment() {
        if ($this->request->is('post')) {
            $order_group_id = $this->request->data['order_Id'];
            $this->loadModel('SellerOrders');
            $sellerRecord = $this->SellerOrders->find()->select(['SellerOrders.seller_id', 'SellerOrders.product_id', 'SellerOrders.quantity_per_item', 'Sellers.stripe_account_id', 'Products.price', 'Sellers.email'])
                            ->where(['SellerOrders.order_id' => $order_group_id])->contain(['Sellers', 'Products'])->toArray();
//            pr($sellerRecord);
//            exit;
            $totalPrice = (intval($this->request->data['price']));
            $stripe = array(
                "secret_key" => "sk_test_akFcdNP70Cip5WAXJr79SEOM",
                "publishable_key" => "pk_test_lGZqlvQMtLaXuBZTDik2jRAx"
            );
            require_once(ROOT . '/vendor' . DS . 'stripe' . DS . 'init.php');
            \Stripe\Stripe::setApiKey($stripe['secret_key']);

            $charge = \Stripe\Charge::create(array(
                        "amount" => $totalPrice * 100,
                        "currency" => "usd",
                        "source" => $this->request->data['token'],
                        "transfer_group" => "{$order_group_id}",
            ));
            foreach ($sellerRecord as $sellers) {
                if ($sellers['seller']['stripe_account_id'] != '') {
//                    echo $sellers['product']['price'] .'<br/>';
//                    echo $sellers['quantity_per_item'].'<br/>';;
//                    echo $sellers['product']['price'] * $sellers['quantity_per_item'];

                    $transfer = \Stripe\Transfer::create(array(
                                "amount" => $sellers['product']['price'] * 100 * $sellers['quantity_per_item'],
                                "currency" => "usd",
                                "destination" => $sellers['seller']['stripe_account_id'],
                                "transfer_group" => "{$order_group_id}",
                    ));
                }
            }
//            exit;
//            pr($charge);
//            exit;
            if (isset($charge->id) && !empty($charge->id)) {
                $this->request->data['transaction_id'] = $charge->id;
                $this->request->data['is_paid'] = 1;
                $this->request->data['order_status'] = 2;
                $previousOrderUpdate = $this->Orders->get($order_group_id);
                $previousOrderUpdate = $this->Orders->patchEntity($previousOrderUpdate, $this->request->data);
                $this->Orders->save($previousOrderUpdate);
                $this->status = true;
                $this->message = $this->msgDictonary['order_crated'];
            } else {
                $this->status = false;
                $this->message = $this->msgDictonary['order_failed'];
            }
        }

        $this->respond();
    }

    public function refundAmount($order_id) {
        $sellerRecord = $this->Orders->find()->select(['Orders.transaction_id'])
                        ->where(['Orders.id' => $order_id])->first();
        $stripe = array(
            "secret_key" => "sk_test_akFcdNP70Cip5WAXJr79SEOM",
            "publishable_key" => "pk_test_lGZqlvQMtLaXuBZTDik2jRAx"
        );
        require_once(ROOT . '/vendor' . DS . 'stripe' . DS . 'init.php');
        \Stripe\Stripe::setApiKey($stripe['secret_key']);
//        $refund = \Stripe\Refund::create(array(
//                    "charge" => "{$sellerRecord['transaction_id']}",
//        ));

        $transfer = \Stripe\Transfer::retrieve("{$sellerRecord['transaction_id']}");
        $transfer->reversals->create(500);
//        $transfer->reversals->create(
//                 "amount" => '',
//      
//        );
        pr($transfer);
        exit;
    }

    public function getOrders() {
        if ($this->request->is('post')) {
            $user_id = $this->loggedInUserId;
            $query = $this->Orders->find();
            $query->where(['Orders.user_id =' => $user_id]);
            $query->contain(['Users' => 'UserAddresses'])->order(['Orders.created' => 'DESC']);
            $ordersDetail = $query->map(function ($row) {
                        if (isset($row->order_status) && $row->order_status == 0) {
                            $order_status = 'Pending';
                        } elseif ($row->order_status == 1) {
                            $order_status = 'Processing';
                        } elseif ($row->order_status == 2) {
                            $order_status = 'Shipped';
                        } elseif ($row->order_status == 3) {
                            $order_status = 'Delivered';
                        }
                        $row->order_status = $order_status;
                        $row->order_json = json_decode($row->order_json);
                        return $row;
                    })->toArray();
            if (!empty($ordersDetail)) {
                $this->status = true;
                $this->responseData = $ordersDetail;
                $this->message = $this->msgDictonary['data_found'];
            } else {
                $this->status = false;
                $this->responseData = array();
                $this->message = $this->msgDictonary['data_not_found'];
            }
        }
        $this->respond();
    }

    public function getOrderDetails() {
        if ($this->request->is('post')) {
            $order_id = $this->request->data['order_id'];
            $user_id = $this->loggedInUserId;
            $query = $this->Orders->find();
            $query->where(['Orders.id' => $order_id, 'Orders.user_id' => $user_id]);
            $ordersDetail = $query->contain(['SellerOrders', 'Users', 'UserAddresses'])->order(['Orders.created' => 'DESC'])->first()->toArray();
            if (!empty($ordersDetail)) {
                $ordersDetail['created'] = $ordersDetail['created']->format('Y-m-d');
                $ordersDetail['order_json'] = json_decode($ordersDetail['order_json']);
                if (isset($ordersDetail['order_status']) && $ordersDetail['order_status'] == 0) {
                    $order_status = 'Pending';
                } elseif ($ordersDetail['order_status'] == 1) {
                    $order_status = 'Processing';
                } elseif ($ordersDetail['order_status'] == 2) {
                    $order_status = 'Shipped';
                } elseif ($ordersDetail['order_status'] == 3) {
                    $order_status = 'Delivered';
                }
                $ordersDetail['order_status'] = $order_status;
                $this->status = true;
                $this->responseData = $ordersDetail;
                $this->message = $this->msgDictonary['data_found'];
            } else {
                $this->status = false;
                $this->responseData = array();
                $this->message = $this->msgDictonary['data_not_found'];
            }
        }
        $this->respond();
    }

    public function getProductPrice($product_id) {
        $this->loadModel('Products');
        $product_info = $this->Products->find()->where(['Products.id' => $product_id])->first();
        return $product_info;
    }
    public function getPaymentMethods() {
        $this->loadModel('PaymentMethods');
        $payment_methods = $this->PaymentMethods->find()->where(['PaymentMethods.enable' => 1])->toArray();
        return $payment_methods;
    }

    public function getAllInfoAboutProducts() {
        if ($this->request->is('post')) {
            $product_data = $this->request->data['products'];
            $user_id = $this->loggedInUserId;
            $tax = 0;
            $total = array();
            if (!empty($product_data)) {
                foreach ($product_data as $k => $prod) {
                    $product_price = $this->getProductPrice($prod['product_id']);
                    $product_data[$k]['subtotal'] = $product_price['price'] * $prod['quantity'];
                    $product_data[$k]['tax'] = $tax;
                    $product_data[$k]['total'] = $product_price['price'] * $prod['quantity'] + $tax;
                }
                $shipping_data[] = array('price'=>0,'name'=>'flat shipping');
                $payment_methods = $this->getPaymentMethods();
                if(!empty($payment_methods)){
                    $pay_methods = $payment_methods;
                }
                $this->status = true;
                $this->responseData['total']['total'] = $product_data;
                $this->responseData['shipping'] = $shipping_data;
                $this->responseData['payment'] = $pay_methods;
                $this->message = $this->msgDictonary['data_found'];
            } else {
                $this->status = false;
                $this->responseData = array();
                $this->message = $this->msgDictonary['data_not_found'];
            }
        }
        $this->respond();
    }

}
