<?php

namespace App\Controller\Customer;

use App\Controller\Customer\AppController;

/**
 * Services Controller
 *
 * @property \App\Model\Table\ServicesTable $Services
 */
class ServicesController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->Auth->allow();
    }

    /**
     * listing method
     *
     * @return \Cake\Network\Response|null
     */
    public function allServices() {
        if ($this->request->is('post')) {
            $orders = ['id' => 'Asc'];
            $services = $this->Services->find()->where([])->select(['id', 'title'])->order($orders)->toArray();
            if (count($services) > 0) {
                $this->status = true;
                $this->message = $this->msgDictonary['record_found'];
                $this->responseData['Services'] = $services;
            } else {
                $this->responseData['Services'] = [];
                $this->message = $this->msgDictonary['no_record_found'];
            }
        }
        $this->respond();
    }

}
