<?php

namespace App\Controller\Api;

use App\Controller\Api\AppController;
use Cake\ORM\TableRegistry;
use Cake\I18n\Time;
use Cake\I18n\Date;
use Cake\Core\Configure;
use Cake\Log\Log;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 */
class UsersController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->Auth->allow();
    }

    /*
     * Method : login
     * Params : user credentials
     * Return : user details
     * Desc : authenticate user
     */

    public function login() {
        if ($this->request->is('post') && !empty($this->request->data)) {
            $this->paramsAvailability($this->request->data, array('email', 'password'));
            $this->paramsValidation(array('email' => 'notBlank', 'password' => 'notBlank'));
            if (!isset($this->request->data['account_type_id'])) {
                $this->request->data['account_type_id'] = 1;
            }
            $this->request->data['login_by'] = 'app';
            $user = $this->Auth->identify();
            if ($user) {
                if ($this->request->data['account_type_id'] == $user['account_type_id']) {
                    if ($user['verified'] != 1) {
                        $this->message = $this->msgDictonary['verification_pending'];
                    } else if ($user['status'] == 0) {
                        $this->message = $this->msgDictonary['deactivated_account'];
                    } else {
                        if (empty($user['auth_token']))
                            $auth_token = $this->getGUID();
                        else
                            $auth_token = $user['auth_token'];

                        $data = $this->_loginResponse($user['id'], $this->request->data, $auth_token);
                        if ($data) {
                            $this->status = true;
                            $this->responseData = $data;
                            $this->message = $this->msgDictonary['login_success'];
                        } else {
                            $this->message = $this->msgDictonary['technical_error'];
                        }
                    }
                } else {
                    $this->message = 'Your Account not associated with this role.';
                }
            } else {
                $this->message = $this->msgDictonary['invalid_login'];
            }
        }
        $this->respond();
    }

    /*
     * Method : updateDevice
     * Params : device details
     * Return : null
     */

    public function updateDevice() {
        if ($this->request->is('post')) {
            $user_data['device_type'] = $this->request->data['device_type'] ? $this->request->data['device_type'] : '';
            $user_data['device_id'] = $this->request->data['device_id'] ? $this->request->data['device_id'] : '';
            $employee = $this->Users->get($this->loggedInUserId);
            $employee = $this->Users->patchEntity($employee, $user_data);
            if ($this->Users->save($employee)) {
                $this->status = true;
                $this->message = $this->msgDictonary['update_device'];
            } else {
                $this->message = $this->msgDictonary['technical_error'];
            }
        }
        $this->respond();
    }

    /*
     * Method : _loginResponse
     * Params : user_id, requestData, auth_token
     * Return : user details
     * Desc : after user authentication, save user's other details
     */

    public function _loginResponse($user_id, $requestData, $auth_token) {
        $user_data['auth_token'] = $auth_token;
        $user_data['id'] = $user_id;
        $user_data['login_by'] = $requestData['login_by'];
        $user_data['online_status'] = 1;
        $user = $this->Users->get($user_id, [
            'contain' => ['SavedCards', 'UserAddresses']]);
        $user = $this->Users->patchEntity($user, $user_data);
        $this->Users->save($user);
        $user_data['id'] = $user['id'];
        $user_data['auth_token'] = $user['auth_token'];
        $user_data['name'] = $user['name'];
        $user_data['email'] = $user['email'];
        $user_data['mobile'] = $user['mobile'];
        $user_data['account_type_id'] = $user['account_type_id'];
        foreach ($user['user_addresses'] as $k => $address) {
            $user['user_addresses'][$k]['full_name'] = $user['name'];
        }
        $user_data['shipping_addresses'] = $user['user_addresses'];
        $user_data['credit_cards'] = $user['saved_cards'];
        $user_data['profile_pic'] = ($user['profile_photo'] != '') ? _BASE_ . "img/uploads/users/" . $user['profile_photo'] : '';

        return $user_data;
    }

    /*
     * Method : register
     * Params : customer details
     * Return :
     * Desc : register customer
     */

    public function registerseller() {
        if ($this->request->is('post')) {
            $this->paramsAvailability($this->request->data, array('first_name', 'last_name', 'email', 'mobile', 'password'));
            $this->paramsValidation(array('first_name' => 'notBlank', 'last_name' => 'notBlank', 'email' => 'notBlank', 'mobile' => 'notBlank', 'password' => 'notBlank'));
            $user = $this->Users->newEntity();
            // $this->request->data['verification_code'] = md5(rand() . uniqid(''//));

            $this->request->data['account_type_id'] = 2;

            $this->request->data['verified'] = 1;
            $this->request->data['auth_token'] = $this->getGUID();
            $this->request->data['status'] = 1;

            $user = $this->Users->patchEntity($user, $this->request->data);
            if ($this->Users->save($user)) {
                $this->status = true;
                $EmailTemplates = TableRegistry::get('EmailTemplates');
                $template = $EmailTemplates->find()->where(['id' => '6'])->first();
                $subject = str_replace('##SITE_NAME##', $this->settings['sitename'], $template->subject);
                $message = str_replace('##FROM_EMAIL##', $this->settings['from_email'], $template->description);
                //  $message = str_replace('##SITE_LOGO##', $this->settings['sitelogo'], $message);
                $message = str_replace('##SITE_NAME##', $this->settings['sitename'], $message);
                $message = str_replace('##USERNAME##', $this->request->data['first_name'] . '' . $this->request->data['last_name'], $message);
                //   $message = str_replace('##VERIFICATION_LINK##', _BASE_ . "users/verifyAppAccount?email=" . $this->request->data['email'] . "&key=" . $this->request->data['verification_code'], $message);
                $sentEmail['to'] = $this->request->data['email'];
                $from = $this->settings['from_email'];
                $bodyVars = array("content" => $message, 'template' => false);
                $send = $this->Default->_sendMail($sentEmail, $from, $subject, $bodyVars);
                $this->message = $this->msgDictonary['signup_success_without_email'];
            } else {
                $this->message = $this->errors = $this->Default->get_errors($user->errors());
            }
        }
        $this->respond();
    }

    public function registerbuyer() {
        if ($this->request->is('post')) {
            $this->paramsAvailability($this->request->data, array('first_name', 'last_name', 'email', 'mobile', 'password'));
            $this->paramsValidation(array('first_name' => 'notBlank', 'last_name' => 'notBlank', 'email' => 'notBlank', 'mobile' => 'notBlank', 'password' => 'notBlank'));
            $user = $this->Users->newEntity();
            // $this->request->data['verification_code'] = md5(rand() . uniqid(''//));
            $this->request->data['account_type_id'] = 1;
            $this->request->data['verified'] = 1;
            $this->request->data['auth_token'] = $this->getGUID();
            $this->request->data['status'] = 1;

            $user = $this->Users->patchEntity($user, $this->request->data);
            if ($this->Users->save($user)) {
                $this->status = true;
//                $EmailTemplates = TableRegistry::get('EmailTemplates');
//                $template = $EmailTemplates->find()->where(['id' => '6'])->first();
//                $subject = str_replace('##SITE_NAME##', $this->settings['sitename'], $template->subject);
//                $message = str_replace('##FROM_EMAIL##', $this->settings['from_email'], $template->description);
//                //  $message = str_replace('##SITE_LOGO##', $this->settings['sitelogo'], $message);
//                $message = str_replace('##SITE_NAME##', $this->settings['sitename'], $message);
//                $message = str_replace('##USERNAME##', $this->request->data['first_name'] . '' . $this->request->data['last_name'], $message);
//             //   $message = str_replace('##VERIFICATION_LINK##', _BASE_ . "users/verifyAppAccount?email=" . $this->request->data['email'] . "&key=" . $this->request->data['verification_code'], $message);
//                $sentEmail['to'] = $this->request->data['email'];
//                $from = $this->settings['from_email'];
//                $bodyVars = array("content" => $message, 'template' => false);
//                $send = $this->Default->_sendMail($sentEmail, $from, $subject, $bodyVars); 
                $this->message = $this->msgDictonary['signup_success_without_email'];
            } else {
                $this->message = $this->errors = $this->Default->get_errors($user->errors());
            }
        }
        $this->respond();
    }

    /*
     * Method : forgot password
     * Params : user's email
     * Return :
     * Desc : send verification code to user
     */

    public function forgot() {
        if ($this->request->is('post')) {
            $this->paramsAvailability($this->request->data, array('email'));
            $uData = $this->Users->find('all')->where(['email' => $this->request->data['email']]);
            $result = $uData->first();
            if (!empty($result)) {
                $verification_code = mt_rand(100000, 999999);
                $EmailTemplates = TableRegistry::get('EmailTemplates');
                $template = $EmailTemplates->find()->where(['id' => 7])->first();

                $message = str_replace('##_BASE_##', _BASE_, $template->description);
                $message = str_replace('##SITE_NAME##', $this->settings['sitename'], $message);
                $message = str_replace('##FROM_EMAIL##', $this->settings['from_email'], $message);
//                $message = str_replace('##SUPPORT_EMAIL##', $this->settings['support_email'], $message);
                $message = str_replace('##SITE_LOGO##', _BASE_ . 'uploads/settings/' . $this->settings['logo'], $message);
                $message = str_replace('##USERNAME##', $result->name, $message);
                $message = str_replace('##VERIFICATION_CODE##', $verification_code, $message);

                $sentEmail['to'] = $result->email;
                $from = $this->settings['from_email'];
                $subject = str_replace('##SITE_NAME##', $this->settings['sitename'], $template->subject);

                $user = $this->Users->get($result->id);
                $tokenData = array(
                    'reset_key' => $verification_code
                );
                $user = $this->Users->patchEntity($user, $tokenData);
                if ($this->Users->save($user)) {
                    $bodyVars = array("content" => $message, 'template' => false);
                    $send = 1;
                    // $send = $this->Default->_sendMail($sentEmail, $from, $subject, $bodyVars);
                    if ($send) {
                        $this->message = $this->msgDictonary['forgot_password'];
                        $this->status = true;
                    } else
                        $this->message = $this->msgDictonary['process_failed'];
                }
            } else {
                $this->status = false;
                $this->message = $this->msgDictonary['invalid_account'];
            }
        }
        $this->respond();
    }

    /*
     * Method : reset password
     * Params : verification code, new password
     * Return :
     * Desc : verify account and reset password
     */

    Public function reset() {
        if ($this->request->is('post')) {
            $this->paramsAvailability($this->request->data, array('reset_key', 'password'));
            $result = $this->Users->find()->where(['reset_key' => $this->request->data['reset_key']])->first();
            if ($result) {
                $user = $this->Users->get($result->id);
                $tokenData = array(
                    'reset_key' => '',
                    'password' => $this->request->data['password']
                );
                $user = $this->Users->patchEntity($user, $tokenData);
                if ($this->Users->save($user)) {
                    $this->message = $this->msgDictonary['reset_password'];
                    $this->status = true;
                } else {
                    $this->message = $this->Default->get_errors($user->errors());
                }
            } else {
                $this->message = $this->msgDictonary['verification_account'];
            }
        }
        $this->respond();
    }

    /**
     * Profile view method
     *
     * @param string|null $id User id.
     * @return \Cake\Network\Response|void Redirects on successful get details, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function profile() {
        $user = $this->Users->get($this->loggedInUserId, ['fields' => ['id', 'first_name', 'last_name', 'email', 'mobile', 'profile_photo']]);
        if ($user) {
            $customerImageFolder = _BASE_ . '/img/uploads/users/photos/';
            $user['profile_photo'] = !empty($user['profile_photo']) && file_exists($customerImageFolder . $user['profile_photo']) ? $customerImageFolder . $user['profile_photo'] : _BASE_ . 'img/uploads/download.png';
//            $user['profile_photo'] = !empty($user['profile_photo']) ? _BASE_ . 'uploads/users/' . $user['profile_photo'] : $user['profile_photo'];
            $this->status = true;
            $this->responseData = $user;
        } else {
            $this->message = $this->msgDictonary['profile_not_found'];
        }
        $this->respond();
    }

    public function socialRegister() {
        if ($this->request->is('post')) {
            $this->paramsValidation(array('unique_key' => 'notBlank'));
            Log::write('debug', $this->request->data);
            $uData = $this->Users->find('all')->where(['unique_key' => $this->request->data['unique_key']])->first();
            if (empty($uData)) {
                $user = $this->Users->newEntity();
                $this->request->data['login_by'] = 'facebook';
                $this->request->data['status'] = $this->request->data['is_verified'] = 1;
                $user = $this->Users->patchEntity($user, $this->request->data, ['validate' => false]);
                if ($this->Users->save($user)) {
                    $user_id = $user->id;

                    //login function
//                $token = $user_id . '|' . $this->request->data['unique_key'];
                    $auth_token = $this->getGUID();
                    $data = $this->_loginResponse($user_id, $this->request->data, $auth_token);
                    if ($data) {
                        $this->status = true;
                        $this->responseData = $data;
                        $this->message = $this->msgDictonary['login_success'];
                    } else {
                        $this->message = $this->msgDictonary['technical_error'];
                    }
                } else {
                    $emailRelatedData = $this->Users->find('all')->where(['email' => $this->request->data['email']])->first();
                    $user_id = $emailRelatedData['id'];
                    $this->loadModel('Autographs');
                    $user_data['id'] = $user_id;
                    $user_data['unique_key'] = $this->request->data['unique_key'];
                    // $uniqueKey = $this->request->data['unique_key'];
                    $user = $this->Users->get($user_id);
                    $user = $this->Users->patchEntity($user, $user_data);
                    $this->Users->save($user);
                    $auth_token = $this->getGUID();
                    $data = $this->_loginResponse($user_id, $this->request->data, $auth_token);
                    $this->status = true;
                    $this->responseData = $data;
                    $this->message = $this->msgDictonary['login_success'];
                }
            } else {

                //  $uData = $this->Users->find('all')->where(['unique_key' => $this->request->data['unique_key']]);
                $result = $uData;

                if (!empty($result)) {
                    $auth_token = $this->getGUID();
                    $data = $this->_loginResponse($result['id'], $result, $auth_token);
                    $this->status = true;
                    $this->responseData = $data;
                    $this->message = $this->msgDictonary['login_success'];
                } else {
                    $this->code = 400;
                    $this->message = $this->msgDictonary['invalid_detail'];
                }
            }
        } else {
            $this->status = true;
            $this->responseData = $data;
            $this->message = $this->msgDictonary['page_not_found'];
            //$this->message = $this->errors = $this->Default->get_errors($user->errors());
        }
        $this->respond();
    }

    /**
     * Update method
     *
     * @param string|null $id User id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function uploadProfilePice() {
        $extensions_array = ['jpg', 'jpeg', 'png', 'gif'];
        if (isset($this->request->data['profile_photo']['name']) && !empty($this->request->data['profile_photo']['name']) && $this->request->data['profile_photo']['error'] == 0) {
            //$upload_folder = _BASE_ . 'webroot/uploads/users';
            $upload_folder = $_SERVER['DOCUMENT_ROOT'] . '/hairsaloon/webroot/img/uploads/users/photos';
            $file_name = 'customer_' . time() . '_' . basename($this->request->data['profile_photo']['name']);

            // check image extension
            $file_extension = pathinfo($this->request->data['profile_photo']['name'], PATHINFO_EXTENSION);
            $file_extension = strtolower($file_extension);

            if (!in_array($file_extension, $extensions_array)) {
                $this->message = $this->msgDictonary['invalid_extension'];
                $this->respond();
            } else {
                if (move_uploaded_file($this->request->data['profile_photo']['tmp_name'], $upload_folder . '/' . $file_name)) {
                    // save image to db
                    $this->request->data['profile_photo'] = $file_name;
                } else
                    unset($this->request->data['profile_photo']);
            }
        }
    }

    public function updateProfile() {
        if ($this->request->is(['patch', 'post', 'put'])) {
            $this->paramsValidation(array('first_name' => 'notBlank'));
            $extensions_array = ['jpg', 'jpeg', 'png', 'gif'];
            if (isset($this->request->data['profile_photo']['name']) && !empty($this->request->data['profile_photo']['name']) && $this->request->data['profile_photo']['error'] == 0) {
                //$upload_folder = _BASE_ . 'webroot/uploads/users';
                $upload_folder = $_SERVER['DOCUMENT_ROOT'] . '/hairsaloon/webroot/img/uploads/users/photos';
                $file_name = 'customer_' . time() . '_' . basename($this->request->data['profile_photo']['name']);

                // check image extension
                $file_extension = pathinfo($this->request->data['profile_photo']['name'], PATHINFO_EXTENSION);
                $file_extension = strtolower($file_extension);

                if (!in_array($file_extension, $extensions_array)) {
                    $this->message = $this->msgDictonary['invalid_extension'];
                    $this->respond();
                } else {
                    if (move_uploaded_file($this->request->data['profile_photo']['tmp_name'], $upload_folder . '/' . $file_name)) {
                        // save image to db
                        $this->request->data['profile_photo'] = $file_name;
                    } else
                        unset($this->request->data['profile_photo']);
                }
            } else if (isset($this->request->data['profile_photo']))
                unset($this->request->data['profile_photo']);
            $user = $this->Users->get($this->loggedInUserId);
            $user = $this->Users->patchEntity($user, $this->request->data);
            if ($this->Users->save($user)) {
                $user_data['id'] = $user['id'];
                $user_data['first_name'] = $user['first_name'];
                $user_data['last_name'] = $user['last_name'];
                $user_data['email'] = $user['email'];
                $user_data['mobile'] = $user['mobile'];
                $user_data['profile_photo'] = ($user['profile_photo']) ? _BASE_ . 'img/uploads/users/photos/' . $user['profile_photo'] : $user['profile_photo'];
                $this->status = true;
                $this->message = $this->msgDictonary['profile_update'];
                $this->responseData = $user_data;
            } else {
                $this->message = $this->errors = $this->get_errors($user->errors());
            }
        }
        $this->respond();
    }

    public function addAddress() {
        if ($this->request->is('post')) {
            $this->loadModel('UserAddresses');
            $user_id = $this->loggedInUserId;
            $this->paramsAvailability($this->request->data, array('address_1', 'address_2', 'city', 'phone', 'state', 'postcode'));
//            $this->paramsValidation(array('address_1' => 'notBlank', 'address_2' => 'notBlank', 'city' => 'notBlank', 'phone' => 'notBlank', 'state' => 'notBlank', 'postcode' => 'notBlank'));
            $this->request->data['user_id'] = $user_id;
            $this->request->data['country_id'] = $this->request->data['country'];
            $userAddress = $this->UserAddresses->newEntity();
            $userAddress = $this->UserAddresses->patchEntity($userAddress, $this->request->data);
            if ($this->UserAddresses->save($userAddress)) {
                $uAddress = $this->UserAddresses->find('all')->where(['UserAddresses.user_id' => $user_id])->toArray();
                $this->status = true;
                $this->message = 'Address Saved';
                $this->responseData = $uAddress;
            } else {
                $this->status = false;
                $this->message = 'Address not Saved';
            }
        }
        $this->respond();
    }

    public function editAddress() {
        if ($this->request->is('post')) {
            $this->loadModel('UserAddresses');
            $userAddress = $this->UserAddresses->get($this->request->data['id']);
            $userAddress = $this->UserAddresses->patchEntity($userAddress, $this->request->data);
            if ($this->UserAddresses->save($userAddress)) {
                $uAddress = $this->UserAddresses->find('all')->where(['UserAddresses.user_id' => $this->request->data['user_id']])->toArray();
                $this->status = true;
                $this->message = 'Address Updated';
                $this->responseData = $uAddress;
            } else {
                $this->status = false;
                $this->message = 'Address not Updated';
            }
        }
        $this->respond();
    }

    public function getUserAddresdses() {
        if ($this->request->is('post')) {
            $user_id = $this->loggedInUserId;
            $this->loadModel('UserAddresses');
            $query = $this->UserAddresses->find();
            $query->where(['UserAddresses.user_id' => $user_id]);
            $query->contain(['Countries'])->order(['UserAddresses.created' => 'DESC']);
            $uAddress = $query->map(function ($row) { // map() is a collection method, it executes the query
                        $row->created = $row->created->format('Y-m-d');
                        $row->updated = $row->updated->format('Y-m-d');
                        $row->full_name = $row->first_name . ' ' . $row->last_name;
                        return $row;
                    })->toArray();

            if (!empty($uAddress)) {
                $this->status = true;
                $this->responseData = $uAddress;
            } else {
                $this->status = false;
                $this->responseData = [];
            }
        } else {
            $this->status = false;
            $this->message = $this->msgDictonary['technical_error'];
        }
        $this->respond();
    }

    public function removeAddress() {
        if ($this->request->is('post')) {
            $this->loadModel('UserAddresses');
            $entity = $this->UserAddresses->get($this->request->data['id']);
            if ($entity) {
                $delete = $this->UserAddresses->delete($entity);
                $uAddress = $this->UserAddresses->find('all')->where(['UserAddresses.user_id' => $this->request->data['user_id']])->toArray();
                $this->status = true;
                $this->responseData = $uAddress;
            } else {
                $this->status = false;
                $this->message = 'This address not found';
                $this->responseData = [];
            }
        }
        $this->respond();
    }

    public function getUserSigleAddresdss() {
        if ($this->request->is('post')) {
            $this->loadModel('UserAddresses');
            $result = $this->UserAddresses->find()->where(['id' => $this->request->data['id']])->first();
            if (!empty($result)) {
                $this->status = true;
                $this->responseData = $result;
            } else {
                $this->status = false;
                $this->responseData = [];
            }
        } else {
            $this->status = false;
            $this->message = $this->msgDictonary['technical_error'];
        }
        $this->respond();
    }

    public function getUserAddress() {
        if ($this->request->is('post')) {
            $this->loadModel('UserAddresses');
            $this->paramsValidation(array('user_id' => 'notBlank'));
            $query = $this->UserAddresses->find();
            $query->where(['UserAddresses.user_id =' => $this->request->data['user_id']]);
            $userAddress = $query->toArray();
            if (!empty($userAddress)) {
                $this->status = true;
                $this->responseData = $userAddress;
                $this->message = $this->msgDictonary['data_found'];
            } else {
                $this->status = false;
                $this->message = $this->msgDictonary['data_not_found'];
            }
        }
        $this->respond();
    }

    public function createOrder() {
        if ($this->request->is('post')) {
            /* ------------save cards------------------- */

            require_once(ROOT . '/vendor' . DS . 'stripe' . DS . 'init.php');
            \Stripe\Stripe::setApiKey('sk_test_akFcdNP70Cip5WAXJr79SEOM');

//            $charge = \Stripe\Charge::create(array("card" => array(
//                            "number" => "4242424242424242",
//                            "exp_month" => 1,
//                            "exp_year" => 2017,
//                            "cvc" => "314",
//            )));
//            pr($charge);
//            exit;
            $TokenResult = \Stripe\Token::create(array(
                        "card" => array(
                            "number" => "4242424242424242",
                            "exp_month" => 1,
                            "exp_year" => 2017,
                            "cvc" => "314"
                        )
            ));
            //echo "<pre>";;
            print_r($TokenResult);
            exit;
//            $this->token = $TokenResult['id']; //store token id into token variable
//            $this->chargeCard($this->token);
//            Customer::create(array(
//                "description" => "Customer for test@example.com",
//                "source" => $t->id));
//            exit();

            $customer = Customer::create(array(
                        "email" => 'amitkumar@mailinator.com',
                        "description" => 'amit sharma',
                        "source" => $token // obtained with Stripe.js
            ));

            $charge = \Stripe\Charge::create(array('customer' => 'cus_BoHa9378yfmduD', 'amount' => 10 * 100, 'currency' => 'gbp'));
            pr($charge);
            exit;

            // $charge = \Stripe\Charge::create(array('source' => $this->request->data['payment_token'], 'amount' => $this->request->data['order_price'] * 100, 'currency' => 'gbp'));
        }

        $this->respond();
    }

    public function changePassword() {
        if ($this->request->is('post')) {
            $user_id = $this->loggedInUserId;
            if ($user_id) {
                if ($user_id) {
                    $this->paramsAvailability($this->request->data, array('old_password', 'new_password'));
                    $users = $this->Users->get($user_id, ['contain' => []]);
                    $this->request->data['email'] = $users->email;
                    $this->request->data['password'] = $this->request->data['old_password'];
                    if (!empty($this->request->data)) {
                        $CheckPassword = $this->Auth->identify();
                        if (!empty($CheckPassword)) {
                            $user = $this->Users->patchEntity($users, [
                                'old_password' => $this->request->data['old_password'],
                                'password' => $this->request->data['new_password']]);
                            $this->Users->save($user);
                            $user_data['id'] = $user['id'];
                            $user_data['auth_token'] = $user['auth_token'];
                            $user_data['name'] = $user['first_name'] . ' ' . $user['last_name'];
                            $user_data['email'] = $user['email'];
                            $user_data['postcode'] = $user['postcode'];
                            $user_data['profile_pic'] = ($user['profile_photo'] != '') ? _BASE_ . "img/uploads/users/photos/" . $user['profile_photo'] : $user['profile_photo'];

                            if ($this->Users->save($user)) {
                                $this->status = true;
                                $this->responseData = $user_data;
                                $this->message = $this->msgDictonary['reset_password'];
                            } else {
                                $this->status = false;
                                $this->message = $this->Default->get_errors($user->errors());
                            }
                        } else {
                            $this->status = false;
                            $this->message = $this->msgDictonary['password_wrong'];
                        }
                    }
                }
            } else {
                $this->status = true;
                $this->message = $this->msgDictonary['profile_not_found'];
            }
            $this->respond();
        }
    }

    /*
     * Method : my profile
     * Params : null
     * Return : user data
     * Desc : get user's profile data
     */

    public function userprofile() {
        $user_id = $this->loggedInUserId;
        $users_data = $this->Users->find()->select([
                            'Users.id',
                            'Users.first_name',
                            'Users.last_name',
                            'Users.mobile',
                            'Users.email',
                            'Users.postcode',
                            'Users.profile_photo'
                        ])
                        ->where(['status' => 1, 'id' => $user_id])
                        ->first()->toArray();

        $users_data['profile_photo'] = ($users_data['profile_photo'] != '') ? _BASE_ . "img/uploads/users/photos/" . $users_data['profile_photo'] : _BASE_ . "img/uploads/restaurants/photos/index.png";
        if (!empty($users_data)) {
            $this->status = true;
            $this->responseData = $users_data;
            $this->message = $this->msgDictonary['record_found'];
        } else {
            $this->status = true;
            $this->message = $this->msgDictonary['no_record_found'];
        }
        $this->respond();
    }

    /*
     * Method : editProfile
     * Params : first name,last name,mobile,question,answer
     * Return : null
     * Desc : update user's profile data
     */

    public function editProfile() {
        if ($this->request->is('post')) {
            $this->request->data['user_id'] = $this->loggedInUserId;
            $user = $this->Users->find()->where(['id' => $this->request->data['user_id']])->first();
            $user['first_name'] = $this->request->data['first_name'];
            $user['last_name'] = $this->request->data['last_name'];
            $user['mobile'] = $this->request->data['mobile'];
            if (!empty($user)) {
                if ($resultUpdate = $this->Users->save($user)) {
                    $user_data['id'] = $resultUpdate->id;
                    $user_data['auth_token'] = $resultUpdate->auth_token;
                    $user_data['first_name'] = $resultUpdate->first_name;
                    $user_data['last_name'] = $resultUpdate->last_name;
                    $user_data['email'] = $resultUpdate->email;
                    $user_data['mobile'] = $resultUpdate->mobile;
                    $user_data['postcode'] = $resultUpdate->postcode;
                    $user_data['device_id'] = $resultUpdate->device_id;
                    $user_data['device_type'] = $resultUpdate->device_type;
                    $user_data['profile_pic'] = ($resultUpdate->profile_photo != '') ? _BASE_ . "img/uploads/users/photos/" . $resultUpdate->profile_photo : $resultUpdate->profile_photo;
                    $this->status = true;
                    $this->responseData = $user_data;
                    $this->message = "Your Profile has been updated successfully";
                } else {
                    $this->status = false;
                    $this->message = $this->errors = $this->Default->get_errors($resultUpdate->errors());
                }
            } else {
                $this->status = true;
                $this->message = $this->msgDictonary['no_record_found'];
            }
            $this->respond();
        }
    }

    public function uploadProfileImage() {
        $this->request->data['user_id'] = $this->loggedInUserId;
        ;
        $user = $this->Users->find()->where(['id' => $this->request->data['user_id']])->first();
        $user['profile_photo'] = $_FILES['file']['name'];
        $target_path = BASE_PATH_USER_IMAGE;
        $target_path = $target_path . basename($_FILES['file']['name']);
        if (move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {
            if ($resultUpdate = $this->Users->save($user)) {
                $user_data['profile_pic'] = ($resultUpdate->profile_photo != '') ? _BASE_ . "img/uploads/users/photos/" . $resultUpdate->profile_photo : '';
                $this->status = true;

                $this->message = 'Image Uploaded Successfully';
            } else {
                $this->status = false;

                $this->message = $this->errors = $this->Default->get_errors($resultUpdate->errors());
            }
        } else {
            $this->status = true;

            $this->message = 'Error in image uploading';
        }
        $this->respond();
    }

}
