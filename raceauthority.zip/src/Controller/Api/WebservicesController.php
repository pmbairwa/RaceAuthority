<?php

namespace App\Controller\Customer;

use App\Controller\Customer\AppController;
use Cake\Core\Configure;

class WebservicesController extends AppController {

    public function initialize() {
        parent::initialize();
        ///auth alllow
        $this->Auth->allow(array('testwebservices'));
        //header allow origin//
        header('Access-Control-Allow-Origin: *');
    }

    public function testwebservices() {
        $this->viewBuilder()->layout('ajax');
        $customer_Arr = array('users/login', 'users/register', 'users/forgot', 'users/reset', 'users/updateDevice', 'users/cardValidate', 'users/cardDetails', 'users/profile', 'users/update','users/getAddress','users/savedAddress');
        $pages_Arr = array('pages/home', 'pages/getCost', 'pages/customerQA');
        $add_on_Arr = array('addOns/listing');
        $orders_Arr = array('orders/add', 'orders/myOrders', 'orders/details', 'orders/orderValidate','orders/cancelOrder');
        $actions = array_merge($customer_Arr, $pages_Arr, $add_on_Arr, $orders_Arr);

        foreach ($actions as $key => $action) {
            switch ($action) {
                case 'users/login':
                    $dataRequest[$key] = '{"email":"sandeep@appsder.com","password":"123456"}';
                    break;
                case 'users/register':
                    $dataRequest[$key] = '{"name" : "ppp","email" : "sandeep@appsder.com","password" : "123456","phone" : "123456"}';
                    break;
                case 'users/forgot':
                    $dataRequest[$key] = '{"email":"sandeep@appsder.com"}';
                    break;
                case 'users/reset':
                    $dataRequest[$key] = '{"email" : "sandeep@appsder.com","password" : "123456","verification_code" : "411620"}';
                    break;
                case 'users/updateDevice':
                    $dataRequest[$key] = '{"device_id" : "fr456y","device_type" : "android"}';
                    break;
                case 'users/cardValidate':
                    $dataRequest[$key] = '{"id" : "","card_name" : "DS Developer","card_number" : "4556540398946660","expiry" : "062021","cvv" : "123","type" : "add"}';
                    break;
                case 'users/cardDetails':
                    $dataRequest[$key] = '{}';
                    break;
                case 'users/profile':
                    $dataRequest[$key] = '{}';
                    break;
                case 'users/update':
                    $dataRequest[$key] = '{"name" : "new user","profile_pic" : ""}';
                    break;
                case 'users/getAddress':
                    $dataRequest[$key] = '{}';
                    break;
                case 'users/savedAddress':
                    $dataRequest[$key] = '{}';
                    break;
                case 'orders/cancelOrder':
                    $dataRequest[$key] = '{"id": 1,"status":9}';
                    break;
                case 'pages/home':
                    $dataRequest[$key] = '{}';
                    break;
                case 'pages/getCost':
                    $dataRequest[$key] = '{"cart_data": [{"item_type": 1,"id": 1},{"item_type": 2,"id": 3},{"item_type": 3,"id": 1},{"item_type": 4,"id": 6}]}';
                    break;
                case 'pages/customerQA':
                     $dataRequest[$key] = '{}';
                    break;
                case 'addOns/listing':
                    $dataRequest[$key] = '{}';
                    break;
                case 'orders/add':
                    $dataRequest[$key] = '{"pickup_date": "2017-02-24", "pickup_time_from": "10:00","pickup_time_to": "13:00","delivery_date": "2017-02-25", "delivery_time_from": "10:00", "delivery_time_to": "12:00", "instruction": "any special instruction", "user_address": { "address_line_1": "jhalana","address_line_2": "jaipur", "postcode": "302020","latitude": "","longitude": ""},
"order_details": [{ "service_id": "1","item_id": "1", "weight": "2", "item_type": "1"},{ "service_id": "1","item_id": "3", "item_type": "2"},{ "service_id": "1","item_id": "3", "item_type": "2"},{ "service_id": "1","item_id": "1","quantity": "2", "item_type": "3"},{ "service_id": "2","item_id": "6","quantity": "2", "item_type": "4"}]}';
                    break;
                case 'orders/myOrders':
                    $dataRequest[$key] = '{"limit": "", "page": ""}';
                    break;
                case 'orders/details':
                    $dataRequest[$key] = '{"id": "63"}';
                    break;
                case 'orders/orderValidate':
                    $dataRequest[$key] = '{}';
                    break;
                case 'default':
                    $dataRequest[$key] = 'Invalid Request';
                    break;
            }
        }
        $this->set(compact('actions', 'dataRequest'));
    }

}
