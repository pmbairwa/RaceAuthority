<?php

/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link      http://cakephp.org CakePHP(tm) Project
 * @since     0.2.9
 * @license   http://www.opensource.org/licenses/mit-license.php MIT License
 */

namespace App\Controller\Api;

use Cake\Controller\Controller;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\ORM\TableRegistry;
use Cake\Network\Exception\UnauthorizedException;
use Cake\Network\Response;
use Cake\Mailer\Email;
use Cake\Log\Log;

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @link http://book.cakephp.org/3.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller {

    /**
     * Initialization hook method.
     *
     * Use this method to add common initialization code like loading components.
     *
     * e.g. `$this->loadComponent('Security');`
     *
     * @return void
     */
    public $status = false;
    public $message = '';
    public $responseData = [];
    public $code = 200;
    public $errors = '';
    public $authAllowedMethods = ['login', 'register', 'getCountryState', 'socialRegister', 'getReviews', 'getAllSliders', 'postReview', 'forgot', 'createOrderPayment','getCategoryListing', 'getProductReview', 'removeAddress', 'getUserAddress', 'editAddress', 'getUserSigleAddresdss', 'getCategories', 'reset', 'getAllProducts', 'allServices', 'getProductDetail', 'getProductsByCategory', 'getAllSalons', 'getSalonDetail', 'employeeDetail', 'getSalonEmployee', 'registerseller', 'registerbuyer'];
    public $testMethods = ['testwebservices'];
    public $loggedInUserId = null;
    public $settings = null;
    public $msgDictonary = array(
        // request 
        'invalid_login' => 'Username or password is incorrect',
        'invalid_token' => 'Invalid Token',
        'invalid_api_token' => 'Invalid Api Token',
        'invalid_request' => 'Invalid Request',
        'invalid_csrf_token' => 'Unable to identify request origin',
        'params_not_available' => 'The required parameter is not available in the request',
        'empty_request' => 'Request data is empty',
        'invalid_params' => 'Requested parameter should be numeric',
        'blank_params' => 'Some of your parameter is blank',
        'invalid_device' => 'You have loggedIn on another device.',
        // server error
        'technical_error' => 'Some technical error has occurred',
        'page_not_found' => 'Page not found',
        'no_record_found' => 'No record found',
        //account
        'invalid_account' => 'Entered Email address is invalid',
        'verification_account' => 'Entered verification code is invalid',
        'deactivated_account' => 'Your account has been deactivated, Please contact Administrator for further assistance',
        'verification_pending' => 'Your email address verification is pending',
        'forgot_password' => 'A verification code has been sent to your email account',
        'process_failed' => 'Your process failed. Please try again',
        'reset_password' => 'Your password has been updated successfully.',
        'account_deleted' => 'Your account has been deleted successfully.',
        //login signup logout
        'logout_success' => 'You have logged out successfully',
        'login_success' => 'You have logged in successfully',
        'signup_success' => 'A verification link has been sent to your email account, Please verify your account.',
        'signup_success_without_email' => 'Registration Successfull.',
        // profile
        'profile_not_found' => 'Profile you have requested did not found',
        'profile_update' => 'Your profile has been updated successfully',
        'update_device' => 'Updated successfully',
        'record_found' => 'List found.',
        // user images
        'invalid_extension' => 'Image not uploaded because of extension issue.',
        'image_success' => 'Profile pic uploaded successfully.',
        // Orders
        'order_success' => 'Thank you, your order has been placed.',
        'order_update' => 'Order has been updated.',
        'card_validate' => 'Card verified',
        'card_validate_fail' => 'Card verification failed',
        'card_update' => 'Card updated',
        'update_status' => 'Status updated',
        'comment_saved' => "Comment saved",
        'error_update_Laundromat' => "Error while updating laundromat commission data",
        'invalid_pincode' => "Sorry for the inconvenience we are not providing any service to this pin code.",
        'address_already_exist' => "Sorry for the inconvenience address already exist.",
        'content_not_found' => 'No content available for the given alias',
        'data_found' => 'Record Found',
        'data_not_found' => 'Record Not Found',
        'review_submit' => 'Review has been sumitted',
        'password_wrong' => "Your old password is wrong",
        'data_saved' => "Data Saved",
        'data_not_saved' => "Data not Saved",
        'order_failed' => 'Order was not compelted as payment was failed',
        'order_crated' => 'Order has been made successfully',
        'product_add' => 'Product has been submitted.',
    );

    public function initialize() {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: content-type,csrf-token,auth-token');
        header('Content-Type: application/json');
        header('Access-Control-Request-Method: POST');
        parent::initialize();
        $this->loadComponent('RequestHandler');
        $this->loadComponent('Default');
        if ($this->request->prefix == 'api') {
            $this->loadComponent('Auth', [
                'authenticate' => [
                    'Form' => [
                        'finder' => 'authCustomer',
                        'fields' => [
                            'username' => 'email',
                            'password' => 'password'
                        ]
                    ]
                ]
            ]);
        }
        $this->loadModel('Users');
        $this->loadModel('Settings');
        $this->settings = $this->Settings->getAllSettings();

        $this->getJsonInput();
        if (!in_array($this->request->action, $this->testMethods)) {
            $this->verifyRequest();
            $this->checkAuthToken();
        }
    }

    public function beforeFilter(Event $event) {
        
    }

    /*
     * Method : verifyRequest
     * Params : csrf_token from requested headers
     * Return :
     * Desc : verify request for csrf_token
     */

    public function verifyRequest() {
        $authInformation = getallheaders();
        $parametertocheck = '';
        if (isset($authInformation['csrf-token'])) {
            $parametertocheck = 'csrf-token';
        } elseif (isset($authInformation['Csrf-Token'])) {
            $parametertocheck = 'Csrf-Token';
        } else {
            $parametertocheck = 'csrf-token';
        }
        $this->paramsAvailability($authInformation, array($parametertocheck));
        if ($authInformation[$parametertocheck] != $this->settings['csrf_token']) {
            $this->status = false;
            $this->message = $this->msgDictonary['invalid_csrf_token'];
            $this->respond();
        }
    }

    /*
     * Method : paramsAvailability
     * Check : This method check parameters availability in the request
     */

    public function paramsAvailability($source, $paramsToChecks) {
        foreach ($paramsToChecks as $value) {
            if (!array_key_exists($value, $source)) {
                $this->status = false;
                $this->message = $value . $this->msgDictonary['params_not_available'];
                $this->responseData = [$value];
                // respond  method will automatically exit from the loop when the rquired params not found
                $this->respond();
            }
        }
    }

    /*
     * Method : getJsonInput
     * Check : This method used to parse input request data
     * Params : json params
     */

    public function getJsonInput() {
        $data = file_get_contents("php://input");
        $this->request->data = (isset($data) && $data != '') ? json_decode($data, true) : $this->request->data;
    }

    /*
     * Method : checkAuthToken
     * Check : This method check token for each request except the allowed methods
     * Params : auth_token:6465s4df6g4s65d4fg6
     */

    public function checkAuthToken() {
        if (!in_array($this->request->action, $this->authAllowedMethods)) {
            $authInformation = getallheaders();
            $parametertocheck = '';
            if (isset($authInformation['auth-token'])) {
                $parametertocheck = 'auth-token';
            } elseif (isset($authInformation['Auth-Token'])) {
                $parametertocheck = 'Auth-Token';
            } else {
                $parametertocheck = 'auth-token';
            }
            $this->paramsAvailability($authInformation, array($parametertocheck));
            $authenticate = $this->Users->find()->select(['id'])->where(['auth_token' => $authInformation[$parametertocheck]])->first();
            if (empty($authenticate)) {
                $this->message = $this->msgDictonary['invalid_token'];
                $this->code = 401;
                $this->respond();
            } else {
                $this->loggedInUserId = $authenticate['id'];
                $action = $this->request->action;
                $this->Auth->allow($action);
            }
        }
    }

    /*
     * Method : paramsValidation
     * Check : Checks for empty request data, validate data against datatypes
     */

    public function paramsValidation($params) {
        if (empty($this->request->data)) {
            $this->status = false;
            $this->message = $this->msgDictonary['empty_request'];
            $this->respond();
        }
        foreach ($params as $key => $value) {
            $this->paramsAvailability($this->request->data, array($key));
            switch ($value) {
                case 'numeric':
                    if (!is_numeric($this->request->data[$key])) {
                        $this->message = $this->msgDictonary['invalid_params'];
                        // $this->responseData = array($key);
                        $this->respond();
                    }
                    break;
                case 'notBlank':
                    if ($this->request->data[$key] == '') {
                        $this->message = $this->msgDictonary['blank_params'];
                        //$this->responseData = array($key);
                        $this->respond();
                    }
                    break;
                default:
                    return true;
            }
        }
    }

    /*
     * Method : getGUID
     * Params : get guid for unique auth token
     * Return : a unique string
     */

    function getGUID() {
        if (function_exists('com_create_guid')) {
            return com_create_guid();
        } else {
            mt_srand((double) microtime() * 10000); //optional for php 4.2.0 and up.
            $charid = strtoupper(md5(uniqid(rand(), true)));
            $hyphen = chr(45); // "-"
            $uuid = //chr(123)// "{"
                    substr($charid, 0, 8) . $hyphen
                    . substr($charid, 8, 4) . $hyphen
                    . substr($charid, 12, 4) . $hyphen
                    . substr($charid, 16, 4) . $hyphen
                    . substr($charid, 20, 12);
            // .chr(125);// "}"
            return $uuid;
        }
    }

    public function getStatusText($status) {
        switch ($status) {
            case 0:
                return 'ACCEPT';
                break;
            case 1:
                return 'PICKUP BAG';
                break;
            case 2:
                return 'AT LAUNDROMAT';
                break;
            case 3:
                return 'DELIVER';
                break;
            case 'default':
                return 'COMPLETED';
                break;
        }
    }

    /*
     * Method : respond
     * Check : This method is used to make response
     * Desc : make, return and stop response
     */

    public function respond() {

        if (empty($this->responseData))
            $this->responseData = '';
        $this->response->type('json');

        $resultJ = json_encode(['status' => $this->status,
            'code' => $this->code,
            'data' => $this->responseData,
            'message' => $this->message]
        );
//        pr($resultJ);
//        exit;



        $this->response->body($resultJ);
        $this->response->send();

//        $this->response->body([
//            'status' => $this->status,
//            'code' => $this->code,
//            'data' => $this->responseData,
//            'message' => $this->message,
//                //'errors' => $this->errors,
//        ]);
        //$this->response->send();
        $this->response->stop();
    }

//    public function pushNotificationToDeviceolddfs($deviceId, $body, $deviceType, $role_id) {
//
//        if (strtolower($deviceType) == "ios" && $deviceId != '') {
//            $deviceToken = $deviceId;
//
//            $ctx = stream_context_create();
//            // ck.pem is your certificate file
//            if ($role_id == 3) {
//                stream_context_set_option($ctx, 'ssl', 'local_cert', 'pem/DevPushCustomer.pem');  // For customer
//            } else if ($role_id == 2) {
//                stream_context_set_option($ctx, 'ssl', 'local_cert', 'pem/DevPushEmployee.pem');  // For Employee
//            }
//
//            stream_context_set_option($ctx, 'ssl', 'passphrase', '');
//
//            // Open a connection to the APNS server
//            $fp = stream_socket_client(
//                    //'ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
//                    'ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
//
//            if (!$fp)
//                exit("Failed to connect: $err $errstr" . PHP_EOL);
//
//
//            // Create the payload body
//            $body['aps'] = array(
//                'alert' => array(
//                    'title' => $body['title'],
//                    'body' => $body['body'],
//                    'order_id' => $body['order_id']
//                ),
//                'sound' => 'default'
//            );
//
//            // Encode the payload as JSON
//            $payload = json_encode($body);
//            if (is_array($deviceToken)) {
//                foreach ($deviceToken as $device) {
//                    $msg = chr(0) . pack('n', 32) . pack('H*', $device) . pack('n', strlen($payload)) . $payload;
//                    $result = fwrite($fp, $msg, strlen($msg));
//                }
//            } else {
//                $msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;
//                $result = fwrite($fp, $msg, strlen($msg));
//            }
//            // Close the connection to the server
//            fclose($fp);
//
//            if (!$result)
//                return 'Message not delivered' . PHP_EOL;
//            else
//                return 'Message successfully delivered' . PHP_EOL;
//        }
//
//        if (strtolower($deviceType) == "android" && $deviceId != '') {
//            //-------------------------- ANDROID CONNECTION --------------------------------
//            $url = 'https://fcm.googleapis.com/fcm/send';
//
//            if ($role_id == 3) {
//                $key = 'AIzaSyDKPjC3OcgKQ-bNT9anJ4a4_HE7WA3zcv4';  // For customer
//            } else if ($role_id == 2) {
//                $key = 'AIzaSyB1RPhdZ6r4V2TbhnA_90zuuWWK62ZgbR4';  // For Employee
//            }
//
//            $headers = array(
//                'Authorization: key=' . $key, //'AIzaSyDzGmc2V0y9LI9MbJt8oK3TVwU9BW0CLbU',//GOOGLE_API_KEY,
//                'Content-Type: application/json'
//            );
//            if (!is_array($deviceId))
//                $deviceId = array($deviceId);
//
//            $finalmsg["message"] = $body['body'];
//            $finalmsg["title"] = $body['title'];
//            $finalmsg["order_id"] = $body['order_id'];
//            $finalmsg["unique_key"] = mt_rand(10000, 99999);
//            $finalmsg["priority"] = 'high'; // new
//            $fields = array(
//                'registration_ids' => $deviceId,
//                'data' => $finalmsg,
//                'priority' => 'high' // new fcm
//            );
//
//
//            $ch = curl_init();
//            curl_setopt($ch, CURLOPT_URL, $url);
//            curl_setopt($ch, CURLOPT_POST, true);
//            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
//            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
//            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
//
//            $result = curl_exec($ch);
//
//            curl_close($ch);
//        }
//    }
//
//    public function pushNotificationToDevicettafasf($devID, $message, $cert) {
//        echo "\n sending gcm to " . $devID;
//        $cert = 'AIzaSyDKPjC3OcgKQ-bNT9anJ4a4_HE7WA3zcv4';
//        $message = array("message" => "We\'re only a few minutes away from # kick-off. Time to tweet your support!",
//            "title" => "Arsenal vs Fulham ");
//        $registatoin_ids = 'dcs9GJlJeRA:APA91bFnMDWRXl4I4Li2CaoucVSh5R5yONhbna75zRvZkLY78B4Nz62dvVr_39R9NMSoposYHeS3_QbfsuPJcMveVs876eJCB7dF4zwn425eeI6FbKREAYemqHqlVVH1XpYlY14KBFTk';
//        $url = 'https://android.googleapis.com/gcm/send';
//
//        $fields = array(
//            'registration_ids' => $registatoin_ids,
//            'data' => $message,
//        );
//
//        $headers = array(
//            'Authorization: key=' . $cert,
//            'Content-Type: application/json'
//        );
//        // Open connection
//        $ch = curl_init();
//
//
//        // Set the url, number of POST vars, POST data
//        curl_setopt($ch, CURLOPT_URL, $url);
//
//        curl_setopt($ch, CURLOPT_POST, true);
//        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
//        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//
//        // Disabling SSL Certificate support temporarly
//        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
//
//        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
//
//        // Execute post
//        $result = curl_exec($ch);
//        if ($result === FALSE) {
//            die('Curl failed: ' . curl_error($ch));
//        }
//
//        // Close connection
//        curl_close($ch);
//        echo $result;
////        $post_data = file_get_contents('php://input');
//    }

    public function pushNotificationToDevice($deviceId, $body, $deviceType, $role_id) {

        //ignore_user_abort();
        //ob_start();
        $message = array
            (
            'message' => $body['body'],
            'title' => $body['title'],
            'subtitle' => 'Alert message!',
//            'order_id' => $body['order_id'],
            'vibrate' => 1,
            'sound' => 'default',
            'largeIcon' => 'large_icon',
            'smallIcon' => 'small_icon'
        );
        $url = 'https://fcm.googleapis.com/fcm/send';

        $fields = array(
            'to' => $deviceId,
            'data' => $message,
        );

        /* if ($role_id == 3) { echo 'a'; die;
          define('GOOGLE_API_KEY', 'AAAAvvyor6o:APA91bE9-uqBd6bmLTVxkuZlCOJFrKsT2oJOm2M5PhZH0RFFgrVaE0iPqr3PqRMc_TKqaBVSFgifhj1XOWRVisqsCX2lNmBe8A2O8GTbBh0Re5CbUPMkfjN51v8v-2yTv5iqr012GOYv');
          } else if ($role_id == 2) { echo 'b'; die;
          define('GOOGLE_API_KEY', 'AAAAd5Oi6SM:APA91bGvYTigYpgejASIs2DD8NJIDmR6wJIp9e3tDe-akSQbXpA-sjwiQ2cEqiuEwG05D7tNHu6P_Y0x--owOk-AGoZPr18jrNGopmEahdoODNOiF2Sj0WWHMnwXBHh3a-U80XamTZ6-');
          } */
        if ($role_id == 3) {
            $headers = array(
                'Authorization:key=' . Configure::read('CustomerKey'),
                'Content-Type: application/json'
            );
        } else if ($role_id == 2) {
            $headers = array(
                'Authorization:key=' . Configure::read('DriverKey'),
                'Content-Type: application/json'
            );
        }



        /* $headers = array(
          'Authorization:key=' . Configure::read('DriverKey'),
          'Content-Type: application/json'
          ); */

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $result = curl_exec($ch);

        if ($result == 1) {

            return true;
        } else {
//            die('Curl failed ' . curl_error());
            return false;
        }


        curl_close($ch);
//        return $result;
        //ob_flush();
    }

    public function checkIfRecordExist($modelName = null, $condtions = null) {
        $data = $this->$modelName->find()->where($condtions)->first();
        if ($data) {
            return 1;
        } else {
            return 0;
        }
    }

//        gcm($countDeviceId2, $msg, 'AIzaSyBT_NjP04tllpdlW1K1LC9qa9DwTKnZckg');
}
