<?php
namespace App\Controller\Admin;

use App\Controller\AppController;

/**
 * ActivationCodes Controller
 *
 * @property \App\Model\Table\ActivationCodesTable $ActivationCodes
 *
 * @method \App\Model\Entity\ActivationCode[] paginate($object = null, array $settings = [])
 */
class ActivationCodesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Products']
        ];
        $activationCodes = $this->paginate($this->ActivationCodes);

        $this->set(compact('activationCodes'));
        $this->set('_serialize', ['activationCodes']);
    }

    /**
     * View method
     *
     * @param string|null $id Activation Code id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $activationCode = $this->ActivationCodes->get($id, [
            'contain' => ['Products']
        ]);

        $this->set('activationCode', $activationCode);
        $this->set('_serialize', ['activationCode']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add($id=null)
    {
        if($id){
            $activationCode = $this->ActivationCodes->get($id, [
                'contain' => []
            ]);
        }else{
            $activationCode = $this->ActivationCodes->newEntity();
        }
        if ($this->request->is(['post', 'put'])) {
            $activationCode = $this->ActivationCodes->patchEntity($activationCode, $this->request->getData());
            if ($this->ActivationCodes->save($activationCode)) {
                $this->Flash->success(__('The activation code has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The activation code could not be saved. Please, try again.'));
        }
        $products = $this->ActivationCodes->Products->find('list', ['limit' => 200]);
        $this->set(compact('activationCode', 'products'));
        $this->set('_serialize', ['activationCode']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Activation Code id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $activationCode = $this->ActivationCodes->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $activationCode = $this->ActivationCodes->patchEntity($activationCode, $this->request->getData());
            if ($this->ActivationCodes->save($activationCode)) {
                $this->Flash->success(__('The activation code has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The activation code could not be saved. Please, try again.'));
        }
        $products = $this->ActivationCodes->Products->find('list', ['limit' => 200]);
        $this->set(compact('activationCode', 'products'));
        $this->set('_serialize', ['activationCode']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Activation Code id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $activationCode = $this->ActivationCodes->get($id);
        if ($this->ActivationCodes->delete($activationCode)) {
            $this->Flash->success(__('The activation code has been deleted.'));
        } else {
            $this->Flash->error(__('The activation code could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
