<?php
namespace App\Controller\Admin;

use App\Controller\AppController;

/**
 * SecurityQuestions Controller
 *
 * @property \App\Model\Table\SecurityQuestionsTable $SecurityQuestions
 *
 * @method \App\Model\Entity\SecurityQuestion[] paginate($object = null, array $settings = [])
 */
class SecurityQuestionsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $securityQuestions = $this->paginate($this->SecurityQuestions);

        $this->set(compact('securityQuestions'));
        $this->set('_serialize', ['securityQuestions']);
    }

    /**
     * View method
     *
     * @param string|null $id Security Question id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $securityQuestion = $this->SecurityQuestions->get($id, [
            'contain' => []
        ]);

        $this->set('securityQuestion', $securityQuestion);
        $this->set('_serialize', ['securityQuestion']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add($id=null)
    {
        if($id){
            $securityQuestion = $this->SecurityQuestions->get($id, [
                'contain' => []
            ]);
        }else{
            $securityQuestion = $this->SecurityQuestions->newEntity();
        }
        if ($this->request->is(['post', 'put'])) {
            $securityQuestion = $this->SecurityQuestions->patchEntity($securityQuestion, $this->request->getData());
            if ($this->SecurityQuestions->save($securityQuestion)) {
                $this->Flash->success(__('The security question has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The security question could not be saved. Please, try again.'));
        }
        $this->set(compact('securityQuestion'));
        $this->set('_serialize', ['securityQuestion']);
    }   

    /**
     * Delete method
     *
     * @param string|null $id Security Question id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $securityQuestion = $this->SecurityQuestions->get($id);
        if ($this->SecurityQuestions->delete($securityQuestion)) {
            $this->Flash->success(__('The security question has been deleted.'));
        } else {
            $this->Flash->error(__('The security question could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
