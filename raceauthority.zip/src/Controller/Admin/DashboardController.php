<?php

namespace App\Controller\Admin;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class DashboardController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->Users = TableRegistry::get('Users');
        $this->Reviews = TableRegistry::get('Reviews');
        $this->Vendors = TableRegistry::get('Vendors');
        $this->Products = TableRegistry::get('Products');
        $this->Orders = TableRegistry::get('Orders');
    }

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index() {
        $recentlyAddedProducts = $this->Products->find()->limit(5)->order(['id DESC'])->toArray();
        $recentOrders = $this->Orders->find()->limit(5)->order(['id DESC'])->toArray();
        $sellers = $this->Vendors->find()->limit(4)->order(['id DESC'])->toArray();
        $sellersTotal = $this->Vendors->find()->order(['id DESC'])->toArray();
        $customers = $this->Users->find()->limit(4)->order(['id DESC'])->toArray();
        $customersTotal = $this->Users->find()->order(['id DESC'])->toArray();
        $reviews = $this->Reviews->find()->count();
        $this->set(compact("reviews", "sellers", "recentlyAddedProducts", "recentOrders", 'sellers', 'customers', 'customersTotal', 'sellersTotal'));
    }

}
