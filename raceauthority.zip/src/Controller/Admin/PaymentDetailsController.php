<?php
namespace App\Controller\Admin;

use App\Controller\AppController;

/**
 * PaymentDetails Controller
 *
 * @property \App\Model\Table\PaymentDetailsTable $PaymentDetails
 *
 * @method \App\Model\Entity\PaymentDetail[] paginate($object = null, array $settings = [])
 */
class PaymentDetailsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Restaurants']
        ];
        $paymentDetails = $this->paginate($this->PaymentDetails);

        $this->set(compact('paymentDetails'));
        $this->set('_serialize', ['paymentDetails']);
    }

    /**
     * View method
     *
     * @param string|null $id Payment Detail id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $paymentDetail = $this->PaymentDetails->get($id, [
            'contain' => ['Restaurants']
        ]);

        $this->set('paymentDetail', $paymentDetail);
        $this->set('_serialize', ['paymentDetail']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add($id=null)
    {
        if($id){
            $paymentDetail = $this->PaymentDetails->get($id, [
                'contain' => []
            ]);
        }else{
            $paymentDetail = $this->PaymentDetails->newEntity();
        }
        if ($this->request->is(['post', 'put'])) {
            $paymentDetail = $this->PaymentDetails->patchEntity($paymentDetail, $this->request->getData());
            if ($this->PaymentDetails->save($paymentDetail)) {
                $this->Flash->success(__('The payment detail has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The payment detail could not be saved. Please, try again.'));
        }
        $restaurants = $this->PaymentDetails->Restaurants->find('list')->where(['Restaurants.status'=>1]);        
        $this->set(compact('paymentDetail', 'restaurants'));
        $this->set('_serialize', ['paymentDetail']);
    }
    
    /**
     * Delete method
     *
     * @param string|null $id Payment Detail id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $paymentDetail = $this->PaymentDetails->get($id);
        if ($this->PaymentDetails->delete($paymentDetail)) {
            $this->Flash->success(__('The payment detail has been deleted.'));
        } else {
            $this->Flash->error(__('The payment detail could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
