<?php

namespace App\Controller\Admin;

use App\Controller\AppController;
use Cake\Core\Configure;

/**
 * Cmspages Controller
 *
 * @property \App\Model\Table\CmspagesTable $Cmspages
 */
class CmspagesController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Default');
        $_dir = str_replace("\\", "/", $this->Cmspages->_dir);
        $this->set(compact('_dir'));
    }

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index() {
        $options['order'] = ['id' => 'DESC'];
        $options['limit'] = Configure::read('Setting.admin_page_limit');
        $options['finder'] = ['common' => ['searchKeyword' => $this->request->query]];
        $this->paginate = $options;
        $records = $this->paginate($this->{$this->modelClass});
        $this->set(array('records' => $records, 'dateformat' => Configure::read('Setting.admin_date_time_format')));
        $this->set('_serialize', ['records']);
    }

    /**
     * View method
     *
     * @param string|null $id Cmspage id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null) {
        $record = $this->{$this->modelClass}->get($id, [
            'contain' => []
        ]);

        $this->set(array('record' => $record, 'dateformat' => Configure::read('Setting.admin_date_time_format')));
        $this->set('_serialize', ['record']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add($id = null) {
        if ($id) {
            $record = $this->{$this->modelClass}->get($id, [
                'contain' => []
            ]);
        } else {
            $record = $this->{$this->modelClass}->newEntity();
        }
        if ($this->request->is(['patch', 'post', 'put'])) {

            if (trim($this->request->data['slug']) == "") {
                $this->request->data['slug'] = $this->Default->getUniqueAlias($this->request->data['title'], $this->modelClass, $id);
            } else {
                $this->request->data['slug'] = $this->Default->getUniqueAlias($this->request->data['slug'], $this->modelClass, $id);
            }            
            $record = $this->{$this->modelClass}->patchEntity($record, $this->request->data);            
            if ($this->{$this->modelClass}->save($record)) {
                $this->Flash->success(__('The cmspage has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {                
                $this->Flash->error(__('The cmspage could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('record'));
        $this->set('_serialize', ['record']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Cmspage id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null) {
        $this->request->allowMethod(['post', 'delete']);
        $record = $this->{$this->modelClass}->get($id);
        if ($this->{$this->modelClass}->delete($record)) {
            $this->Flash->success(__('The cmspage has been deleted.'));
        } else {
            $this->Flash->error(__('The cmspage could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }

    public function deleteimg($id = null) {
        $record = $this->Cmspages->get($id);
        if ($this->Cmspages->deleteImage($record->image, $record)) {
            $this->Flash->success(__('The banner has been deleted.'));
        } else {
            $this->Flash->error(__('The banner could not be deleted. Please, try again.'));
        }
        return $this->redirect($this->referer());
    }

}
