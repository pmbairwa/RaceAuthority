<?php

namespace App\Controller\Admin;

use App\Controller\AppController;
use Cake\Core\Configure;

/**
 * Categories Controller
 *
 * @property \App\Model\Table\CategoriesTable $Categories
 */
class CategoriesController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Default');
    }

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index() {
        $options['order'] = ['id' => 'DESC'];
        $options['limit'] = $this->SettingConfig['admin_paging_limit'];
        $options['finder'] = ['common' => ['searchKeyword' => $this->request->query]];

        $this->paginate = $options;
        $categories = $this->paginate($this->Categories);

        $this->set(compact('categories'));
        $this->set('_serialize', ['categories']);
    }

    /**
     * View method
     *
     * @param string|null $id Category id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null) {
        $category = $this->Categories->get($id, [
            'contain' => []
        ]);

        $this->set('category', $category);
        $this->set('_serialize', ['category']);
    }

    /**
     * Add method
     *
     * @param string|null $id Category id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
//    public function add($id = null) {
//        if ($id)
//            $category = $this->Categories->get($id, [
//                'contain' => []
//            ]);
//        else
//            $category = $this->Categories->newEntity();
//
//        $categories = $this->Categories->find('list')->where(['status' => 1])->toArray();
//
//        if ($this->request->is(['patch', 'post', 'put'])) {
//            $category = $this->Categories->patchEntity($category, $this->request->data);
//            if ($this->Categories->save($category)) {
//                $this->Flash->success(__('The category has been saved.'));
//
//                return $this->redirect(['action' => 'index']);
//            }
//            $this->Flash->error(__('The category could not be saved. Please, try again.'));
//        }
////         pr($categories);
////        exit;
//        $this->set(compact('category', 'categories'));
//        $this->set('_serialize', ['category', 'categories']);
//    }

    public function add($id = null) {
//        $this->loadModel('Categories');
        $err = '';
        if ($id)
            $category = $this->Categories->get($id, ['contain' => []]
            );
        else
            $category = $this->Categories->newEntity();
        $categories = $this->Categories->find('list')->where(['status' => 1])->toArray();

        if ($this->request->is(['put', 'post', 'patch'])) {
            $allowed_ext_img = array('jpg', 'jpeg', 'png');
            $file_ext_img = pathinfo($this->request->data['image']['name'], PATHINFO_EXTENSION);
            if (isset($this->request->data['image']) && $this->request->data['image'] != '') {
                if (isset($this->request->data['image']['name']) && $this->request->data['image']['name'] != '') {
                    if (in_array($file_ext_img, $allowed_ext_img)) {
                        $imagename = $this->Default->createImageName($this->request->data['image']['name'], BASE_PATH_CATEGORY_IMAGE, current(explode(".", $this->request->data['image']['name'])));
                        if (move_uploaded_file($this->request->data['image']['tmp_name'], BASE_PATH_CATEGORY_IMAGE . $imagename)) {
                            if ($this->request->data['old_image'] != $imagename) {
                                @unlink(BASE_PATH_CATEGORY_IMAGE . $this->request->data['old_image']);
                            }
                        }
                        $this->request->data['image'] = $imagename;
                    } else {
                        $err .= ' Please upload valid image';
                    }
                } else {
                    $this->request->data['image'] = $this->request->data['old_image'];
                }
            }
            if ($err == '') {
                $category = $this->Categories->patchEntity($category, $this->request->data);
                if ($this->Categories->save($category)) {
                    $this->Flash->success(__('Category has been saved.'));
                    $this->redirect(['controller' => 'categories', 'action' => 'index', 2]);
                } else
                    $this->Flash->error(__($this->Default->get_errors($category->errors())));
            } else {
                $this->Flash->error(__($err));
            }
        }

        $this->set(compact(['category']));
    }

    /**
     * Edit method
     *
     * @param string|null $id Category id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null) {
        $category = $this->Categories->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $category = $this->Categories->patchEntity($category, $this->request->data);
            if ($this->Categories->save($category)) {
                $this->Flash->success(__('The category has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The category could not be saved. Please, try again.'));
        }
        $this->set(compact('category'));
        $this->set('_serialize', ['category']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Category id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null) {
        $this->request->allowMethod(['post', 'delete']);
        $category = $this->Categories->get($id);
        if ($this->Categories->delete($category)) {
            $this->Flash->success(__('The category has been deleted.'));
        } else {
            $this->Flash->error(__('The category could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

}
