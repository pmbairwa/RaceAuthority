<?php
namespace App\Controller\Admin;

use App\Controller\AppController;

/**
 * ShippingMethods Controller
 *
 * @property \App\Model\Table\ShippingMethodsTable $ShippingMethods
 *
 * @method \App\Model\Entity\ShippingMethod[] paginate($object = null, array $settings = [])
 */
class ShippingMethodsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Users']
        ];
        $shippingMethods = $this->paginate($this->ShippingMethods);

        $this->set(compact('shippingMethods'));
        $this->set('_serialize', ['shippingMethods']);
    }

    /**
     * View method
     *
     * @param string|null $id Shipping Method id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $shippingMethod = $this->ShippingMethods->get($id, [
            'contain' => ['Users']
        ]);

        $this->set('shippingMethod', $shippingMethod);
        $this->set('_serialize', ['shippingMethod']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add($id=null)
    {
        if($id){
            $shippingMethod = $this->ShippingMethods->get($id, [
                'contain' => []
            ]);
        }else{
            $shippingMethod = $this->ShippingMethods->newEntity();
        }
        if ($this->request->is(['post', 'put'])) {
            $shippingMethod = $this->ShippingMethods->patchEntity($shippingMethod, $this->request->getData());
            if ($this->ShippingMethods->save($shippingMethod)) {
                $this->Flash->success(__('The shipping method has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The shipping method could not be saved. Please, try again.'));
        }
        $users = $this->ShippingMethods->Users->find('list', ['limit' => 200]);
        $this->set(compact('shippingMethod', 'users'));
        $this->set('_serialize', ['shippingMethod']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Shipping Method id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $shippingMethod = $this->ShippingMethods->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $shippingMethod = $this->ShippingMethods->patchEntity($shippingMethod, $this->request->getData());
            if ($this->ShippingMethods->save($shippingMethod)) {
                $this->Flash->success(__('The shipping method has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The shipping method could not be saved. Please, try again.'));
        }
        $users = $this->ShippingMethods->Users->find('list', ['limit' => 200]);
        $this->set(compact('shippingMethod', 'users'));
        $this->set('_serialize', ['shippingMethod']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Shipping Method id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $shippingMethod = $this->ShippingMethods->get($id);
        if ($this->ShippingMethods->delete($shippingMethod)) {
            $this->Flash->success(__('The shipping method has been deleted.'));
        } else {
            $this->Flash->error(__('The shipping method could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
