<?php
namespace App\Controller\Admin;

use App\Controller\AppController;

/**
 * PromotionalCodes Controller
 *
 * @property \App\Model\Table\PromotionalCodesTable $PromotionalCodes
 *
 * @method \App\Model\Entity\PromotionalCode[] paginate($object = null, array $settings = [])
 */
class PromotionalCodesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Salons']
        ];
        $promotionalCodes = $this->paginate($this->PromotionalCodes);

        $this->set(compact('promotionalCodes'));
        $this->set('_serialize', ['promotionalCodes']);
    }

    /**
     * View method
     *
     * @param string|null $id Promotional Code id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $promotionalCode = $this->PromotionalCodes->get($id, [
            'contain' => ['Salons']
        ]);

        $this->set('promotionalCode', $promotionalCode);
        $this->set('_serialize', ['promotionalCode']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add($id=null)
    {
        if($id){
            $promotionalCode = $this->PromotionalCodes->get($id, [
                'contain' => []
            ]);
        }else{
            $promotionalCode = $this->PromotionalCodes->newEntity();
        }
        if ($this->request->is(['post', 'put'])) {
            $promotionalCode = $this->PromotionalCodes->patchEntity($promotionalCode, $this->request->getData());
            if ($this->PromotionalCodes->save($promotionalCode)) {
                $this->Flash->success(__('The promotional code has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The promotional code could not be saved. Please, try again.'));
        }
        $salons = $this->PromotionalCodes->Salons->find('list', ['limit' => 200]);
        $this->set(compact('promotionalCode', 'salons'));
        $this->set('_serialize', ['promotionalCode']);
    }

    
    /**
     * Delete method
     *
     * @param string|null $id Promotional Code id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $promotionalCode = $this->PromotionalCodes->get($id);
        if ($this->PromotionalCodes->delete($promotionalCode)) {
            $this->Flash->success(__('The promotional code has been deleted.'));
        } else {
            $this->Flash->error(__('The promotional code could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
