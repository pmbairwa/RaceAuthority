<?php

namespace App\Controller\Admin;

use App\Controller\AppController;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[] paginate($object = null, array $settings = [])
 */
class UsersController extends AppController {

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function initialize() {
        parent::initialize();

        $this->Auth->allow(['login']);
        $this->loadComponent('Cookie');
        $this->loadComponent('Default');
    }

    public function index() {
        $this->paginate = [
            'contain' => ['Countries']
        ];
        $users = $this->paginate($this->Users);
        $this->set(compact('users'));
        $this->set('_serialize', ['users']);
    }

    /**
     * View method
     *
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null) {
        $user = $this->Users->get($id, [
            'contain' => ['Countries', 'Orders', 'Reviews', 'SavedCards', 'ShippingMethods', 'StripeCustomers', 'UserAddresses', 'UserTokens']
        ]);

        $this->set('user', $user);
        $this->set('_serialize', ['user']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add() {
        $err = '';
        $user = $this->Users->newEntity();
        if ($this->request->is(['post', 'put'])) {
            $allowed_ext_img = array('jpg', 'jpeg', 'png');
            $file_ext_img = pathinfo($this->request->data['profile_photo']['name'], PATHINFO_EXTENSION);
            if (isset($this->request->data['profile_photo']) && $this->request->data['profile_photo'] != '') {
                if (isset($this->request->data['profile_photo']['name']) && $this->request->data['profile_photo']['name'] != '') {
                    if (in_array($file_ext_img, $allowed_ext_img)) {
                        $imagename = $this->Default->createImageName($this->request->data['profile_photo']['name'], BASE_PATH_USER_IMAGE, current(explode(".", $this->request->data['profile_photo']['name'])));
                        if (move_uploaded_file($this->request->data['profile_photo']['tmp_name'], BASE_PATH_USER_IMAGE . $imagename)) {
                            $this->request->data['profile_photo'] = $imagename;
                        }
                    } else {
                        $err .= ' Please upload valid image';
                    }
                }
            }
            if ($err = '') {
                $user = $this->Users->patchEntity($user, $this->request->getData());
                if ($this->Users->save($user)) {
                    $this->Flash->success(__('The user has been saved.'));

                    return $this->redirect(['action' => 'index']);
                }
                $this->Flash->error(__('The user could not be saved. Please, try again.'));
            } else {
                $this->Flash->error(__($err));
            }
        }

       // $accountTypes = $this->Users->AccountTypes->find('list', ['limit' => 200]);
        $countries = $this->Users->Countries->find('list', ['limit' => 200]);
        $this->set(compact('user', 'countries'));
        $this->set('_serialize', ['user']);
    }

    /**
     * Edit method
     *
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null) {
        $err = '';
        $user = $this->Users->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $allowed_ext_img = array('jpg', 'jpeg', 'png');
            $file_ext_img = pathinfo($this->request->data['profile_photo']['name'], PATHINFO_EXTENSION);
            if (isset($this->request->data['profile_photo']) && $this->request->data['profile_photo'] != '') {
                if (isset($this->request->data['profile_photo']['name']) && $this->request->data['profile_photo']['name'] != '') {
                    if (in_array($file_ext_img, $allowed_ext_img)) {
                        $imagename = $this->Default->createImageName($this->request->data['profile_photo']['name'], BASE_PATH_USER_IMAGE, current(explode(".", $this->request->data['profile_photo']['name'])));
                        if (move_uploaded_file($this->request->data['profile_photo']['tmp_name'], BASE_PATH_USER_IMAGE . $imagename)) {
                            if ($this->request->data['old_image'] != $imagename) {
                                @unlink(BASE_PATH_USER_IMAGE . $this->request->data['old_image']);
                            }
                        }
                        $this->request->data['profile_photo'] = $imagename;
                    } else {
                        $err .= ' Please upload valid image';
                    }
                } else {
                    $this->request->data['profile_photo'] = $this->request->data['old_image'];
                }
            }
            if ($err == '') {
                $user = $this->Users->patchEntity($user, $this->request->getData());
                if ($this->Users->save($user)) {
                    $this->Flash->success(__('The user has been saved.'));

                    return $this->redirect(['action' => 'index']);
                }
                $this->Flash->error(__('The user could not be saved. Please, try again.'));
            } else {
                $this->Flash->error(__($err));
            }
        }
        $accountTypes = $this->Users->AccountTypes->find('list', ['limit' => 200]);
        $countries = $this->Users->Countries->find('list', ['limit' => 200]);
        $this->set(compact('user', 'accountTypes', 'countries'));
        $this->set('_serialize', ['user']);
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null) {
        $this->request->allowMethod(['post', 'delete']);
        $user = $this->Users->get($id);
        if ($this->Users->delete($user)) {
            $this->Flash->success(__('The user has been deleted.'));
        } else {
            $this->Flash->error(__('The user could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

}
