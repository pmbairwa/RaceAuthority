<?php

namespace App\Controller\Admin;

use App\Controller\AppController;
use Cake\Core\Configure;

/**
 * Settings Controller
 *
 * @property \App\Model\Table\SettingsTable $Settings
 */
class SettingsController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Default');
        $_dir = str_replace("\\", "/", $this->Settings->_dir);
        $this->set(compact('_dir'));
    }
    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index() {
        $options['order'] = ['Settings.config_name' => 'ASC'];
        if (isset($this->request->query['keyword']) && !empty($this->request->query['keyword'])) {
            $this->request->data['keyword'] = $this->request->query['keyword'];
        }
        $options['finder'] = ['general' => ['searchKeyword' => $this->request->query]];
        $options['limit'] = Configure::read('Setting.admin_page_limit');
        $this->paginate = $options;
        $settings = $this->paginate($this->Settings);
        $this->set(compact('settings'));
        $this->set('_serialize', ['settings']);
    }

    /**
     * View method
     *
     * @param string|null $id Setting id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null) {
        $setting = $this->Settings->get($id, [
            'contain' => []
        ]);

        $this->set('setting', $setting);
        $this->set('_serialize', ['setting']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add($id = null) {
        if ($id) {
            $setting = $this->Settings->get($id, [
                'contain' => []
            ]);
        } else {
            $setting = $this->Settings->newEntity();
        }
        if ($this->request->is(['patch', 'post', 'put'])) {
            $setting = $this->Settings->patchEntity($setting, $this->request->data);
            if ($this->Settings->save($setting)) {            
                $this->Flash->success(__('The setting has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The setting could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('setting'));
        $this->set('_serialize', ['setting']);
    }

    public function socials() {
        $setting = $this->Settings->newEntity();
        if ($this->request->is(['patch', 'post', 'put'])) {            
            $id = $this->request->data['id'];            
            $ent['config_name'] = "Social Configuration";
            $ent['config_key'] = "social";
            $ent['config_value'] = json_encode($this->request->data['settings']);
            $ent['manager'] = "social";
            if ($id) {
                $ent['id'] = $id;
                $setting->id = $id;}           
            $setting = $this->Settings->patchEntity($setting, $ent);           
            if (!empty($this->request->data['settings']) && $this->Settings->save($setting)) {                
                $this->Flash->success(__('The social configuration setting has been saved.'));
                return $this->redirect(['action' => 'socials']);
            } else {
                $this->Flash->error(__('The setting could not be saved. Please, try again.'));
            }
        }
        if (empty($setting->toArray())) {
            $conditions = ['manager' => 'social'];
            $setting = $this->Settings->find()->where($conditions)->first();
            if (!empty($setting)) {
                $sq = json_decode($setting->config_value, true);
                $setting = $this->Settings->patchEntity($setting, ['settings' => $sq]);
            }
        }        
        $this->set(compact('setting'));
        $this->set('_serialize', ['setting']);
    }

    public function smtp() {
        $conditions = ['manager' => 'smtp'];
        $setting = $this->Settings->find()->where($conditions)->all();
        if ($this->request->is(['patch', 'post', 'put'])) {           
            $settings = $this->Settings->patchEntities($setting, $this->request->getData());            
            if ($this->Settings->saveMany($settings)) {
                $this->Flash->success(__('Smtp details has been saved.'));
                return $this->redirect(['action' => 'smtp']);
            } else {
                $this->Flash->error(__('Smtp details could not be saved. Please, try again.'));
            }
        }        
        $this->set(compact('setting'));
        $this->set('_serialize', ['setting']);
    }

    public function theme_options() {
        $conditions = ['manager' => 'theme'];
        $setting = $this->Settings->find()->where($conditions)->toArray();
        if ($this->request->is(['patch', 'post', 'put'])) {           
            $settings = $this->Settings->patchEntities($setting, $this->request->getData());            
            if ($this->Settings->saveMany($settings)) {
                $this->Flash->success(__('Theme options has been saved.'));
                return $this->redirect(['action' => 'theme_options']);
            } else {
                $this->Flash->error(__('Theme options could not be saved. Please, try again.'));
            }
        }  
        $this->set(compact('setting'));
        $this->set('_serialize', ['setting']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Setting id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null) {
        $this->request->allowMethod(['post', 'delete']);
        $setting = $this->Settings->get($id);
        if ($this->Settings->delete($setting)) {
            $this->Flash->success(__('The setting has been deleted.'));
        } else {
            $this->Flash->error(__('The setting could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }
    
    public function deleteimg($id = null) {
        $record = $this->Settings->get($id);
        if ($this->Settings->deleteImage($record->config_value, $record)) {
            $this->Flash->success(__('The banner has been deleted.'));
        } else {
            $this->Flash->error(__('The banner could not be deleted. Please, try again.'));
        }
        return $this->redirect($this->referer());
    }

}
