<?php

namespace App\Controller\Seller;

use App\Controller\AppController;
use Cake\Utility\Text;
use Cake\ORM\TableRegistry;
use Cake\Mailer\MailerAwareTrait;
use Cake\Core\Exception\Exception;
use Cake\Core\Configure;
use Cake\Log\Log;

//use Cake\Http\Client;
/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 */
class StripeController extends AppController {

    use MailerAwareTrait;

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Cookie');
        $this->loadComponent('Cookie');
    }

    public function index() {

        $this->autoRender = false;
        if ($this->request->query('code')) {
            $code = $this->request->query('code');
            $msg = '';
            $token_request_body = array(
                'client_secret' => Configure::read('Stripe.ApiKey'),
                'grant_type' => Configure::read('Stripe.grant_type'),
                'code' => $code
            );

            $req = curl_init(Configure::read('Stripe.token_url'));
            curl_setopt($req, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($req, CURLOPT_POST, true);
            curl_setopt($req, CURLOPT_POSTFIELDS, http_build_query($token_request_body));
            curl_setopt($req, CURLOPT_SSL_VERIFYPEER, FALSE);
            // TODO: Additional error handling
            $respCode = curl_getinfo($req, CURLINFO_HTTP_CODE);
            $curl_output = curl_exec($req);
            if ($errno = curl_errno($req)) {
                $error_message = curl_strerror($errno);
                echo "cURL error ({$errno}):\n {$error_message}";
            }
            $resp = json_decode($curl_output, true);
            curl_close($req);
            $selerId = $this->Auth->user('id');
            if (isset($selerId) && $selerId != '') {
                $this->loadModel('Users');
                $this->loadModel('RestaurantOrders');
                $this->loadModel('PaymentDetails');
//                $seller = $this->Users->find('all')
//                        ->where(['id' => $selerId])
//                        ->select('id')
//                        ->first();
                $sellerId = $seller->id;
                if (isset($resp['stripe_user_id']) && $resp['stripe_user_id'] != '') {
                    $count = $this->PaymentDetails->find()->where(['seller_id' => $sellerId])->count();
                    $paymentDetails = TableRegistry::get("PaymentDetails");
                    $query = $paymentDetails->query();
                    $type = 'stripe';
                    if ($count > 0) {
                        $result = $query->update()
                                ->set(['stripe_account_id' => $resp['stripe_user_id'], 'type' => $type])
                                ->where(['seller_id' => $seller->id])
                                ->execute();
                        $return = true;
                        $msg = 'Your stripe account is successfully updated.';
                    } else {
                        $result = $query->insert(['stripe_account_id', 'type', 'seller_id'])
                                ->values([
                                    'stripe_account_id' => $resp['stripe_user_id'],
                                    'type' => $type,
                                    'seller_id' => $seller->id
                                ])
                                ->execute();
                        $msg = 'Your stripe account successfully added.';
                        $return = true;
                    }
                } else {
                    $msg = $resp['error'] . ' ' . $resp['error_description'];
                    $return = false;
                }
            } else {
                return $this->redirect(['controller' => 'users', 'action' => 'login']);
                $return = false;
            }
        } else {
            $msg = 'Url Not Valid';
            $return = false;
        }
        if ($return) {
            $this->Flash->success(__($msg));
            return $this->redirect(['controller' => 'dashboard', 'action' => 'index']);
        } else {
            echo $msg;
            die;
        }
    }

}
