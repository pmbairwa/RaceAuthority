<?php

namespace App\Controller\Admin;

use App\Controller\AppController;

/**
 * Reviews Controller
 *
 * @property \App\Model\Table\ReviewsTable $Reviews
 *
 * @method \App\Model\Entity\Review[] paginate($object = null, array $settings = [])
 */
class ReviewsController extends AppController {

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index() {
        $options['finder'] = ['common' => ['searchKeyword' => $this->request->query]];
        $options['order'] = ['lft' => 'ASC'];
        $options['limit'] = $this->ConfigSettings['admin_page_limit'];
        $options['contain'] = ['Users'];
        $this->paginate = $options;
        $reviews = $this->paginate($this->Reviews);
        $this->set(compact('reviews'));
        $this->set('_serialize', ['reviews']);
    }

    /**
     * View method
     *
     * @param string|null $id Review id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null) {
        $review = $this->Reviews->get($id, [
            'contain' => ['Users']
        ]);

        $this->set('review', $review);
        $this->set('_serialize', ['review']);
    }

    public function approve($id = null) {
        $review = $this->Reviews->get($id);
        $review->status = 1;
        if ($this->Reviews->save($review)) {
            $this->Flash->success(__('The review has been approved.'));
        } else {
            $this->Flash->error(__('The review could not be approved. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function reject($id = null) {
        $review = $this->Reviews->get($id);
        $review->status = 2;
        if ($this->Reviews->save($review)) {
            $this->Flash->success(__('The review has been rejected.'));
        } else {
            $this->Flash->error(__('The review could not be rejected. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function review_vendor() {
        $options['finder'] = ['CommonVendor' => ['searchKeyword' => $this->request->query]];
        $options['order'] = ['lft' => 'ASC'];
        $options['where'] = ['user_id' => 0];
        $options['limit'] = $this->ConfigSettings['admin_page_limit'];
        $options['contain'] = ['Vendors'];
        $this->paginate = $options;
        $reviews = $this->paginate($this->Reviews);
        $this->set(compact('reviews'));
        $this->set('_serialize', ['reviews']);
    }

}
