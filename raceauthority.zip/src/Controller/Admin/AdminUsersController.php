<?php

namespace App\Controller\Admin;

use App\Controller\AppController;
use Cake\Utility\Text;
use Cake\ORM\TableRegistry;
use Cake\Validation\Validation;
use Cake\Core\Configure;
use Cake\Mailer\MailerAwareTrait;

/**
 * AdminUsers Controller
 *
 * @property \App\Model\Table\AdminUsersTable $AdminUsers
 */
class AdminUsersController extends AppController {

    use MailerAwareTrait;

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Cookie');

        $_dir = str_replace("\\", "/", $this->AdminUsers->_dir);
        $this->set(compact('_dir'));
    }

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index() {

        $query = $this->AdminUsers->find();
        $conditions = [];
        if (isset($this->request->query['keyword']) && !empty($this->request->query['keyword'])) {
            $conditions[] = ['OR' => [['CONCAT(AdminUsers.first_name," ", AdminUsers.last_name) LIKE' => '%' . trim($this->request->query['keyword']) . '%'], ['AdminUsers.first_name LIKE' => '%' . trim($this->request->query['keyword']) . '%'], ['AdminUsers.last_name LIKE' => '%' . trim($this->request->query['keyword']) . '%'], ['AdminUsers.email LIKE' => '%' . trim($this->request->query['keyword']) . '%'], ['AdminUsers.mobile LIKE' => '%' . trim($this->request->query['keyword']) . '%']]];
        }

        if (!empty($this->request->query)) {
            $this->request->data = $this->request->query;
        }

        $query->where($conditions);
        $options['order'] = ['AdminUsers.id' => 'ASC'];
        $options['limit'] = $this->ConfigSettings['admin_page_limit'];
        $this->paginate = $options;
        $records = $this->paginate($query);
        $this->set(array('records' => $records));
        $this->set('_serialize', ['records']);
    }

    /**
     * View method
     *
     * @param string|null $id Admin User id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null) {
        if (!$id)
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);

        $record = $this->{$this->modelClass}->get($id);

        $this->set(array('record' => $record, 'dateformat' => Configure::read('Setting.admin_date_time_format')));
        $this->set('_serialize', ['record']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add($id = null) {
        if ($id) {
            $record = $this->{$this->modelClass}->get($id, [
                'contain' => []
            ]);
        } else {
            $record = $this->{$this->modelClass}->newEntity();
        }
        if ($this->request->is(['patch', 'post', 'put'])) {
            $record = $this->{$this->modelClass}->patchEntity($record, $this->request->data);
            if ($this->request->data['password'] == "") {
                unset($record->password);
            }
            if ($this->{$this->modelClass}->save($record)) {
                $this->Flash->success(__('The admin user has been saved.'));
                return $this->redirect(['action' => 'add', $id]);
            } else {
                $this->Flash->error(__('The admin user could not be saved. Please, try again.'));
            }
        }

        $_dir = str_replace("\\", "/", $this->AdminUsers->_dir);
        $this->set(compact('record', '_dir'));
        $this->set('_serialize', ['record']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Admin User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null) {
        $this->request->allowMethod(['post', 'delete']);
        $record = $this->{$this->modelClass}->get($id);
        if ($this->{$this->modelClass}->delete($record) && $this->{$this->modelClass}->deleteImage($record->profile_photo)) {
            $this->Flash->success(__('The admin user has been deleted.'));
        } else {
            $this->Flash->error(__('The admin user could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }

    public function deleteimg($id = null) {
        $record = $this->{$this->modelClass}->get($id);
        if ($this->{$this->modelClass}->deleteImage($record->profile_photo, $record)) {
            $this->Flash->success(__('The profile photo has been deleted.'));
        } else {
            $this->Flash->error(__('The profile photo could not be deleted. Please, try again.'));
        }
        return $this->redirect($this->referer());
    }

    public function login() {
        $this->viewBuilder()->layout('login');
        if ($this->Auth->user('id')) {
            return $this->redirect($this->Auth->redirectUrl());
        }
        if ($this->request->is('post')) {
            $_user = $this->request->data['username'];
            if (Validation::email($this->request->data['username'])) {
                $this->Auth->config('authenticate', [
                    'Form' => [
                        'fields' => ['username' => 'email']
                    ]
                ]);
                $this->Auth->constructAuthenticate();
                $this->request->data['email'] = $this->request->data['username'];
                unset($this->request->data['username']);
            }
            $user = $this->Auth->identify();
            $this->request->data['username'] = $_user;
            if ($user) {
                $this->Auth->setUser($user);
                if ($this->request->data['adminremember_me'] == 1) {
                    unset($this->request->data['adminremember_me']);
                    $this->Cookie->write('adminremember_me', $this->request->data, true, "+1 week");
                }
                return $this->redirect($this->Auth->redirectUrl());
            }
            $this->Flash->error(__('Invalid Email Id or password, try again'));
        } else {
            $logincookie = $this->Cookie->read('adminremember_me');
            if (!empty($logincookie))
                $this->request->data = $logincookie;
        }
    }

    public function forgot() {
        $this->viewBuilder()->layout('login');
        $UserTokens = TableRegistry::get('UserTokens');
        $EmailTemplates = TableRegistry::get('EmailTemplates');
        $template = $EmailTemplates->find()->where(['email_type' => 'forgot_password'])->first();
        if ($this->request->is('post')) {
            $uData = $this->{$this->modelClass}->find("all", ['conditions' => ['email' => $this->request->data['email']]]);
            $result = $uData->first();
            if (!empty($result)) {
                $uid = Text::uuid();
                $EmailTemplates = TableRegistry::get('EmailTemplates');
                $template = $EmailTemplates->find()->where(['email_type' => 'forgot_password'])->first();
                $message = str_replace('##base_url', _BASE_, $template->description);
                $message = str_replace('##site_name', Configure::read('Setting.SITE_NAME'), $message);
                $message = str_replace('##site_logo', _BASE_ . 'img/uploads/settings/' . Configure::read('Setting.logo'), $message);
                $message = str_replace('##USER_NAME##', $result->name, $message);
                $message = str_replace('##USER_RESET_LINK##', _BASE_ . "admin/admin_users/reset/" . $uid, $message);
                $message = str_replace('##footer', "Copyright " . Configure::read('Setting.SITE_NAME') . " " . date("Y"), $message);
                $sentEmail['to'] = $result->email;
                $from = $this->SettingConfig['from_email'];
                $subject = str_replace('##firstname', $result->first_name, $template->subject);

                $_usertoken = $UserTokens->newEntity();
                $_usertoken->user_id = $result->id;
                $_usertoken->user_type = "admin_user";
                $_usertoken->token_type = "forgot";
                $_usertoken->token = $uid;
                if ($UserTokens->save($_usertoken)) {
                    $config['to'] = $result->email;
                    $config['subject'] = $subject;
                    $this->getMailer('Manu')->send('sendEmails', [$config, $message]);
                    $this->Flash->success(__('Your password reset link has been sent to your email!'));
                }
                return $this->redirect(['action' => 'login']);
            } else {
                $this->Flash->error(__('This email address does not exist in database.!'));
            }
        }
    }

    public function reset($token = null) {
        $this->viewBuilder()->layout('login');
        if (!$token) {
            return $this->redirect(['action' => 'login']);
        }
        $UserTokens = TableRegistry::get('UserTokens');
        $query = $UserTokens->find()->select(['id', 'user_id']);
        $query->where(['UserTokens.token' => $token, 'UserTokens.status' => 0, 'UserTokens.user_type' => 'admin_user', 'UserTokens.token_type' => 'forgot'])->order(['id' => 'DESC'])->limit(1);
        $res = $query->first();
        if (empty($res)) {
            $this->Flash->error(__('you token has expired.!'));
            return $this->redirect(['action' => 'forgot']);
        }
        if ($this->request->is('post')) {
            $len = strlen($this->request->data['password']);
            if ($this->request->data['password'] != $this->request->data['confirm_password']) {
                $this->Flash->error(__('password didn\'t match. please try again!'));
                return;
            } elseif ($len < 6) {
                $this->Flash->error(__('Your password must be at least 6 characters long.'));
                return;
            } elseif ($len > 15) {
                $this->Flash->error(__('Password is too long. The limit is 15 characters.'));
                return;
            } elseif (!(preg_match('/^(?=.*[a-zA-Z_@&+-])(?=.*\d)([0-9a-zA-Z_@&+-]+)$/', $this->request->data['password']) && preg_match('/[A-Z]/', $this->request->data['password']) && preg_match('/[a-z]/', $this->request->data['password']) && preg_match('/[!@#$%^&*()\-_=+{};:,<.>]/', $this->request->data['password']))) {
                $this->Flash->error(__('Password must contain at least one small, one capital alphabet, one numeric digit and one special character.'));
                return;
            }
            $adminUser = $this->{$this->modelClass}->get($res->user_id);
            $adminUser->password = $this->request->data['password'];
            if ($this->{$this->modelClass}->save($adminUser)) {
                $tokenq = $UserTokens->query();
                $tokenq->delete()
                        ->where(['id' => $res->id])
                        ->execute();
                $this->Flash->success(__('Your password has changed.'));
                return $this->redirect(['action' => 'login']);
            } else {
                $this->Flash->error(__('your process faild. please try again!'));
            }
        }
    }

    public function logout() {
        return $this->redirect($this->Auth->logout());
    }

}
