<?php

namespace App\Controller\Admin;

use App\Controller\AppController;

/**
 * CommissionSettings Controller
 *
 * @property \App\Model\Table\CommissionSettingsTable $CommissionSettings
 *
 * @method \App\Model\Entity\CommissionSetting[] paginate($object = null, array $settings = [])
 */
class CommissionSettingsController extends AppController {

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index() {
        $commissionSettings = $this->paginate($this->CommissionSettings);

        $this->set(compact('commissionSettings'));
        $this->set('_serialize', ['commissionSettings']);
    }

    /**
     * View method
     *
     * @param string|null $id Commission Setting id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null) {
        $commissionSetting = $this->CommissionSettings->get($id, [
            'contain' => []
        ]);

        $this->set('commissionSetting', $commissionSetting);
        $this->set('_serialize', ['commissionSetting']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add($id = null) {
        if ($id) {
            $commissionSetting = $this->CommissionSettings->get($id, [
                'contain' => []
            ]);
        } else {
            $commissionSetting = $this->CommissionSettings->newEntity();
        }
        if ($this->request->is(['post', 'put'])) {
            $commissionSetting = $this->CommissionSettings->patchEntity($commissionSetting, $this->request->getData());
            if ($this->CommissionSettings->save($commissionSetting)) {
                $this->Flash->success(__('The commission setting has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The commission setting could not be saved. Please, try again.'));
        }
        $commssion_for = array(1 => 'admin', 2 => 'vendor');
        $commission_mode = array(1 => 'Fixed', 2 => 'Percent');
        $this->set(compact('commissionSetting','commssion_for','commission_mode'));
        $this->set('_serialize', ['commissionSetting']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Commission Setting id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null) {
        $commissionSetting = $this->CommissionSettings->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $commissionSetting = $this->CommissionSettings->patchEntity($commissionSetting, $this->request->getData());
            if ($this->CommissionSettings->save($commissionSetting)) {
                $this->Flash->success(__('The commission setting has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The commission setting could not be saved. Please, try again.'));
        }
        $this->set(compact('commissionSetting'));
        $this->set('_serialize', ['commissionSetting']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Commission Setting id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null) {
        $this->request->allowMethod(['post', 'delete']);
        $commissionSetting = $this->CommissionSettings->get($id);
        if ($this->CommissionSettings->delete($commissionSetting)) {
            $this->Flash->success(__('The commission setting has been deleted.'));
        } else {
            $this->Flash->error(__('The commission setting could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

}
