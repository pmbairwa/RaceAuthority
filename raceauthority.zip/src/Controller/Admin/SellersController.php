<?php

namespace App\Controller\Admin;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;

/**
 * Sellers Controller
 *
 * @property \App\Model\Table\SellersTable $Sellers
 *
 * @method \App\Model\Entity\Salon[] paginate($object = null, array $settings = [])
 */
class SellersController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Default');
        $_dir = str_replace("\\", "/", $this->Sellers->_dir);
        $this->set(compact('_dir'));
    }

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index() {

        $options['finder'] = ['common' => ['searchKeyword' => $this->request->query]];
        $options['order'] = ['Sellers.id' => 'DESC'];
        $options['limit'] = $this->ConfigSettings['admin_page_limit'];
        $options['contain'] = ['Users'];
        $this->paginate = $options;

        $sellers = $this->paginate($this->Sellers);
        $dateformat = Configure::read('Setting.admin_date_time_format');
        $this->set(compact('sellers', 'dateformat'));
        $this->set('_serialize', ['sellers']);
    }    

    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add($id = null) {
        if ($id) {
            $salon = $this->Sellers->get($id, [
                'contain' => ['SalonWorkDays']
            ]);
        } else {
            $salon = $this->Sellers->newEntity();
        }
        if ($this->request->is(['post', 'put'])) {
            //to show data if error exists         
            foreach ($this->request->data['salon_work_days'] as $order_key => $order) {
                $order_num = 1;
                foreach ($order as $key => $value) {
                    if (($value['is_off'] != 0 && empty($value['opening_time']) && empty($value['closed_time']))) {
                        unset($this->request->data['salon_work_days'][$order_key][$key]);
                    } else {
                        $this->request->data['salon_work_days'][$order_key][$key]['order_by'] = $order_num;
                        $order_num++;
                    }
                }

                if (empty($this->request->data['salon_work_days'][$order_key]))
                    unset($this->request->data['salon_work_days'][$order_key]);
            }
            $data_array = $this->request->data['salon_work_days'];

            unset($this->request->data['salon_work_days']);
            //to save data in database
            $i = 0;
            foreach ($data_array as $SalonWorkDay) {
                $order_num = 1;
                foreach ($SalonWorkDay as $order) {
                    $this->request->data['salon_work_days'][$i]['week_day'] = $order['week_day'];
                    $this->request->data['salon_work_days'][$i]['opening_time'] = $order['opening_time'];
                    $this->request->data['salon_work_days'][$i]['closed_time'] = $order['closed_time'];
                    $this->request->data['salon_work_days'][$i]['order_by'] = $order_num;

                    $i++;
                    $order_num++;
                }
            }            

            $salon = $this->Sellers->patchEntity($salon, $this->request->getData());
            if (!$salon->isNew()) {
                $this->Sellers->SalonWorkDays->deleteAll(['salon_id' => $salon->id]);
            }

            if ($this->Sellers->save($salon)) {
                $this->Flash->success(__('The salon has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->request->data['salon_work_days'] = $data_array;
            $this->Flash->error(__('The salon could not be saved. Please, try again.'));
        }

        $Users = TableRegistry::get('Users');
        $users = $Users->find('list')->where(['Users.account_type_id' => 2]);        
        
        $this->set(compact('salon', 'users'));
        $this->set('_serialize', ['salon']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Salon id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null) {
        $this->request->allowMethod(['post', 'delete']);
        $salon = $this->Sellers->get($id);
        if ($this->Sellers->delete($salon)) {
            $this->Flash->success(__('The salon has been deleted.'));
        } else {
            $this->Flash->error(__('The salon could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function deleteimg($id = null) {
        $record = $this->Sellers->get($id);
        if ($this->Sellers->deleteImage($record->image, $record)) {
            $this->Flash->success(__('The salon image has been deleted.'));
        } else {
            $this->Flash->error(__('The salon image could not be deleted. Please, try again.'));
        }
        return $this->redirect($this->referer());
    }

    public function deletebannerimg($id = null) {
        $record = $this->Sellers->get($id);
        if ($this->Sellers->deleteImage($record->banner, $record)) {
            $this->Flash->success(__('The salon banner image has been deleted.'));
        } else {
            $this->Flash->error(__('The salon banner image could not be deleted. Please, try again.'));
        }
        return $this->redirect($this->referer());
    }

    public function get_postcode($postcode = null) {
        $this->viewBuilder()->layout('ajax');
        $this->autoRender = false;
        echo $this->Default->getPostcode($postcode);
    }
}
