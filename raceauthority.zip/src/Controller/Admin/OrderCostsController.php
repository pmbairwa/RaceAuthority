<?php

namespace App\Controller\Admin;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\ORM\TableRegistry;
use Cake\Mailer\MailerAwareTrait;

/**
 * OrderCosts Controller
 *
 * @property \App\Model\Table\OrderCostsTable $OrderCosts
 *
 * @method \App\Model\Entity\OrderCost[] paginate($object = null, array $settings = [])
 */
class OrderCostsController extends AppController {
    use MailerAwareTrait;
    
    
    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function index() {
        $this->loadModel('Settings');
        $orderCost = $this->OrderCosts->find()->toArray();
        $settings = $this->Settings->find()->where(['Settings.manager'=>'order']);
        foreach ($settings as $key=>$value)
        {
            $global_cost[$value->config_key] = $value;
        }    
        $salons = $this->OrderCosts->Salons->find('list')->where(['status' => 1]);
        $this->set(compact('orderCost', 'global_cost', 'salons'));
        $this->set('_serialize', ['orderCost']);
    }
    
    public function manage($id = NULL) {
        $orderCost = $this->OrderCosts->find()->where(['salon_id' => $id])->first();
        $this->set(compact('orderCost','id'));
        $this->set('_serialize', ['orderCost']);
    }
    
   /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add($id=null)
    {   
        if(isset($this->request->data['id']) && !empty($this->request->data['id'])){
             $orderCosts = $this->OrderCosts->get($this->request->data['id'], [
            'contain' => []
        ]);
        }else{
            $orderCosts = $this->OrderCosts->newEntity();
        }
        $message = 'Invalid request.';
        $status = FALSE;
        $ocid = false;
        if ($this->request->is('Ajax') && !empty($this->request->data)) {
            $paymentTypes = $this->request->getData('payment_type');
            $paymentDetails = "";
            if($this->request->getData('payment_option_type')==1){
                $this->request->data['monthly_subscription_fee'] = "";
                $this->request->data['one_time_joining_amount'] = "";
                $paymentDetails = '<p>Payment Option: Wallet Option</p>
                                  <p>Wallet Amount: '.$this->request->data['wallet_amount'].'</p>
                                  <p>Per Order Amount: '.$this->request->data['order_per_amount'].'</p>';
            }else if($this->request->getData('payment_option_type')==2){
                $this->request->data['one_time_joining_amount'] = "";
                $paymentDetails = '<p>Payment Option: Monthly Subscription Fee & Percentage/order</p>
                                   <p>Monthly Subscription Fee: '.$this->request->data['monthly_subscription_fee'].'</p>		
                                   <p>Per Order Amount: '.$this->request->data['order_per_amount'].'</p>';
            }else if($this->request->getData('payment_option_type')==3){
                $this->request->data['one_time_joining_amount'] = "";
                $this->request->data['monthly_subscription_fee'] = "";
                $paymentDetails = '<p>Payment Option: Percentage per Order</p>
                                   <p>% Per Order Amount: '.$this->request->data['order_per_amount'].'</p>';
            }else if($this->request->getData('payment_option_type')==4){
                $this->request->data['monthly_subscription_fee'] = "";
                $paymentDetails = '<p>Payment Option: One Time Joining Fee</p>
                                   <p>One Time Fee: '.$this->request->data['one_time_joining_amount'].'</p>		
                                   <p>Per Order Amount: '.$this->request->data['order_per_amount'].'</p>';
            }
            $orderCosts = $this->OrderCosts->patchEntity($orderCosts, $this->request->getData());
            if ($this->OrderCosts->save($orderCosts)) {
                $ocid = isset($this->request->data['id']) && !empty($this->request->data['id'])?$this->request->data['id']:$orderCosts->id;
                if(empty($this->request->data['id'])){
                    if($paymentTypes == 'f'){
                        $paymentType = 'Fixed';
                    }else{
                        $paymentType = 'Percentage';
                    }
                        $EmailTemplates = TableRegistry::get('EmailTemplates');
                        $template = $EmailTemplates->find()->where(['email_type' => 'payment_invoice'])->first();
                        $message = str_replace('##base_url##', _BASE_, $template->description);
                        $message = str_replace('##site_name', Configure::read('Setting.SITE_NAME'), $message);
                        $logo = Configure::read('Setting.logo');

                        $message = str_replace('##site_logo', _BASE_ . 'img/uploads/settings/'.$logo, $message);


                        $message = str_replace('##footer', "Copyright " . Configure::read('Setting.SITE_NAME') . " " . date("Y"), $message);
                        $salon = TableRegistry::get('Salons');
                        $restaurntOwnerEmail = $salon->find()->contain(['Users'])->where(['Salons.id' => $this->request->getData('salon_id')])->first();
                        $message = str_replace('##first_name##', $restaurntOwnerEmail['user']['first_name'], $message);
                        $message = str_replace('##payment_details##', $paymentDetails, $message);
                        $message = str_replace('##payment_type##', $paymentType, $message);
                        $message = str_replace('##site_url', _BASE_.'admin', $message);

                        $sentEmail['to'] = $restaurntOwnerEmail['user']['email'];
                        $from = Configure::read('Setting.from_email');
                        $subject = str_replace('##firstname', $restaurntOwnerEmail['user']['first_name'], $template->subject);
                        $subject = str_replace('##first_name', Configure::read('Setting.SITE_NAME'), $subject);
                        $subject = str_replace('##site_name', Configure::read('Setting.SITE_NAME'), $subject);
                        $config['to'] = $restaurntOwnerEmail['user']['email'];
                        $config['subject'] = $subject;                     
                        $this->getMailer('Manu')->send('sendEmails', [$config, $message]);
               }
                $message = 'The order cost has been saved.';
                $status = TRUE;
                
            }else{
                        $_error = $orderCosts->errors();                        
                        if (!empty($_error)) {
                            $message = "A validation error occurred";
                        }
                        $eacherr = '';
                        $inc = " - ";
                        foreach ($_error as $k => $er) {
                            if (is_array($er)) {
                                foreach ($er as $ke => $iner) {
                                    $eacherr .= $inc . $iner . "<br/>";
                                    $inc++;
                                }
                            } else {
                                $eacherr .= $inc . $er . "<br/>";
                            }
                        }
                if(!empty($eacherr)){        
                    $message .=  "<br>".$eacherr;       
                }
                $status = FALSE;
            }
            
        }
        die(json_encode(['status'=>$status,'message'=>$message,'ocid'=>$ocid]));       
    }    
    
    
    public function get_orders_data($getType = null){
        $this->viewBuilder()->layout('ajax');
        
        if($getType == 1){
            $orderCost = $this->OrderCosts->find()->where(['payment_option_type' => 1])->toArray();
        }else if($getType == 2){
            $orderCost = $this->OrderCosts->find()->where(['payment_option_type' => 2])->toArray();
        }else{
            $orderCost = $this->OrderCosts->find()->where(['payment_option_type' => 0])->toArray();
        }
        $salons = $this->OrderCosts->Salons->find('list')->where(['status' => 1]);
        $this->set(compact('orderCost', 'salons', 'getType'));
    }
    
    public function save_global_cost() {
        $this->viewBuilder()->layout('ajax');
        $this->autoRender = FALSE;
        
        $this->loadModel('Settings');
        $setting = $this->Settings->find()->where(['Settings.manager'=>'order']);
        $setting = $this->Settings->patchEntities($setting, $this->request->data['data']);
        if ($this->Settings->saveMany($setting)) {
            $response['status'] = 1;
        } else {
            $response['status'] = 0;
        }
        echo json_encode($response);
    }
    
    public function save_payment_recharge() {
        $this->viewBuilder()->layout('ajax');
        $this->autoRender = FALSE;
        
        $id = $this->request->data['salon_id'];
        $orderCost = $this->OrderCosts->find()->where(['salon_id' => $id])->first();       
        
        if (!empty($orderCost)) {
            $ordercost = $this->OrderCosts->get($orderCost->id);
            if($this->request->data['payment_option_type'] == 1){
               $this->request->data['wallet_amount'] = $orderCost['wallet_amount'] +  $this->request->data['wallet_amount'];
            }  
        }else{
            $ordercost = $this->OrderCosts->newEntity();
        }
        $orderCost = $this->OrderCosts->patchEntity($ordercost, $this->request->data);    
        if ($this->OrderCosts->save($orderCost)) {
            $ocid = $orderCost->id;
            $response['status'] = 1;
            $response['wallet_amt'] = $this->request->data['wallet_amount'];
            $response['ocid'] = $ocid;
        } else {
            $response['status'] = 0;
        }
        echo json_encode($response);
    }   

    public function remove_cost($id) {
        $this->viewBuilder()->layout('ajax');
        $this->autoRender = FALSE;
        $this->loadModel('OrderCosts');
        $order_cost = $this->OrderCosts->get($id);
        if ($this->OrderCosts->delete($order_cost)) {
            $response['status'] = 1;
        } else {
            $response['status'] = 0;
        }

        echo json_encode($response);
    }

}
