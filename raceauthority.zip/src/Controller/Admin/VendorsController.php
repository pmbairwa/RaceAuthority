<?php

namespace App\Controller\Admin;

use App\Controller\AppController;

/**
 * Vendors Controller
 *
 * @property \App\Model\Table\VendorsTable $Vendors
 *
 * @method \App\Model\Entity\Vendor[] paginate($object = null, array $settings = [])
 */
class VendorsController extends AppController {

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function initialize() {
        parent::initialize();

        $this->Auth->allow(['login']);
        $this->loadComponent('Cookie');
        $this->loadComponent('Default');
    }

    public function index() {
        $this->paginate = [
            'contain' => ['Countries']
        ];
        $vendors = $this->paginate($this->Vendors);

        $this->set(compact('vendors'));
        $this->set('_serialize', ['vendors']);
    }

    /**
     * View method
     *
     * @param string|null $id Vendor id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null) {
        $vendor = $this->Vendors->get($id, [
            'contain' => ['Countries']
        ]);

        $this->set('vendor', $vendor);
        $this->set('_serialize', ['vendor']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add() {
        $err = '';
        $vendor = $this->Vendors->newEntity();
        if ($this->request->is(['post', 'put'])) {
            $allowed_ext_img = array('jpg', 'jpeg', 'png');
            $file_ext_img = pathinfo($this->request->data['image']['name'], PATHINFO_EXTENSION);
            if (isset($this->request->data['image']) && $this->request->data['image'] != '') {
                if (isset($this->request->data['image']['name']) && $this->request->data['image']['name'] != '') {
                    if (in_array($file_ext_img, $allowed_ext_img)) {
                        $imagename = $this->Default->createImageName($this->request->data['image']['name'], BASE_PATH_VENDOR_IMAGE, current(explode(".", $this->request->data['image']['name'])));
                        if (move_uploaded_file($this->request->data['image']['tmp_name'], BASE_PATH_VENDOR_IMAGE . $imagename)) {
                            $this->request->data['image'] = $imagename;
                        }
                    } else {
                        $err .= ' Please upload valid image';
                    }
                }
            }
            if ($err = '') {
                $vendor = $this->Vendors->patchEntity($vendor, $this->request->getData());
                if ($this->Vendors->save($vendor)) {
                    $this->Flash->success(__('The vendor has been saved.'));

                    return $this->redirect(['action' => 'index']);
                }
                $this->Flash->error(__($this->Default->get_errors($vendor->errors())));
                // $this->Flash->error(__('The vendor could not be saved. Please, try again.'));
            } else {
                $this->Flash->error(__($err));
            }
        }
        $countries = $this->Vendors->Countries->find('list', ['limit' => 200]);
        $this->set(compact('vendor', 'countries'));
        $this->set('_serialize', ['vendor']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Vendor id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null) {
        $err = '';
        $vendor = $this->Vendors->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $allowed_ext_img = array('jpg', 'jpeg', 'png');
            $file_ext_img = pathinfo($this->request->data['image']['name'], PATHINFO_EXTENSION);
            if (isset($this->request->data['image']) && $this->request->data['image'] != '') {
                if (isset($this->request->data['image']['name']) && $this->request->data['image']['name'] != '') {
                    if (in_array($file_ext_img, $allowed_ext_img)) {
                        $imagename = $this->Default->createImageName($this->request->data['image']['name'], BASE_PATH_VENDOR_IMAGE, current(explode(".", $this->request->data['image']['name'])));
                        if (move_uploaded_file($this->request->data['image']['tmp_name'], BASE_PATH_VENDOR_IMAGE . $imagename)) {
                            if ($this->request->data['old_image'] != $imagename) {
                                @unlink(BASE_PATH_VENDOR_IMAGE . $this->request->data['old_image']);
                            }
                        }
                        $this->request->data['image'] = $imagename;
                    } else {
                        $err .= ' Please upload valid image';
                    }
                } else {
                    $this->request->data['image'] = $this->request->data['old_image'];
                }
            }
            if ($err == '') {
                $vendor = $this->Vendors->patchEntity($vendor, $this->request->getData());
                if ($this->Vendors->save($vendor)) {
                    $this->Flash->success(__('The vendor has been saved.'));

                    return $this->redirect(['action' => 'index']);
                }
                $this->Flash->error(__($this->Default->get_errors($vendor->errors())));
            } else {
                $this->Flash->error(__($err));
            }
        }
        $countries = $this->Vendors->Countries->find('list', ['limit' => 200]);
        $this->set(compact('vendor', 'countries'));
        $this->set('_serialize', ['vendor']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Vendor id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null) {
        $this->request->allowMethod(['post', 'delete']);
        $vendor = $this->Vendors->get($id);
        if ($this->Vendors->delete($vendor)) {
            $this->Flash->success(__('The vendor has been deleted.'));
        } else {
            $this->Flash->error(__('The vendor could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

}
