<?php

namespace App\Controller\Admin;

use App\Controller\AppController;

/**
 * Products Controller
 *
 * @property \App\Model\Table\ProductsTable $Products
 *
 * @method \App\Model\Entity\Product[] paginate($object = null, array $settings = [])
 */
class ProductsController extends AppController {

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function initialize() {
        parent::initialize();

        $this->Auth->allow(['login']);
        $this->loadComponent('Cookie');
        $this->loadComponent('Default');
    }

    public function index() {
        $this->paginate = [
            'contain' => ['Categories', 'Vendors']
        ];
        $products = $this->paginate($this->Products);
        $this->set(compact('products'));
        $this->set('_serialize', ['products']);
    }

    /**
     * View method
     *
     * @param string|null $id Product id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null) {
        $product = $this->Products->get($id, [
            'contain' => ['Categories', 'Vendors', 'ProductTags', 'ProductImages', 'Reviews']
        ]);

        $this->set('product', $product);
        $this->set('_serialize', ['product']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add() {
        $err = '';
        $product = $this->Products->newEntity(null, ['associated' => ['ProductImages']]);
     //   $product = $this->Products->newEntity();
        if ($this->request->is(['post', 'put'])) {
            $product = $this->Products->patchEntity($product, $this->request->data, ['associated' => ['ProductImages']]);
            if ($this->Products->save($product)) {
                $this->Flash->success(__('The product has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            pr($product->errors());
            exit;
            $this->Flash->error(__($this->Default->get_errors($product->errors())));
        }
        $categories = $this->Products->Categories->find('list', ['limit' => 200]);
        $vendors = $this->Products->Vendors->find('list', [
            'keyField' => 'id',
            'valueField' => 'first_name',
                ], ['limit' => 200]);
        $this->set(compact('product', 'categories', 'vendors'));
        $this->set('_serialize', ['product']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Product id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null) {
        $product = $this->Products->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $product = $this->Products->patchEntity($product, $this->request->getData());
            if ($this->Products->save($product)) {
                $this->Flash->success(__('The product has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__($this->Default->get_errors($vendor->errors())));
        }
        $categories = $this->Products->Categories->find('list', ['limit' => 200]);
        $vendors = $this->Products->Vendors->find('list', [
            'keyField' => 'id',
            'valueField' => 'first_name',
                ], ['limit' => 200]);
        $this->set(compact('product', 'categories', 'vendors'));
        $this->set('_serialize', ['product']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Product id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null) {
        $this->request->allowMethod(['post', 'delete']);
        $product = $this->Products->get($id);
        if ($this->Products->delete($product)) {
            $this->Flash->success(__('The product has been deleted.'));
        } else {
            $this->Flash->error(__('The product could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

}
