<?php

namespace App\Controller\Seller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\ORM\TableRegistry;

/**
 * Orders Controller
 *
 * @property \App\Model\Table\OrdersTable $Orders
 *
 * @method \App\Model\Entity\Order[] paginate($object = null, array $settings = [])
 */
class OrdersController extends AppController {

    public function initialize() {
        parent::initialize();
        if ($this->Auth->user()) {
            $this->seller = $seller = $this->Auth->user('id');
            $this->seller_id = $this->seller;
        }
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index() {
        return $this->redirect(['action' => 'pendingOrders']);
    }

    /**
     * Change status method
     *
     * @param string|null $id Order id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function changeStatus($id = null, $user_id = null) {

        $this->viewBuilder()->layout('ajax');
        $data = array();
        $data['status'] = $this->request->data['status'];
        if ($this->request->data['status'] == 1) {
            $data['accepted_status'] = 1;
            $data['accept_status_time'] = date('Y-m-d H:i:s');
        }
        if (!empty($id)) {
            $order = $this->Orders->get($id);

            $order = $this->Orders->patchEntity($order, $data);
            if ($order_status_update = $this->Orders->save($order)) {
                $this->sendPushNotifications($data, $user_id, $id, $order_status_update);   //send push notifcation function call
                $response['status'] = 1;
                $response['id'] = $order->id;
            } else {
                $response['status'] = 0;
            }
        } else {
            $response['status'] = 0;
        }
        echo json_encode($response);
        exit;
    }

    /**
     * send push notifications
     *
     * @param string|null $user_id user id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    function sendPushNotifications($data, $user_id, $id, $order_status_update) {
        $this->loadModel('DeviceTokens');
        $devices = $this->DeviceTokens->find()->where(['DeviceTokens.user_id' => $user_id]);

        if (!empty($devices)) {
            $msg = '';
            $status_msg = '';
            if ($data['status'] == 0) {
                $status_msg = "Dear customer, your order #" . $id . " is pending.";
            } else if ($data['status'] == 1) {
                $secs = strtotime($this->min_order_time) - strtotime("00:00");

                $ready_time = date("H:i", strtotime($order_status_update->accept_status_time) + $secs);

                $status_msg = "Dear customer, your order #" . $id . " has been accepted. Your order will be ready at " . $ready_time;
            } else if ($data['status'] == 2) {
                $status_msg = "Dear customer, your order #" . $id . " has been rejected.Sorry for the inconvenience";
            } else if ($data['status'] == 3) {
                $status_msg = "Dear customer, your order #" . $id . " is ready for pickup";
            } else if ($data['status'] == 4) {
                $status_msg = "Dear customer, your order #" . $id . " is out for Delivery";
            } else if ($data['status'] == 5) {
                $status_msg = "Dear customer, your order #" . $id . " has been delayed, Sorry for the inconvenience";
            } else {
                $status_msg = "Dear customer, your order #" . $id . " has been delivered. Enjoy the meal.";
            }
            $order_id = $id;

            foreach ($devices as $key => $val) {
                if ($val['device_type'] == 'ios') {

                    $this->Default->pushnotificationIphone($val['device_token'], $status_msg, $order_id);
                } else {
                    $this->Default->androidPushNotification($val['device_token'], $status_msg, $order_id);
                }
            }
        }
    }

    /**
     * View method
     *
     * @param string|null $id Order id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null) {


        $order = $this->Orders->get($id, [
            'contain' => ['Restaurants', 'Users', 'RestaurantOrders']
        ]);
        $this->loadModel('MenuOrders');
        $this->loadModel('ExtraOrders');
        $this->loadModel('AttributeOrders');
        $tags = array();
        $menus = $this->MenuOrders->find()->where(['order_id' => $id, 'MenuOrders.meal_id' => 0])->order(['MenuOrders.tag ASC'])->all();
        $menus_data = $this->Default->getMenus($menus);

        $meals = $this->MenuOrders->find()->where(['MenuOrders.order_id' => $id, 'MenuOrders.meal_id !=' => 0])->order(['MenuOrders.tag ASC'])->all();
        $meals_data = $this->Default->getMeals($meals, $id);

        $this->set(compact('order', 'tags', 'menus_data', 'meals_data'));
        $this->set('_serialize', ['order']);
    }

    /**
     * get menus
     *
     * @param string|null array $menus
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\blank array When record not found.
     */
    /* function getMenus($menus) {
      $menus_data = array();
      if (!empty($menus)) {

      $menus = $menus->toArray();
      foreach ($menus as $k => $d) {
      $menus_data[$k]['menu_id'] = $d['menu_id'];
      $menus_data[$k]['menu_name'] = $d['menu_name'];
      $menus_data[$k]['tag'] = $d['tag'];
      $menus_data[$k]['price'] = $d['menu_price'];
      $extras = $this->ExtraOrders->find()->where(['menu_order_id' => $d['id']])->all();

      if (!empty($extras)) {
      $extras = $extras->toArray();

      foreach ($extras as $k1 => $d1) {
      $menus_data[$k]['extras'][$k1]['extra_id'] = $d1['extra_id'];
      $menus_data[$k]['extras'][$k1]['extra_name'] = $d1['extra_name'];
      $menus_data[$k]['extras'][$k1]['price'] = $d1['price'];
      }
      }
      $attributes = $this->AttributeOrders->find()->where(['menu_order_id' => $d['id']])->all();
      if (!empty($attributes)) {
      $attributes = $attributes->toArray();
      foreach ($attributes as $k2 => $d2) {
      $menus_data[$k]['attributes'][$k2]['attribute_id'] = $d2['attribute_id'];
      $menus_data[$k]['attributes'][$k2]['attribute_name'] = $d2['attribute_name'];
      $menus_data[$k]['attributes'][$k2]['price'] = $d2['price'];
      }
      }
      $this->loadModel('OptionOrders');
      $option = $this->OptionOrders->find()->where(['menu_order_id' => $d['id']])->all();
      if (!empty($option)) {
      $options = $option->toArray();

      foreach ($options as $k2 => $d2) {
      $menus_data[$k]['options'][$k2]['option_id'] = $d2['option_id'];
      $menus_data[$k]['options'][$k2]['option_name'] = $d2['option_name'];
      }
      }
      }
      }

      return $menus_data;
      } */

    /**
     * get meals
     *
     * @param string|null array $meals ,order id $id
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\blank array When record not found.
     */
    /*    function getMeals($meals, $id) {
      $meals_data = array();
      if (!empty($meals)) {
      foreach ($meals as $key => $data) {

      $meals_data[$key]['meal_id'] = $data['meal_id'];
      $meals_data[$key]['meal_name'] = $data['meal_name'];
      $meals_data[$key]['tag'] = $data['tag'];
      $meals_data[$key]['price'] = $data['meal_price'];
      //$menus = $this->MenuOrders->find()->where(['meal_id' => $data['meal_id'], 'id' => $data['id'], 'order_id' => $id])->all();
      $menus = $this->MenuOrders->find()->where(['meal_id' => $data['meal_id'], 'meal_type' => $data['meal_type'], 'order_id' => $id])->all();
      foreach ($menus as $k => $d) {
      $meals_data[$key]['menus'][$k]['menu_id'] = $d['menu_id'];
      $meals_data[$key]['menus'][$k]['menu_name'] = $d['menu_name'];
      $extras = $this->ExtraOrders->find()->where(['menu_order_id' => $d['id']])->all();
      if (!empty($extras)) {
      foreach ($extras as $k1 => $d1) {
      $meals_data[$key]['menus'][$k]['extras'][$k1]['extra_id'] = $d1['extra_id'];
      $meals_data[$key]['menus'][$k]['extras'][$k1]['extra_name'] = $d1['extra_name'];
      $meals_data[$key]['menus'][$k]['extras'][$k1]['price'] = $d1['price'];
      }
      }
      $attributes = $this->AttributeOrders->find()->where(['menu_order_id' => $d['id']])->all();
      if (!empty($attributes)) {
      foreach ($attributes as $k2 => $d2) {
      $meals_data[$key]['menus'][$k]['attributes'][$k2]['attribute_id'] = $d2['attribute_id'];
      $meals_data[$key]['menus'][$k]['attributes'][$k2]['attribute_name'] = $d2['attribute_name'];
      $meals_data[$key]['menus'][$k]['attributes'][$k2]['price'] = $d2['price'];
      }
      }
      }
      }
      }
      return $meals_data;
      } */

    /**
     * Invoice print method
     *
     * @param string|null $id Order id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function invoice_print($id = null) {
        $this->viewBuilder()->setLayout('print');
        $order = $this->Orders->get($id, [
            'contain' => ['Restaurants', 'Users', 'RestaurantOrders']
        ]);
        $this->loadModel('MenuOrders');
        $this->loadModel('ExtraOrders');
        $this->loadModel('AttributeOrders');
        $tags = array();
        $menus = $this->MenuOrders->find()->where(['order_id' => $id, 'MenuOrders.meal_id' => 0])->order(['MenuOrders.tag ASC'])->all();
        $menus_data = $this->Default->getMenus($menus);
        $meals = $this->MenuOrders->find()->where(['MenuOrders.order_id' => $id, 'MenuOrders.meal_id !=' => 0])->order(['MenuOrders.tag ASC'])->all();
        $meals_data = $this->Default->getMeals($meals, $id);
        $this->set(compact('order', 'tags', 'menus_data', 'meals_data'));
        $this->set('_serialize', ['order']);
    }

    /**
     * Export method
     *
     * @param string|null request query.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function export($status) {
        $ConfigSettings = Configure::read('Setting');
        $options['finder'] = ['common' => ['searchKeyword' => $this->request->query]];

        if ($status == 'pendingOrders') {
            $options['conditions'] = ['Orders.restaurant_id' => $this->restaurant_id, 'Orders.status' => 0];
        } elseif ($status == 'acceptedOrders') {
            $options['conditions'] = ['OR' => [['Orders.status' => '1'], ['Orders.status' => '3'], ['Orders.status' => '4'], ['Orders.status' => '5']], 'Orders.restaurant_id' => $this->restaurant_id];
        } else {
            $options['conditions'] = ['OR' => [['Orders.status' => '2'], ['Orders.status' => '6']], 'Orders.restaurant_id' => $this->restaurant_id];
        }

        $options['limit'] = $this->ConfigSettings['admin_page_limit'];
        $options['contain'] = ['Restaurants', 'Users'];
        $this->paginate = $options;
        $orders = $this->paginate($this->Orders);
        $orders = $orders->toArray();
        $data = array();
        if (!empty($orders)) {
            $i = 1;
            foreach ($orders as $key => $val) {
                $data[$key]['Sr.No.'] = $i;
                $data[$key]['order_id'] = $val['id'];
                $data[$key]['customer'] = $val['user']['first_name'] . '' . $val['user']['last_name'];
                $data[$key]['order_type'] = ucwords($val->order_type);
                $data[$key]['ready_time'] = date('h:i a', strtotime($val->ready_time)) . ' ' . $val->created->format($ConfigSettings['admin_date_format']);
                $data[$key]['total_payment'] = $val->total_payment;

                $data[$key]['created'] = $val->created->format($ConfigSettings['admin_date_format']);

                $i++;
            }
        }
        $this->response->download('orders.csv');

        $_serialize = 'data';
        $_header = ['Sr.No.', 'Order ID', 'Customer Name', 'Order Type', 'Ready Time', 'Toatl Payment', 'Order Date'];
        $this->set(compact('data', '_serialize', '_header'));
        $this->viewBuilder()->className('CsvView.Csv');
        return;
    }

    /**
     * Pending Orders method
     *
     * @param string|null request query.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
//    public function pendingOrders() {
//        $options['finder'] = ['common' => ['searchKeyword' => $this->request->query]];
//        $options['conditions'] = ['Orders.restaurant_id' => $this->restaurant_id, 'Orders.status' => 0, 'Orders.on_table =' => 0];
//        $options['limit'] = $this->ConfigSettings['admin_page_limit'];
//        $options['contain'] = ['Restaurants', 'Users'];
//
//        $this->paginate = $options;
//        $orders = $this->paginate($this->Orders);
//        $data = !empty($this->request->query) ? $this->request->query : array();
//        $this->set(compact('orders', 'data'));
//        $this->set('_serialize', ['orders']);
//    }
    public function pendingOrders() {
        $this->loadModel('Orders');
        $this->loadModel('Reviews');
        $pending_orders = $this->Orders->find()->where(['user_id' => $this->seller_id, 'order_status' => 0])->count();
        pr($pending_orders);
        exit;
        $this->set(compact('pending_orders'));

        $options['order'] = ['Orders.created DESC'];
        $options['conditions'] = ['Orders.user_id' => $this->seller_id, 'Orders.order_status' => 0];
        $options['limit'] = 10;
        $options['contain'] = ['Users'];
        $this->paginate = $options;
        $orders = $this->paginate($this->Orders);
        $data = !empty($this->request->query) ? $this->request->query : array();
        $this->set(compact('orders', 'data'));
        $this->set('_serialize', ['orders']);
    }

    /**
     * Pending Orders Load method
     *
     * @param string|null request query.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function pendingOrdersLoad() {

        $options['order'] = ['Orders.created DESC'];
        $options['conditions'] = ['Orders.restaurant_id' => $this->restaurant_id, 'Orders.status' => 0];
        $options['limit'] = $this->ConfigSettings['admin_page_limit'];
        $options['contain'] = ['Restaurants', 'Users'];
        $this->paginate = $options;
        $orders = $this->paginate($this->Orders);

        $this->set(compact('orders'));
        $this->set('_serialize', ['orders']);
    }

    /**
     * Accepted Orders method
     *
     * @param string|null request query.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function acceptedOrders() {
        $this->loadModel('Orders');
        $this->loadModel('Reviews');
        $accepted_orders = $this->Orders->find()->where(['OR' => [['Orders.order_status' => '1'], ['Orders.order_status' => '3'], ['Orders.order_status' => '4'], ['Orders.order_status' => '5']], 'user_id' => $this->seller_id])->count();
        $this->set(compact('accepted_orders'));

        $options['order'] = ['Orders.created DESC'];
        $options['conditions'] = ['Orders.user_id' => $this->seller_id, 'Orders.order_status' => 0];
        $options['limit'] = 10;
        $options['contain'] = ['Users'];
        $this->paginate = $options;
        $orders = $this->paginate($this->Orders);
        $data = !empty($this->request->query) ? $this->request->query : array();
        $this->set(compact('orders', 'data'));
        $this->set('_serialize', ['orders']);
    }

    /**
     * Other Orders method
     *
     * @param string|null request query.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function otherOrders() {
        $this->loadModel('Orders');
        $this->loadModel('Reviews');
        $other_orders = $this->Orders->find()->where(['OR' => [['Orders.order_status' => '2'], ['Orders.order_status' => '6']], 'user_id' => $this->seller_id])->count();
        $this->set(compact('other_orders'));
        $options['order'] = ['Orders.created DESC'];
        $options['conditions'] = ['Orders.user_id' => $this->seller_id, 'Orders.order_status' => 0];
        $options['limit'] = 10;
        $options['contain'] = ['Users'];
        $this->paginate = $options;
        $orders = $this->paginate($this->Orders);
        $data = !empty($this->request->query) ? $this->request->query : array();
        $this->set(compact('orders', 'data'));
        $this->set('_serialize', ['orders']);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add() {
        $order = $this->Orders->newEntity();
        if ($this->request->is('post')) {
            $order = $this->Orders->patchEntity($order, $this->request->getData());
            if ($this->Orders->save($order)) {
                $this->Flash->success(__('The order has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The order could not be saved. Please, try again.'));
        }
        $restaurants = $this->Orders->Restaurants->find('list', ['limit' => 200]);
        $userAddresses = $this->Orders->UserAddresses->find('list', ['limit' => 200]);
        $this->set(compact('order', 'restaurants', 'userAddresses'));
        $this->set('_serialize', ['order']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Order id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null) {
        $this->request->allowMethod(['post', 'delete']);
        $order = $this->Orders->get($id);
        if ($this->Orders->delete($order)) {
            $this->Flash->success(__('The order has been deleted.'));
        } else {
            $this->Flash->error(__('The order could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    /**
     * manage_waiter method
     * Des : list all waiters
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function manage_waiter($id = NULL) {
        $this->loadModel('Users');
        $order = $this->Orders->newEntity();
        $orderData = $this->Orders->get($id);
        $waiter_id = $orderData->waiter_id;
        $waiters = $this->Users->find('list', ['keyField' => 'id', 'valueField' => 'first_name'])->where(['restaurant_id' => $this->restaurant_id, 'account_type_id' => 3])
                ->where(['status' => 1, 'verified' => 1])
                ->toArray();
        //pr($waiters); die;
        $this->set(compact('waiters', 'id', 'order', 'waiter_id'));
        $this->set('_serialize', ['waiters']);
    }

    /**
     * add_waiter method
     * Desc : assign waiter on order
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add_waiter() {

        $response = array();
        $response['status'] = 0;
        if ($this->request->is('post')) {
            $orders = TableRegistry::get('Orders');
            if ($this->request->data('waiter_id') != '') {
                $requestData = $this->request->data();
                $order_id = $requestData['order_id'];
                $waiter_id = $requestData['waiter_id'];
                $order = $this->Orders->get($order_id);
                $order->waiter_id = $waiter_id;
                if ($orders->save($order)) {
                    $data['status'] = 7;
                    $this->Default->sendPushNotifications($data, $waiter_id, $order_id);
                    $response['status'] = 1;
                    $response['id'] = $order->id;
                    $response['message'] = 'waiter is assigned on #' . $order->id . ' orderId';
                } else {
                    $response['status'] = 0;
                    $response['message'] = 'waiter is not assigned on #' . $order->id . ' orderId';
                }
            } else {
                $response['status'] = 0;
                $response['message'] = 'Please select waiter';
            }
        } else {
            $response['status'] = 0;
            $response['message'] = 'Not found record';
        }
        echo json_encode($response);
        die;
    }

}
