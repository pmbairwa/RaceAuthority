<?php

namespace App\Controller\Seller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\ORM\TableRegistry;
use Cake\Mailer\MailerAwareTrait;
use Cake\I18n\Date;
use Cake\Validation\Validation;
use Cake\Utility\Text;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 */
class UsersController extends AppController {

    use MailerAwareTrait;

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Time');
        $this->loadComponent('Cookie');
        
        $_dir = str_replace("\\", "/", $this->Users->_dir);
        $this->set(compact('_dir'));
    }

    public function login() {
        $this->viewBuilder()->layout('login');
        if ($this->Auth->user('id')) {
            return $this->redirect($this->Auth->redirectUrl());
        }

        if ($this->request->is('post')) {
            $_user = $this->request->data['username'];
            
            if (Validation::email($this->request->data['username'])) {
                $this->Auth->config('authenticate', [
                    'Form' => [
                        'fields' => ['username' => 'email']
                    ]
                ]);
                $this->Auth->constructAuthenticate();
                $this->request->data['email'] = $this->request->data['username'];
                unset($this->request->data['username']);
            }
            
            $user = $this->Auth->identify();     
            if($user['account_type_id'] == 2){
                $this->request->data['username'] = $_user;            
                if ($user) {
                    $this->Auth->setUser($user);
                    if ($this->request->data['adminremember_me'] == 1) {
                        unset($this->request->data['adminremember_me']);
                        $this->Cookie->write('adminremember_me', $this->request->data, true, "1 week");
                    }
                    return $this->redirect($this->Auth->redirectUrl());
                }
                $this->Flash->error(__('Invalid Email Id or password, try again'));
            }
            else
            {
                $this->Flash->error(__('Invalid Email Id or password, try again'));
                return $this->redirect($this->Auth->logout());
            }    
            
            
        } else {
            $logincookie = $this->Cookie->read('adminremember_me');
            if (!empty($logincookie))
                $this->request->data = $logincookie;
        }
    }

    public function forgot() {
        $this->viewBuilder()->layout('login');
        $UserTokens = TableRegistry::get('UserTokens');        
        $EmailTemplates = TableRegistry::get('EmailTemplates');
        $template = $EmailTemplates->find()->where(['email_type' => 'forgot_password_admin'])->first();
        if ($this->request->is('post')) {
            $uData = $this->{$this->modelClass}->find("all", ['conditions' => ['email' => $this->request->data['email'],'account_type_id' => 2]]);
            $result = $uData->first();
            if (!empty($result)) {
                $uid = Text::uuid();
                $EmailTemplates = TableRegistry::get('EmailTemplates');
                $template = $EmailTemplates->find()->where(['email_type' => 'forgot_password_admin'])->first();
                $message = str_replace('##base_url', _BASE_, $template->description);
                $message = str_replace('##site_name', Configure::read('Setting.SITE_NAME'), $message);
                $message = str_replace('##site_logo', _BASE_ . 'img/uploads/settings/' . Configure::read('Setting.logo'), $message);
                $message = str_replace('##first_name', $result->name, $message);
                $message = str_replace('##user_reset_url', _BASE_ . "restaurant_owner/users/reset/" . $uid, $message);
                $message = str_replace('##footer', "Copyright " . Configure::read('Setting.SITE_NAME') . " " . date("Y"), $message);
                $sentEmail['to'] = $result->email;
                $from = $this->SettingConfig['from_email'];
                $subject = str_replace('##firstname', $result->first_name, $template->subject);

                $_usertoken = $UserTokens->newEntity();
                $_usertoken->user_id = $result->id;
                $_usertoken->user_type = "admin_user";
                $_usertoken->token_type = "forgot";
                $_usertoken->token = $uid;
                if ($UserTokens->save($_usertoken)) {
                    $config['to'] = $result->email;
                    $config['subject'] = $subject;
                    $this->getMailer('Manu')->send('sendEmails', [$config, $message]);
                    $this->Flash->success(__('Your password reset link has been sent to your email!'));
                }
                return $this->redirect(['action' => 'login']);
            } else {
                $this->Flash->error(__('This email address does not exist in database.!'));
            }
        }
    }

    public function reset($token = null) {
        $this->viewBuilder()->layout('login');
        if (!$token) {
            return $this->redirect(['action' => 'login']);
        }
        $UserTokens = TableRegistry::get('UserTokens');
        $query = $UserTokens->find()->select(['id', 'user_id']);
        $query->where(['UserTokens.token' => $token, 'UserTokens.status' => 0, 'UserTokens.user_type' => 'admin_user', 'UserTokens.token_type' => 'forgot'])->order(['id' => 'DESC'])->limit(1);
        $res = $query->first();
        if (empty($res)) {
            $this->Flash->error(__('you token has expired.!'));
            return $this->redirect(['action' => 'forgot']);
        }
        if ($this->request->is('post')) {
            $len = strlen($this->request->data['password']);
            if ($this->request->data['password'] != $this->request->data['confirm_password']) {
                $this->Flash->error(__('password didn\'t match. please try again!'));
                return;
            } elseif ($len < 6) {
                $this->Flash->error(__('Your password must be at least 6 characters long.'));
                return;
            } elseif ($len > 15) {
                $this->Flash->error(__('Password is too long. The limit is 15 characters.'));
                return;
            } elseif (!(preg_match('/^(?=.*[a-zA-Z_@&+-])(?=.*\d)([0-9a-zA-Z_@&+-]+)$/', $this->request->data['password']) && preg_match('/[A-Z]/', $this->request->data['password']) && preg_match('/[a-z]/', $this->request->data['password']) && preg_match('/[!@#$%^&*()\-_=+{};:,<.>]/', $this->request->data['password']))) {
                $this->Flash->error(__('Password must contain at least one small, one capital alphabet, one numeric digit and one special character.'));
                return;
            }
            
            $adminUser = $this->{$this->modelClass}->get($res->user_id);
            $adminUser->password = $this->request->data['password'];
            if ($this->{$this->modelClass}->save($adminUser)) {
                $tokenq = $UserTokens->query();
                $tokenq->delete()
                        ->where(['id' => $res->id])
                        ->execute();
                $this->Flash->success(__('Your password has changed.'));
                return $this->redirect(['action' => 'login']);
            } else {
                $this->Flash->error(__('your process faild. please try again!'));
            }
        }
    }

    public function logout() {
        return $this->redirect($this->Auth->logout());
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function edit() {  
        $user = $this->Users->get($this->Auth->User('id'));  
        if ($this->request->is(['patch', 'post', 'put'])) {
            $this->request->data['added_by'] = "admin";
            if (isset($this->request->query['type'])) {
                $this->request->data['account_type_id'] = 2;
            }
            $user = $this->Users->patchEntity($user, $this->request->data, ['validate' => 'CheckUserEntry']);            
            if ($this->request->data['password'] == "") {
                unset($user->password);
            }
            if ($this->Users->save($user)) {                
                $this->Flash->success(__('Details has been saved.'));                
            }else{
            $this->Flash->error(__('Details could not be saved. Please, try again.'));
            }
        }        
        $accountTypes = $this->Users->AccountTypes->find('list');
        $_dir = str_replace("\\", "/", $this->Users->_dir);
        $this->set(compact('user', '_dir', 'accountTypes'));
        $this->set('_serialize', ['user']);
    }

    public function deleteimg($id = null) {
        $record = $this->Users->get($id);
        if ($this->Users->deleteImage($record->profile_photo, $record)) {
            $this->Flash->success(__('The profile photo has been deleted.'));
        } else {
            $this->Flash->error(__('The profile photo could not be deleted. Please, try again.'));
        }
        return $this->redirect($this->referer());
    }

        
    /*
      Method: updateDeviceToken
     * @param: device id
     * @return: json array() 
     *      */
    public function updateDeviceToken($device_id) {
        $response = [];
        $this->autoRender = false;
        $this->DeviceTokens = TableRegistry::get('DeviceTokens');
        $result = $this->DeviceTokens->findByDeviceTokenAndUserId($device_id, $this->Auth->user('id'))->count();
        if ($result < 1) {
            $obj = $this->DeviceTokens->newEntity();
            $obj->user_id = $this->Auth->user('id');
            $obj->device_type = 'web';
            $obj->device_token = $device_id;
            if ($this->DeviceTokens->save($obj)) {
                $response['status'] = true;
                $response['message'] = 'device token has been updated';
            }else{
                $response['status'] = false;
                $response['message'] = 'device token has been updated';
            }
            echo json_encode($response);
        }
    }

}
