<?php

namespace App\Controller\Seller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;

/**
 * Restaurants Controller
 *
 * @property \App\Model\Table\RestaurantsTable $Restaurants
 *
 * @method \App\Model\Entity\Restaurant[] paginate($object = null, array $settings = [])
 */
class SellerController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Default');
     
        $this->set(compact('_dir'));
        if ($this->Auth->User('id')) {
            $sellerId = $this->Users->find()->where(['id' => $this->Auth->User('id')])->select(['id'])->first();
            $this->loginUserId = $sellerId->id;
        }
    }

  


    public function get_postcode($postcode = null) {
        $this->viewBuilder()->layout('ajax');
        $this->autoRender = false;
        echo $this->Default->getPostcode($postcode);
    }

    /**
     * order report method
     * description : show commission on all restaurant 
     * @return \Cake\Network\Response|null
     */
    public function orders_report() {
        $this->loadModel('Orders');
        $start_date = '';
        $end_date = '';
        $keyword = (isset($this->request->query['keyword']) && $this->request->query['keyword'] != '') ? $this->request->query['keyword'] : '';
        if (isset($this->request->query['start_date']) && $this->request->query['start_date'] != '') {
            $start_date = $this->request->query['start_date'];
        }
        if (isset($this->request->query['end_date']) && $this->request->query['end_date'] != '') {
            $end_date = $this->request->query['end_date'];
        }

        $query = $this->Orders->find('all');
        $query->limit($this->ConfigSettings['admin_page_limit']);
        $query->contain(['Users', 'Restaurants' => function($d) {
                $d->contain(['OrderCosts' => function($c) {
                        return $c->select(['order_per_amount']);
                    }]);
                $d->select(['Restaurants.id']);
                return $d;
            }, 'RestaurantOrders' => function($r) use ($start_date, $end_date) {
                $r->select(['RestaurantOrders.amount']);
                if ($start_date) {
                    $r->where(function($exp) use ($start_date, $end_date) {
                                return $exp->between('DATE(RestaurantOrders.created)', $start_date, $end_date);
                            });
                } else {
                    $r->where(['MONTH(RestaurantOrders.created)' => date('n')]);
                }
                return $r;
            }]);
        if ($keyword) {
            $query->leftJoinWith('Users');
            $query->where(['Users.first_name Like' => '%' . $keyword . '%']);
            $query->orWhere(['Users.last_name Like' => '%' . $keyword . '%']);
        }
        if ($start_date) {
            $query->where(function($exp) use ($start_date, $end_date) {
                return $exp->between('DATE(Orders.created)', $start_date, $end_date);
            });
        } else {
            $query->where(['MONTH(Orders.created)' => date('n')]);
        }
        $query->where(['Orders.status NOT IN' => [0, 2]]);
        $query->where(['Orders.restaurant_id' => $this->loginUserRestaurantId]);

        if (!isset($this->request->query['sort'])) {
            $query->order(['Orders.commission_amount' => 'DESC']);
        }

        $orderData = $query->toArray();
        $totalCommissionAmount = '0';
        $totalAmountA = 0;
        $totalOrderAmount = '0';
        $tableBooingAmount = 0;
        foreach ($orderData as $key => $data) {
            $totalCommissionAmount = $totalCommissionAmount + $data->commission_amount;
            $totalAmountA = $totalAmountA + $data->total_payment;
            if (isset($data->restaurant_order) && count($data->restaurant_order) > 0) {
                $tableBooingAmount = $tableBooingAmount + $data->restaurant_order->amount;
            }
        }
        $totalOrderAmount = ($totalAmountA + $tableBooingAmount);

        $orders = $this->paginate($query);
        $currentMonthOrderTotal = '0';
        $currentMonthOrder = array();
        $query1 = $this->Orders->find('all');
        $query1->select(['Orders.total_payment', 'Orders.restaurant_order_id', 'Orders.on_table', 'Orders.status']);
        $query1->where(['MONTH(Orders.created)' => date('n')]);
        $query1->where(['Orders.status NOT IN' => [0, 2]]);
        $query1->where(['Orders.restaurant_id' => $this->loginUserRestaurantId]);
        $query1->contain(['RestaurantOrders' => function($r) {
                return $r
                                ->select(['RestaurantOrders.amount'])
                                ->where(['MONTH(RestaurantOrders.created)' => date('n')]);
            }]);
        $currentMonthOrder = $query1->toArray();
        $monthPayment = 0;
        foreach ($currentMonthOrder as $key => $monthData) {
            $monthPayment = $monthPayment + $monthData->total_payment;
            if (isset($monthData->restaurant_order) && count($monthData->restaurant_order) > 0) {
                $monthPayment = $monthPayment + $monthData->restaurant_order->amount;
            }
        }
        $currentMonthOrderTotal = $monthPayment;


        $sdate = new \DateTime('last monday');
        $edate = new \DateTime();
        $currentWeekOrderTotal = '0';
        $queryWeek = $this->Orders->find('all');
        $queryWeek->select(['Orders.total_payment', 'Orders.restaurant_order_id', 'Orders.on_table', 'Orders.status']);
        $queryWeek->where(function ($exp, $q) use ($sdate, $edate) {
            return $exp->between('Orders.created', $sdate, $edate);
        });
        $queryWeek->contain(['RestaurantOrders' => function($r) use ($sdate, $edate) {
                return $r
                                ->select(['RestaurantOrders.amount'])
                                ->where(function ($exp, $q) use ($sdate, $edate) {
                                            return $exp->between('RestaurantOrders.created', $sdate, $edate);
                                        });
            }]);
        $queryWeek->where(['Orders.status NOT IN' => [0, 2]]);
        $queryWeek->where(['Orders.restaurant_id' => $this->loginUserRestaurantId]);
        $currentWeekOrder = $queryWeek->toArray();
        $weekPayment = 0;
        foreach ($currentWeekOrder as $key => $weekData) {
            $weekPayment = $weekPayment + $weekData->total_payment;
            if (isset($weekData->restaurant_order) && count($weekData->restaurant_order) > 0) {
                $weekPayment = $weekPayment + $weekData->restaurant_order->amount;
            }
        }
        $currentWeekOrderTotal = $weekPayment;

        $dateformat = Configure::read('Setting.admin_date_time_format');
        $min_wallet_amount = Configure::read('Setting.min_wallet_balance');
        $this->set(compact('orders', 'dateformat', 'min_wallet_amount', 'currentMonthOrderTotal', 'currentWeekOrderTotal', 'totalCommissionAmount', 'totalOrderAmount', 'start_date', 'end_date'));
        $this->set('_serialize', ['restaurants']);
    }

}
