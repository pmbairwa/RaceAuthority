<?php

namespace App\Controller\Seller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class DashboardController extends AppController {

    public function initialize() {
        parent::initialize();
        if ($this->Auth->user()) {
            $this->seller = $seller = $this->Auth->user('id');
            $this->seller_id = $this->seller;
        }
    }

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index() {
        $this->loadModel('Orders');
        $this->loadModel('Reviews');
        $this->loadModel('PaymentDetails');
        $paymentInfo = $this->PaymentDetails->find()->where(['PaymentDetails.seller_id' => $this->seller_id])->toArray();
      
        $reviews = $this->Reviews->find()->where(['user_id' => $this->seller_id])->count();
        $accepted_orders = $this->Orders->find()->where(['OR' => [['Orders.order_status' => '1'], ['Orders.order_status' => '3'], ['Orders.order_status' => '4'], ['Orders.order_status' => '5']], 'user_id' => $this->seller_id])->count();
        $other_orders = $this->Orders->find()->where(['OR' => [['Orders.order_status' => '2'], ['Orders.order_status' => '6']], 'user_id' => $this->seller_id])->count();
        $pending_orders = $this->Orders->find()->where(['user_id' => $this->seller_id, 'order_status' => 0])->count();
        $this->set(compact('pending_orders', 'other_orders', 'accepted_orders', 'reviews','paymentInfo'));

        $options['order'] = ['Orders.created DESC'];
        $options['conditions'] = ['Orders.user_id' => $this->seller_id, 'Orders.order_status' => 0];
        $options['limit'] = 10;
        $options['contain'] = ['Users'];
        $this->paginate = $options;
        $orders = $this->paginate($this->Orders);
        $this->set(compact('orders'));
        $this->set('_serialize', ['orders']);
    }

}
