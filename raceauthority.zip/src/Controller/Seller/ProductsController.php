<?php

namespace App\Controller\Seller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Utility\Text;
use Cake\ORM\TableRegistry;
use Cake\I18n\Time;
use Cake\I18n\Date;
use Cake\Utility\Hash;
use Cake\Routing\Router;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 */
class ProductsController extends AppController {

    public function initialize() {
        parent::initialize();

        $this->Auth->allow(['login']);
        $this->loadComponent('Cookie');
        $this->loadComponent('Default');
    }

    public function index() {
        $options['order'] = ['id' => 'DESC'];
        $options['conditions'] = ['seller_id' => $this->Auth->User('id')];
        $options['limit'] = $this->SettingConfig['admin_paging_limit'];
        $options['finder'] = ['common' => ['searchKeyword' => $this->request->query,]];
        $options['contain'] = ['Categories', 'Seller'];
        $this->paginate = $options;
        $products = $this->paginate($this->Products);
        $this->set(compact('products'));
        $this->set('_serialize', ['products']);
    }

    public function view($id = null) {
        $product = $this->Products->get($id, [
            'contain' => ['Categories']
        ]);
        $this->set(compact('product'));
        $this->set('_serialize', ['product']);
    }

    public function add($id = null) {
        $this->loadModel('Categories');
        $this->loadModel('Users');
        $this->loadModel('Tags');
        $err = '';
        if ($id)
            $product = $this->Products->get($id, ['contain' => ['ProductTags']]
            );
        else
            $product = $this->Products->newEntity();
        $categories = $this->Categories->find('list')->where(['status' => 1])->toArray();
        $sellers = $this->Users->find('list')->where(['status' => 1, 'account_type_id' => 2])->toArray();
        if ($this->request->is(['put', 'post', 'patch'])) {
            $allowed_ext_img = array('jpg', 'jpeg', 'png');
            $file_ext_img = pathinfo($this->request->data['image']['name'], PATHINFO_EXTENSION);
            if (isset($this->request->data['image']) && $this->request->data['image'] != '') {
                if (isset($this->request->data['image']['name']) && $this->request->data['image']['name'] != '') {
                    if (in_array($file_ext_img, $allowed_ext_img)) {
                        $imagename = $this->Default->createImageName($this->request->data['image']['name'], BASE_PATH_PRODUCT_IMAGE, current(explode(".", $this->request->data['image']['name'])));
                        if (move_uploaded_file($this->request->data['image']['tmp_name'], BASE_PATH_PRODUCT_IMAGE . $imagename)) {
                            if ($this->request->data['old_image'] != $imagename) {
                                @unlink(BASE_PATH_PRODUCT_IMAGE . $this->request->data['old_image']);
                            }
                        }
                        $this->request->data['image'] = $imagename;
                    } else {
                        $err .= ' Please upload valid image';
                    }
                } else {
                    $this->request->data['image'] = $this->request->data['old_image'];
                }
            }
            if ($err == '') {
                $this->request->data['seller_id'] = $this->Auth->user('id');
                $product = $this->Products->patchEntity($product, $this->request->data);
                if ($this->Products->save($product)) {
                    $this->Flash->success(__('Product has been saved.'));
                    $this->redirect(['controller' => 'products', 'action' => 'index', 2]);
                } else
                    $this->Flash->error(__($this->Default->get_errors($product->errors())));
            } else {
                $this->Flash->error(__($err));
            }
        }
        $this->set(compact(['product', 'categories', 'sellers']));
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null) {
        $this->request->allowMethod(['post', 'delete']);
        $record = $this->{$this->modelClass}->get($id);

        if ($this->{$this->modelClass}->delete($record)) {
            if (isset($record->image) && !empty($record->image)) {
                $imgurl = 'img/uploads' . DS . 'products' . DS . $record->image;
                if (file_exists($imgurl . $record->image))
                    unlink($imgurl);
            }
            $this->Flash->success(__('The ' . $record->name . ' has been deleted.'));
        } else {
            $this->Flash->error(__('The ' . $record->name . ' could not be deleted. Please, try again.'));
        }
        return $this->redirect($this->referer());
    }

//    public function getall() {
//        $this->loadModel('Tags');
//        if ($this->request->is('ajax')) {
//            $this->autoRender = false;
//            $name = $this->request->query['term'];
//            $results = $this->Tags->find('all', [
//                'conditions' => [
//                    'tags LIKE' => '%' . $name . '%',
//                ]
//            ]);
//            $resultsArr = [];
//            foreach ($results as $result) {
//                $resultsArr[] = ['label' => $result['tags'], 'value' => $result['id']];
//            }
//            echo json_encode($resultsArr);
//        }
//    }

    /**
     * Change Password
     */
    public function changeStatus($id = null) {
        $this->autoRender = false;
        if ($id) {
            $status = isset($_REQUEST['status']) ? $_REQUEST['status'] : "";
            $user = $this->Users->get($id);
            if ($user) {
                $user->status = $status;
            }
            if ($this->Users->save($user)) {

                if ($status == 1)
                    $this->Flash->success(__('The user has been active'));
                else
                    $this->Flash->success(__('The user has been Inactive'));
                return $this->redirect($this->referer());
            }
        }
    }

    public function add_images($id = null) {
        $productImagesTable = TableRegistry::get('ProductImages');
        if ($this->request->is('post')) {
            foreach ($this->request->data['image'] as $k => $images) {
                $err = 0;
                $allowed_ext_img = array('jpg', 'jpeg', 'png');
                $file_ext_img = pathinfo($images['name'], PATHINFO_EXTENSION);
                if (isset($this->request->data['image']) && $this->request->data['image'] != '') {
                    if (isset($images['name']) && $images['name'] != '') {
                        if (in_array($file_ext_img, $allowed_ext_img)) {
                            $imagename = $this->Default->createImageName($images['name'], BASE_PATH_PRODUCT_IMAGE, current(explode(".", $images['name'])));
                            move_uploaded_file($images['tmp_name'], BASE_PATH_PRODUCT_IMAGE . $imagename);
                            $this->request->data['image'] = $imagename;
                            $productImages = $productImagesTable->newEntity();
                            $productImages->image = $imagename;
                            $productImages->product_id = $id;
                            if ($productImagesTable->save($productImages)) {
                                $err = 0;
                            } else {
                                $err = 1;
                            }
                        } else {
                            $err = 1;
                        }
                    }
                } else {
                    $err = 1;
                }
            }
            if ($err == '') {
                $this->Flash->success(__('The image has been saved.'));
            } else {
                $this->Flash->error(__('The could not be saved. Please, try again.'));
            }
        }
        $productImages = $productImagesTable->findByProductId($id);
        $this->set(compact('productImages'));
        $this->set('_serialize', ['productImages']);
    }

    public function delete_image($id = null) {
        $productImagesTable = TableRegistry::get('ProductImages');
        $this->request->allowMethod(['post', 'delete']);
        $record = $productImagesTable->get($id);

        if ($productImagesTable->delete($record)) {
            if (isset($record->image) && !empty($record->image)) {
                $imgurl = 'img/uploads' . DS . 'products' . DS . $record->image;
                if (file_exists($imgurl . $record->image))
                    unlink($imgurl);
            }
            $this->Flash->success(__('The ' . $record->name . ' has been deleted.'));
        } else {
            $this->Flash->error(__('The ' . $record->name . ' could not be deleted. Please, try again.'));
        }
        return $this->redirect($this->referer());
    }

}
