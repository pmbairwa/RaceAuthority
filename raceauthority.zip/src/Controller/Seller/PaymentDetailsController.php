<?php
namespace App\Controller\RestaurantOwner;

use App\Controller\AppController;

/**
 * PaymentDetails Controller
 *
 * @property \App\Model\Table\PaymentDetailsTable $PaymentDetails
 *
 * @method \App\Model\Entity\PaymentDetail[] paginate($object = null, array $settings = [])
 */
class PaymentDetailsController extends AppController
{    
    public function initialize() {
        parent::initialize();
        if ($this->Auth->user()) {
            $this->restaurant_owner = $restaurant_owner = $this->Auth->user('id');

            $this->loadModel('Restaurants');
            $restaurant = $this->Restaurants->find('all')
                    ->where(['user_id' => $this->restaurant_owner])
                    ->first();
            if (empty($restaurant)) {
                $this->Flash->error(__('You need to add restaurant details first to add attributes.'));
                return $this->redirect(['controller'=>'restaurants','action' => 'add']);
            }
            
            $this->restaurant_id = $restaurant->id;
        }
    }
    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function index($id=null)
    {
        $PaymentDetails = $this->PaymentDetails->find()->where(['PaymentDetails.restaurant_id' => $this->restaurant_id])->first();
        if(!empty($PaymentDetails)){            
            $paymentDetail = $this->PaymentDetails->get($PaymentDetails->id, [
                'contain' => []
            ]);
        }else{
            $paymentDetail = $this->PaymentDetails->newEntity();
        }
        if ($this->request->is(['post', 'put'])) {
            $this->request->data['restaurant_id'] = $this->restaurant_id;
            $paymentDetail = $this->PaymentDetails->patchEntity($paymentDetail, $this->request->getData());
            if ($this->PaymentDetails->save($paymentDetail)) {
                $this->Flash->success(__('The payment detail has been saved.'));

                return $this->redirect(['action' => 'index']);
            }            
            $this->Flash->error(__('The payment detail could not be saved. Please, try again.'));
        }              
        $this->set(compact('paymentDetail'));
        $this->set('_serialize', ['paymentDetail']);
    }    
    
}
