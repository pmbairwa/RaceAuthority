<?php

namespace App\Controller\Seller;

use App\Controller\AppController;

/**
 * Reviews Controller
 *
 * @property \App\Model\Table\ReviewsTable $Reviews
 *
 * @method \App\Model\Entity\Review[] paginate($object = null, array $settings = [])
 */
class ReviewsController extends AppController {

    public function initialize() {
        parent::initialize();
        if ($this->Auth->user()) {
            $this->seller = $seller = $this->Auth->user('id');
            $this->seller_id = $this->seller;
        }
    }

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index() {
        $options['finder'] = ['common' => ['searchKeyword' => $this->request->query]];
        $options['order'] = ['lft' => 'ASC'];
        $options['limit'] = $this->ConfigSettings['admin_page_limit'];
        $options['contain'] = ['Seller'];
        $options['conditions'] = ['Reviews.seller_id' => $this->seller_id];
        $this->paginate = $options;
        $reviews = $this->paginate($this->Reviews);

        $this->set(compact('reviews'));
        $this->set('_serialize', ['reviews']);
    }

    /**
     * View method
     *
     * @param string|null $id Review id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null) {
        $review = $this->Reviews->get($id, [
            'contain' => ['Users', 'Restaurants']
        ]);

        $this->set('review', $review);
        $this->set('_serialize', ['review']);
    }

    public function approve($id = null) {
        $reviews = $this->Reviews->find()->where(['Reviews.id' => $id, 'Reviews.restaurant_id' => $this->restaurant_id])->count();
        if ($reviews == 0) {
            $this->Flash->error(__('You are not authorized to access this page.'));
            return $this->redirect(['action' => 'index']);
        }

        $review = $this->Reviews->get($id);
        $review->status = 1;
        if ($this->Reviews->save($review)) {
            $this->Flash->success(__('The review has been approved.'));
        } else {
            $this->Flash->error(__('The review could not be approved. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function reject($id = null) {
        $reviews = $this->Reviews->find()->where(['Reviews.id' => $id, 'Reviews.restaurant_id' => $this->restaurant_id])->count();
        if ($reviews == 0) {
            $this->Flash->error(__('You are not authorized to access this page.'));
            return $this->redirect(['action' => 'index']);
        }

        $review = $this->Reviews->get($id);
        $review->status = 2;
        if ($this->Reviews->save($review)) {
            $this->Flash->success(__('The review has been rejected.'));
        } else {
            $this->Flash->error(__('The review could not be rejected. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

}
