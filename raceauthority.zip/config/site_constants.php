<?php

use Cake\Core\Configure;
use Cake\Routing\Router;

Configure::write('emailTypes', ['forgot_password' => 'Forgot Password','forgot_password_app' => 'Forgot Password App', 'welcome_email' => 'Welcome Email', 'global_form' => 'Global Form','payment_invoice'=>'Payment Invoice','welcome_from_admin'=>'Welcome From Admin','registration_confirmation_request'=>'Registration Confirmation Request']);

Configure::write('Stripe.client_id', 'ca_CGIs4FYxwpM0iNahqF2CvPEXBpZ8aFrk');
Configure::write('Stripe.client_secret', 'sk_test_akFcdNP70Cip5WAXJr79SEOM');
Configure::write('Stripe.grant_type', 'authorization_code');


Configure::write('OptionsType', ['Choose'=>['select'=>'Select','radio'=>'Radio','checkbox'=>'Checkbox'],'Input'=>['text'=>'Text','textarea'=>'Textarea']]);
