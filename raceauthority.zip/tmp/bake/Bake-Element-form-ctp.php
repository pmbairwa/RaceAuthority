<?php

/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @since         0.1.0
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */
use Cake\Utility\Inflector;

$fields = collection($fields)
        ->filter(function($field) use ($schema) {
    return $schema->columnType($field) !== 'binary';
});

if (isset($modelObject) && $modelObject->hasBehavior('Tree')) {
    $fields = $fields->reject(function ($field) {
        return $field === 'lft' || $field === 'rght';
    });
}
?>

<section class="content-header">
    <h1>
            <CakePHPBakeOpenTagphp echo __('Manage <?= $singularHumanName ?>'); CakePHPBakeCloseTag> <small>
<CakePHPBakeOpenTagphp echo empty($<?= $singularVar ?>->id) ? __('Add New <?= $singularHumanName ?>') : __('Edit <?= $singularHumanName ?>'); CakePHPBakeCloseTag>
        </small>
    </h1>
<CakePHPBakeOpenTagphp echo $this->element('breadcrumb', array('pageName' => '<?= $singularHumanName ?>' . (empty($<?= $singularVar ?>->id) ? '_add' : '_edit'))); CakePHPBakeCloseTag>
</section>

<section class="content">
    <div class="box box-info <?= $pluralVar ?>">

        <div class="box-header with-border">
            <h3 class="box-title"><CakePHPBakeOpenTag= __(empty($<?= $singularVar ?>->id) ? 'Add <?= $singularHumanName ?>' : 'Edit <?= $singularHumanName ?>') CakePHPBakeCloseTag></h3>
        </div><!-- /.box-header -->
        <CakePHPBakeOpenTagphp
        $this->loadHelper('Form', [
            'templates' => 'horizontal_form',
        ]);
        CakePHPBakeCloseTag>
<CakePHPBakeOpenTag= $this->Form->create($<?= $singularVar ?>,['role' => 'form', 'enctype' => 'multipart/form-data']) CakePHPBakeCloseTag>
        <div class="box-body">
            <div class="row">
                <div class="col-md-12">
                    <CakePHPBakeOpenTagphp
                    <?php
                    foreach ($fields as $field) {
                        if (in_array($field, $primaryKey)) {
                            continue;
                        }
                        if (isset($keyFields[$field])) {
                            $fieldData = $schema->column($field);
                            if (!empty($fieldData['null'])) {
                                ?>
                    echo $this->Form->control('<?= $field ?>', ['options' => $<?= $keyFields[$field] ?>, 'empty' => true,'class' => 'form-control']);
                                <?php
                            } else {
                                ?>
                    echo $this->Form->control('<?= $field ?>', ['options' => $<?= $keyFields[$field] ?>,'class' => 'form-control']);
                                <?php
                            }
                            continue;
                        }
                        if (!in_array($field, ['created', 'modified', 'updated'])) {
                            $fieldData = $schema->column($field);
                            if (in_array($fieldData['type'], ['date', 'datetime', 'time']) && (!empty($fieldData['null']))) {
                                ?>
                    echo $this->Form->control('<?= $field ?>', ['empty' => true,'class' => 'form-control datepicker', 'placeholder' => __('<?= Inflector::humanize(Inflector::underscore($field)) ?>')]);
                                <?php
                            } else {
                                if ($field == "status") {
                                    ?>
                    echo $this->Form->control('<?= $field ?>',['options'=>[1 => "Active", 0 => "Inactive"],'class' => 'form-control']);
                                <?php
                                } else {

                                    if (in_array($fieldData['type'], ['tinyint']) && (!empty($fieldData['null']))) {
                                        ?>
                    echo $this->Form->control('<?= $field ?>');
                                    <?php } else { ?>
                    echo $this->Form->control('<?= $field ?>',['class' => 'form-control', 'placeholder' => __('<?= Inflector::humanize(Inflector::underscore($field)) ?>')]);
                                    <?php
                                    }
                                }
                            }
                        }
                    }
                    if (!empty($associations['BelongsToMany'])) {
                        foreach ($associations['BelongsToMany'] as $assocName => $assocData) {
                            ?>
                    echo $this->Form->control('<?= $assocData['property'] ?>._ids', ['options' => $<?= $assocData['variable'] ?>,'class' => 'form-control']);
        <?php
    }
}
?>
                    CakePHPBakeCloseTag>
                </div>
            </div><!-- /.row -->
        </div><!-- /.box-body -->
        <div class="box-footer">
        <CakePHPBakeOpenTagphp echo $this->Form->button(__('Submit'), ['class' => 'btn btn-primary', 'title' => __('Submit')]); CakePHPBakeCloseTag>  
        <CakePHPBakeOpenTagphp echo $this->Html->link(__('Cancel'), ['action' => 'index'], ['class' => 'btn btn-warning', 'title' => __('Cancel')]); CakePHPBakeCloseTag>
        </div>

<CakePHPBakeOpenTag= $this->Form->end() CakePHPBakeCloseTag>
    </div>
</section>
