<?php
/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @since         0.1.0
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */
?>
<CakePHPBakeOpenTagphp
/**
 * @var \<?= $namespace ?>\View\AppView $this
 */
CakePHPBakeCloseTag>
<?php
use Cake\Utility\Inflector;

$fields = collection($fields)
->filter(function($field) use ($schema) {
return !in_array($schema->columnType($field), ['binary', 'text']);
});

if (isset($modelObject) && $modelObject->behaviors()->has('Tree')) {
$fields = $fields->reject(function ($field) {
return $field === 'lft' || $field === 'rght';
});
}

if (!empty($indexColumns)) {
$fields = $fields->take($indexColumns);
}
?>

<section class="content-header">
    <h1>
        <CakePHPBakeOpenTagphp echo __('Manage <?= $singularHumanName ?>'); CakePHPBakeCloseTag>  <small><CakePHPBakeOpenTagphp echo __('Here you can manage the <?= $pluralHumanName ?>'); CakePHPBakeCloseTag></small>
    </h1>
    <CakePHPBakeOpenTagphp echo $this->element('breadcrumb', array('pageName' => '<?= $singularHumanName ?>')); CakePHPBakeCloseTag>
</section>
<?php /*
<nav class="large-3 medium-4 columns" id="actions-sidebar">
    <ul class="side-nav">
        <li class="heading"><CakePHPBakeOpenTag= __('Actions') CakePHPBakeCloseTag></li>
        <li><CakePHPBakeOpenTag= $this->Html->link(__('New <?= $singularHumanName ?>'), ['action' => 'add']) CakePHPBakeCloseTag></li>
        <?php
        $done = [];
        foreach ($associations as $type => $data):
        foreach ($data as $alias => $details):
        if (!empty($details['navLink']) && $details['controller'] !== $this->name &&!in_array($details['controller'], $done)):
        ?>
        <li><CakePHPBakeOpenTag= $this->Html->link(__('List <?= $this->_pluralHumanName($alias) ?>'), ['controller' => '<?= $details['controller'] ?>', 'action' => 'index']) CakePHPBakeCloseTag></li>
        <li><CakePHPBakeOpenTag= $this->Html->link(__('New <?= $this->_singularHumanName($alias) ?>'), ['controller' => '<?= $details['controller'] ?>', 'action' => 'add']) CakePHPBakeCloseTag></li>
        <?php
        $done[] = $details['controller'];
        endif;
        endforeach;
        endforeach;
        ?>
    </ul>
</nav>
  */ ?>
<section class="content">
    <div class="row <?= $pluralVar ?>">
        <div class="col-md-12">
            <div class="box box-info">

                <div class="box-header">
                    <h3 class="box-title"><span class="caption-subject font-green bold uppercase">List <CakePHPBakeOpenTagphp echo __('<?= $pluralHumanName ?>'); CakePHPBakeCloseTag></span></h3>
                    <div class="box-tools">
                        <CakePHPBakeOpenTagphp echo $this->html->link("<i class=\"fa fa-plus\"></i> " . __('New <?= $singularHumanName ?>'), ["action" => "add"], ["class" => "btn btn-block btn-primary", "escape" => false]); CakePHPBakeCloseTag>
                    </div>
                </div><!-- /.box-header -->

                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <?php
                                $cols = 2;
                                foreach ($fields as $field):
                                if($field=='id' || $field=='modified')
                                continue;
                                ?>
                                <th scope="col"><CakePHPBakeOpenTag= $this->Paginator->sort('<?= $field ?>') CakePHPBakeCloseTag></th>
                                <?php $cols++;
                                endforeach; ?>
                                <th scope="col" class="actions"><CakePHPBakeOpenTag= __('Actions') CakePHPBakeCloseTag></th>
                            </tr>
                        </thead>
                        <tbody>
                        <CakePHPBakeOpenTagphp if (!empty($<?= $pluralVar ?>->toArray())) {
                            $i = ((($this->Paginator->param('page') - 1) * $this->Paginator->param('perPage')) + 1);
                            foreach ($<?= $pluralVar ?> as $<?= $singularVar ?>): CakePHPBakeCloseTag>
                            <tr>
                                <td><CakePHPBakeOpenTag= $this->Number->format($i) CakePHPBakeCloseTag>.</td>
                                <?php
                                foreach ($fields as $field) {

                                if($field=='id' || $field=='modified')
                                continue;

                                $isKey = false;
                                if (!empty($associations['BelongsTo'])) {
                                foreach ($associations['BelongsTo'] as $alias => $details) {
                                if ($field === $details['foreignKey']) {
                                $isKey = true;
                                ?>
                                <td><CakePHPBakeOpenTag= $<?= $singularVar ?>->has('<?= $details['property'] ?>') ? $this->Html->link($<?= $singularVar ?>-><?= $details['property'] ?>-><?= $details['displayField'] ?>, ['controller' => '<?= $details['controller'] ?>', 'action' => 'view', $<?= $singularVar ?>-><?= $details['property'] ?>-><?= $details['primaryKey'][0] ?>]) : '' CakePHPBakeCloseTag></td>
                                <?php
                                break;
                                }
                                }
                                }

                                if ($isKey !== true) {
                                if ($field=="status") {
                                $isKey = true;
                                ?>
                                            
                                <td>
                                <CakePHPBakeOpenTagphp if ($<?= $singularVar ?>-><?= $field ?> == 1) {
                                    echo '<span class="label label-success"> '.__('Active').' </span>';
                                    } else {
                                    echo '<span class="label label-danger"> '.__('Inactive').' </span>';
                                    }
                                    CakePHPBakeCloseTag>
                                </td>

                                <?php
                                }
                                }

                                if ($isKey !== true) {
                                if ($field=="created") {
                                $isKey = true;
                                ?>
                                            
                                <td>
                                    <CakePHPBakeOpenTagphp if ($<?= $singularVar ?>-><?= $field ?> != "") {
                                    echo $<?= $singularVar ?>-><?= $field ?>->format($settings['admin_date_format']);
                                    }
                                    CakePHPBakeCloseTag>
                                </td>

                                <?php
                                }
                                }

                                if ($isKey !== true) {
                                if (!in_array($schema->columnType($field), ['integer', 'biginteger', 'decimal', 'float'])) {
                                ?>
                                <td><CakePHPBakeOpenTag= h($<?= $singularVar ?>-><?= $field ?>) CakePHPBakeCloseTag></td>
                                <?php
                                } else {
                                ?>
                                <td><CakePHPBakeOpenTag= $this->Number->format($<?= $singularVar ?>-><?= $field ?>) CakePHPBakeCloseTag></td>
                                <?php
                                }
                                }
                                }

                                $pk = '$' . $singularVar . '->' . $primaryKey[0];
                                ?>
                                <td class="actions">
                                    <div class="btn-group">
                                    <CakePHPBakeOpenTag= $this->Html->link("<i class=\"fa fa-edit\"></i>", ['action' => 'add', <?= $pk ?>], ['class' => 'btn btn-primary btn-sm', 'escape' => false,'alt'=>__('Edit'),'title'=>__('Edit')]) CakePHPBakeCloseTag>
                                    <CakePHPBakeOpenTag= $this->Html->link("<i class=\"fa fa-fw fa-eye\"></i>", ['action' => 'view', <?= $pk ?>], ['class' => 'btn btn-warning btn-sm', 'escape' => false,'alt'=>__('View'),'title'=>__('View Detail')]) CakePHPBakeCloseTag>
                                    <CakePHPBakeOpenTag= $this->Form->postLink("<i class=\"fa fa-trash\"></i>", ['action' => 'delete', <?= $pk ?>], ['confirm' => __('Are you sure you want to delete # {0}?', <?= $pk ?>), 'class' => 'btn btn-danger btn-sm', 'escape' => false,'alt'=>__('Delete'),'title'=>__('Delete')]) CakePHPBakeCloseTag>
                                    </div>
                                    </td>
                            </tr>
                            <CakePHPBakeOpenTagphp
                            $i++;
                            endforeach;
                            } else {
                            echo "<tr> <td colspan='<?= $cols?>' align='center'> <strong>Record Not Available</strong> </td> </tr>";
                            }
                            CakePHPBakeCloseTag>
                        </tbody>
                    </table>
                </div>
                <div class="box-footer clearfix">
<CakePHPBakeOpenTagphp echo $this->element('pagination'); CakePHPBakeCloseTag>
                </div>
            </div><!-- /.box -->
        </div>
    </div>
</section>

